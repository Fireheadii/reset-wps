#!/bin/bash

RED=$(tput setaf 1 && tput bold)
GREEN=$(tput setaf 2 && tput bold)
STAND=$(tput sgr0)
BLUE=$(tput setaf 6 && tput bold)

View_Passkeys(){

while true
do

rm /usr/share/FS3/Temp_Working_Dirctory/View_Passkeys.txt &> /dev/null

clear
ls -l /usr/share/FS3/Passkeys | grep ".txt" | rev | awk '{ print $1 }' | rev > /usr/share/FS3/Temp_Working_Dirctory/View_Passkeys.txt
View_Passkeys_List=$(cat /usr/share/FS3/Temp_Working_Dirctory/View_Passkeys.txt | nl -ba -w 1 -s ': ' | column -t)
clear
echo $RED"Passkey's:"
echo "##############"$STAND
echo ""
echo "$View_Passkeys_List"
echo ""
echo "$GREEN[q]$BLUE = Exit.$STAND"
read -p $GREEN"Input the number of a network, or choose an option:$STAND " Passkey_Line_Number

case $Passkey_Line_Number in
1|2|3|4|5|6|7|8|9|1*|2*|3*|4*|5*|6*|7*|8*|9*|q)
break ;;
*) echo "Input was incorrect, please re-choose an option." ;;
esac
done

if [[ $Passkey_Line_Number == "q" ]]; then

   rm /usr/share/FS3/Temp_Working_Dirctory/View_Passkeys.txt &> /dev/null

   exit
fi

Chosen_Passkey_txt=$(cat /usr/share/FS3/Temp_Working_Dirctory/View_Passkeys.txt | sed -n ""$Passkey_Line_Number"p")
gnome-open /usr/share/FS3/Passkeys/$Chosen_Passkey_txt

rm /usr/share/FS3/Temp_Working_Dirctory/View_Passkeys.txt &> /dev/null

View_Passkeys
}

View_Passkeys
